<?php
/**
 * Core plugin bootstrap.
 *
 * @package Kidia_Mobile_CMS
 */

defined( 'ABSPATH' ) || exit;

require_once KIDIA_MOBILE_CMS_PATH . 'includes/class-kidia-mobile-block.php';
require_once KIDIA_MOBILE_CMS_PATH . 'includes/class-kidia-mobile-block-registry.php';
require_once KIDIA_MOBILE_CMS_PATH . 'includes/class-kidia-mobile-layout-store.php';

require_once KIDIA_MOBILE_CMS_PATH . 'includes/blocks/class-kidia-mobile-hero-slider-block.php';
require_once KIDIA_MOBILE_CMS_PATH . 'includes/blocks/class-kidia-mobile-image-banner-block.php';
require_once KIDIA_MOBILE_CMS_PATH . 'includes/blocks/class-kidia-mobile-product-carousel-block.php';

require_once KIDIA_MOBILE_CMS_PATH . 'admin/class-kidia-mobile-cms-admin.php';
require_once KIDIA_MOBILE_CMS_PATH . 'admin/class-kidia-mobile-cms-hero-slider.php';
require_once KIDIA_MOBILE_CMS_PATH . 'admin/class-kidia-mobile-cms-image-banner.php';
require_once KIDIA_MOBILE_CMS_PATH . 'admin/class-kidia-mobile-cms-brand-carousel.php';

require_once KIDIA_MOBILE_CMS_PATH . 'api/class-home-layout-endpoint.php';

final class Kidia_Mobile_CMS {

	private bool $started = false;

	public function run(): void {

		if ( $this->started ) {
			return;
		}

		$this->started = true;

		$this->register_blocks();
		$this->register_admin_modules();
		$this->register_api_modules();

		add_action(
			'init',
			array( $this, 'load_textdomain' )
		);

		add_filter(
			'plugin_action_links_' . KIDIA_MOBILE_CMS_BASENAME,
			array( $this, 'add_plugin_action_links' )
		);
	}

	private function register_blocks(): void {

		Kidia_Mobile_Block_Registry::register(
			new Kidia_Mobile_Hero_Slider_Block()
		);

		Kidia_Mobile_Block_Registry::register(
			new Kidia_Mobile_Image_Banner_Block()
		);

		Kidia_Mobile_Block_Registry::register(
			new Kidia_Mobile_Product_Carousel_Block()
		);
	}

	private function register_admin_modules(): void {

		$admin = new Kidia_Mobile_CMS_Admin();
		$admin->register();

		$hero_slider = new Kidia_Mobile_CMS_Hero_Slider();
		$hero_slider->register();

		$image_banner = new Kidia_Mobile_CMS_Image_Banner();
		$image_banner->register();

		$brand_carousel = new Kidia_Mobile_CMS_Brand_Carousel();
		$brand_carousel->register();
	}

	private function register_api_modules(): void {

		$endpoint =
			new Kidia_Mobile_CMS_Home_Layout_Endpoint_V4();

		$endpoint->register();
	}

	public function load_textdomain(): void {

		load_plugin_textdomain(
			'kidia-mobile-cms',
			false,
			dirname(
				KIDIA_MOBILE_CMS_BASENAME
			) . '/languages'
		);
	}

	public function add_plugin_action_links(
		array $links
	): array {

		$url = admin_url(
			'admin.php?page=kidia-mobile-cms'
		);

		array_unshift(
			$links,
			sprintf(
				'<a href="%s">%s</a>',
				esc_url( $url ),
				esc_html__( 'Dashboard', 'kidia-mobile-cms' )
			)
		);

		return $links;
	}
}