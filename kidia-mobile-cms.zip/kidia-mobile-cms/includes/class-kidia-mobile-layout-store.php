<?php
/**
 * Mobile Home Builder layout storage.
 *
 * @package Kidia_Mobile_CMS
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'Kidia_Mobile_Layout_Store', false ) ) {
	return;
}

final class Kidia_Mobile_Layout_Store {

	private const OPTION_NAME = 'kidia_mobile_home_layout_v2';

	/**
	 * Returns the saved layout.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function get_layout(): array {
		$layout = get_option(
			self::OPTION_NAME,
			array()
		);

		if ( ! is_array( $layout ) || empty( $layout ) ) {
			return $this->get_default_layout();
		}

		return $this->normalize_layout( $layout );
	}

	/**
	 * Saves the submitted layout.
	 *
	 * @param array<int|string, mixed> $submitted_layout Submitted blocks.
	 *
	 * @return bool
	 */
	public function save_layout(
		array $submitted_layout
	): bool {
		$layout = $this->normalize_layout(
			$submitted_layout
		);

		return update_option(
			self::OPTION_NAME,
			$layout,
			false
		);
	}

	/**
	 * Returns default Home Page blocks.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function get_default_layout(): array {
		$types = array(
        	'hero_slider',
        	'image_banner',
        	'product_carousel',
        );

		$layout = array();

		foreach ( $types as $index => $type ) {
			$block = Kidia_Mobile_Block_Registry::create(
				$type,
				$index + 1
			);

			if ( null !== $block ) {
				$layout[] = $block;
			}
		}

		return $layout;
	}

	/**
	 * Normalizes all layout blocks.
	 *
	 * @param array<int|string, mixed> $layout Raw layout.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function normalize_layout(
		array $layout
	): array {
		$normalized = array();

		foreach ( array_values( $layout ) as $index => $raw_block ) {
			if ( ! is_array( $raw_block ) ) {
				continue;
			}

			$type = isset( $raw_block['type'] )
				? sanitize_key( $raw_block['type'] )
				: '';

			if ( ! Kidia_Mobile_Block_Registry::exists( $type ) ) {
				continue;
			}

			$id = isset( $raw_block['id'] )
				? sanitize_key( $raw_block['id'] )
				: '';

			if ( empty( $id ) ) {
				$id = Kidia_Mobile_Block_Registry::generate_id(
					$type
				);
			}

			$settings = isset( $raw_block['settings'] )
				&& is_array( $raw_block['settings'] )
				? $this->sanitize_settings(
					$raw_block['settings']
				)
				: array();

			$settings = wp_parse_args(
				$settings,
				Kidia_Mobile_Block_Registry::defaults( $type )
			);

			$normalized[] = array(
				'id'       => $id,
				'type'     => $type,
				'enabled'  => ! empty( $raw_block['enabled'] ),
				'order'    => $index + 1,
				'settings' => $settings,
			);
		}

		return $normalized;
	}

	/**
	 * Sanitizes nested settings.
	 *
	 * @param array<string|int, mixed> $settings Raw settings.
	 *
	 * @return array<string|int, mixed>
	 */
	private function sanitize_settings(
		array $settings
	): array {
		$sanitized = array();

		foreach ( $settings as $key => $value ) {
			$clean_key = is_string( $key )
				? sanitize_key( $key )
				: absint( $key );

			if ( is_array( $value ) ) {
				$sanitized[ $clean_key ] =
					$this->sanitize_settings( $value );

				continue;
			}

			if ( is_bool( $value ) ) {
				$sanitized[ $clean_key ] = $value;
				continue;
			}

			if ( is_int( $value ) || is_float( $value ) ) {
				$sanitized[ $clean_key ] = $value;
				continue;
			}

			if ( null === $value ) {
				$sanitized[ $clean_key ] = null;
				continue;
			}

			$string_value = (string) $value;

			if (
				is_string( $clean_key )
				&& false !== strpos( $clean_key, 'url' )
			) {
				$sanitized[ $clean_key ] = esc_url_raw(
					$string_value
				);

				continue;
			}

			if (
				is_string( $clean_key )
				&& in_array(
					$clean_key,
					array(
						'content',
						'description',
						'subtitle',
					),
					true
				)
			) {
				$sanitized[ $clean_key ] =
					sanitize_textarea_field( $string_value );

				continue;
			}

			$sanitized[ $clean_key ] =
				sanitize_text_field( $string_value );
		}

		return $sanitized;
	}
}