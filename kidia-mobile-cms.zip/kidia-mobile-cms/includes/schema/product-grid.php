<?php
/**
 * Product Grid Schema.
 *
 * @package Kidia_Mobile_CMS
 */

defined( 'ABSPATH' ) || exit;

return array(
	'title'       => __( 'Product Grid', 'kidia-mobile-cms' ),
	'description' => __( 'Display WooCommerce products in a responsive grid.', 'kidia-mobile-cms' ),
	'icon'        => 'dashicons-grid-view',

	'defaults' => array(
		'title'          => '',
		'subtitle'       => '',
		'source'         => 'latest',
		'limit'          => 8,
		'columns'        => 2,
		'category_id'    => 0,
		'product_ids'    => '',
		'show_view_all'  => true,
		'view_all_label' => '',
		'action_type'    => '',
		'action_value'   => '',
	),

	'tabs' => array(
		array(
			'id'    => 'general',
			'label' => __( 'General', 'kidia-mobile-cms' ),
		),
		array(
			'id'    => 'source',
			'label' => __( 'Source', 'kidia-mobile-cms' ),
		),
		array(
			'id'    => 'display',
			'label' => __( 'Display', 'kidia-mobile-cms' ),
		),
		array(
			'id'    => 'action',
			'label' => __( 'View All Action', 'kidia-mobile-cms' ),
		),
	),

	'fields' => array(
		array(
			'key'        => 'title',
			'label'      => __( 'Section Title', 'kidia-mobile-cms' ),
			'type'       => 'text',
			'tab'        => 'general',
			'default'    => '',
			'full_width' => true,
		),
		array(
			'key'        => 'subtitle',
			'label'      => __( 'Subtitle', 'kidia-mobile-cms' ),
			'type'       => 'textarea',
			'tab'        => 'general',
			'default'    => '',
			'rows'       => 3,
			'full_width' => true,
		),
		array(
			'key'     => 'source',
			'label'   => __( 'Products Source', 'kidia-mobile-cms' ),
			'type'    => 'select',
			'tab'     => 'source',
			'default' => 'latest',
			'options' => array(
				'latest'       => __( 'Latest Products', 'kidia-mobile-cms' ),
				'featured'     => __( 'Featured Products', 'kidia-mobile-cms' ),
				'on_sale'      => __( 'On Sale', 'kidia-mobile-cms' ),
				'best_selling' => __( 'Best Selling', 'kidia-mobile-cms' ),
				'top_rated'    => __( 'Top Rated', 'kidia-mobile-cms' ),
				'random'       => __( 'Random', 'kidia-mobile-cms' ),
				'category'     => __( 'Specific Category', 'kidia-mobile-cms' ),
				'manual'       => __( 'Manual Selection', 'kidia-mobile-cms' ),
			),
		),
		array(
			'key'     => 'category_id',
			'label'   => __( 'Category ID', 'kidia-mobile-cms' ),
			'type'    => 'number',
			'tab'     => 'source',
			'default' => 0,
			'min'     => 0,
			'step'    => 1,
		),
		array(
			'key'         => 'product_ids',
			'label'       => __( 'Product IDs', 'kidia-mobile-cms' ),
			'type'        => 'text',
			'tab'         => 'source',
			'default'     => '',
			'description' => __( 'For Manual Selection, enter IDs separated by commas.', 'kidia-mobile-cms' ),
			'full_width'  => true,
		),
		array(
			'key'     => 'limit',
			'label'   => __( 'Products Limit', 'kidia-mobile-cms' ),
			'type'    => 'number',
			'tab'     => 'source',
			'default' => 8,
			'min'     => 1,
			'max'     => 50,
			'step'    => 1,
		),
		array(
			'key'     => 'columns',
			'label'   => __( 'Columns', 'kidia-mobile-cms' ),
			'type'    => 'number',
			'tab'     => 'display',
			'default' => 2,
			'min'     => 1,
			'max'     => 4,
			'step'    => 1,
		),
		array(
			'key'     => 'show_view_all',
			'label'   => __( 'Show View All', 'kidia-mobile-cms' ),
			'type'    => 'checkbox',
			'tab'     => 'display',
			'default' => true,
		),
		array(
			'key'        => 'view_all_label',
			'label'      => __( 'View All Label', 'kidia-mobile-cms' ),
			'type'       => 'text',
			'tab'        => 'display',
			'default'    => '',
			'full_width' => true,
		),
		array(
			'key'     => 'action_type',
			'label'   => __( 'Action Type', 'kidia-mobile-cms' ),
			'type'    => 'select',
			'tab'     => 'action',
			'default' => '',
			'options' => array(
				''           => __( 'Automatic', 'kidia-mobile-cms' ),
				'collection' => __( 'Collection', 'kidia-mobile-cms' ),
				'category'   => __( 'Category', 'kidia-mobile-cms' ),
				'product'    => __( 'Product', 'kidia-mobile-cms' ),
				'brand'      => __( 'Brand', 'kidia-mobile-cms' ),
				'brands'     => __( 'All Brands', 'kidia-mobile-cms' ),
				'search'     => __( 'Search', 'kidia-mobile-cms' ),
				'external'   => __( 'External URL', 'kidia-mobile-cms' ),
			),
		),
		array(
			'key'         => 'action_value',
			'label'       => __( 'Action Value', 'kidia-mobile-cms' ),
			'type'        => 'text',
			'tab'         => 'action',
			'default'     => '',
			'description' => __( 'Leave the action fields empty to link to the selected source automatically.', 'kidia-mobile-cms' ),
			'full_width'  => true,
		),
	),
);
