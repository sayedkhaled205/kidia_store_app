<?php
/**
 * Mobile Home Builder block registry.
 *
 * @package Kidia_Mobile_CMS
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'Kidia_Mobile_Block_Registry', false ) ) {
	return;
}

final class Kidia_Mobile_Block_Registry {

	/**
	 * Registered block objects.
	 *
	 * @var array<string, Kidia_Mobile_Block>
	 */
	private static array $registered_blocks = array();

	/**
	 * Registers a Home Builder block.
	 *
	 * @param Kidia_Mobile_Block $block Block object.
	 *
	 * @return void
	 */
	public static function register(
		Kidia_Mobile_Block $block
	): void {
		$type = sanitize_key(
			$block->get_type()
		);

		if ( empty( $type ) ) {
			return;
		}

		self::$registered_blocks[ $type ] = $block;
	}

	/**
	 * Removes a registered block.
	 *
	 * Useful for testing or disabling a block dynamically.
	 *
	 * @param string $type Block type.
	 *
	 * @return void
	 */
	public static function unregister(
		string $type
	): void {
		$type = sanitize_key( $type );

		unset(
			self::$registered_blocks[ $type ]
		);
	}

	/**
	 * Returns a registered block object.
	 *
	 * @param string $type Block type.
	 *
	 * @return Kidia_Mobile_Block|null
	 */
	public static function get_block(
		string $type
	): ?Kidia_Mobile_Block {
		$type = sanitize_key( $type );

		return self::$registered_blocks[ $type ] ?? null;
	}

	/**
	 * Returns all registered block objects.
	 *
	 * @return array<string, Kidia_Mobile_Block>
	 */
	public static function registered(): array {
		return self::$registered_blocks;
	}

	/**
	 * Returns definitions for all supported blocks.
	 *
	 * Registered block objects take priority over legacy definitions.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function all(): array {
		$definitions = self::legacy_definitions();

		foreach ( self::$registered_blocks as $type => $block ) {
			$definition = $block->get_definition();

			$definition['defaults'] =
				$block->get_default_settings();

			$definitions[ $type ] = $definition;
		}

		return $definitions;
	}

	/**
	 * Returns one block definition.
	 *
	 * @param string $type Block type.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function get(
		string $type
	): ?array {
		$type   = sanitize_key( $type );
		$blocks = self::all();

		return $blocks[ $type ] ?? null;
	}

	/**
	 * Checks whether a block type is supported.
	 *
	 * @param string $type Block type.
	 *
	 * @return bool
	 */
	public static function exists(
		string $type
	): bool {
		return null !== self::get( $type );
	}

	/**
	 * Checks whether a real block object is registered.
	 *
	 * @param string $type Block type.
	 *
	 * @return bool
	 */
	public static function is_registered(
		string $type
	): bool {
		return self::get_block( $type )
			instanceof Kidia_Mobile_Block;
	}

	/**
	 * Returns default settings for a block.
	 *
	 * @param string $type Block type.
	 *
	 * @return array<string, mixed>
	 */
	public static function defaults(
		string $type
	): array {
		$block = self::get_block( $type );

		if ( $block instanceof Kidia_Mobile_Block ) {
			return $block->get_default_settings();
		}

		$definition = self::get( $type );

		if (
			null === $definition
			|| empty( $definition['defaults'] )
			|| ! is_array( $definition['defaults'] )
		) {
			return array();
		}

		return $definition['defaults'];
	}

	/**
	 * Creates a new block instance.
	 *
	 * @param string $type  Block type.
	 * @param int    $order Block order.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function create(
		string $type,
		int $order = 1
	): ?array {
		$type  = sanitize_key( $type );
		$block = self::get_block( $type );

		if ( $block instanceof Kidia_Mobile_Block ) {
			return $block->create_instance(
				max( 1, $order )
			);
		}

		if ( ! self::exists( $type ) ) {
			return null;
		}

		return array(
			'id'       => self::generate_id( $type ),
			'type'     => $type,
			'enabled'  => true,
			'order'    => max( 1, $order ),
			'settings' => self::defaults( $type ),
		);
	}

	/**
	 * Normalizes a saved block instance.
	 *
	 * @param array<string, mixed> $instance Saved instance.
	 * @param int                  $order    Block order.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function normalize(
		array $instance,
		int $order
	): ?array {
		$type = isset( $instance['type'] )
			? sanitize_key(
				(string) $instance['type']
			)
			: '';

		if ( empty( $type ) || ! self::exists( $type ) ) {
			return null;
		}

		$block = self::get_block( $type );

		if ( $block instanceof Kidia_Mobile_Block ) {
			return $block->normalize_instance(
				$instance,
				max( 1, $order )
			);
		}

		$id = isset( $instance['id'] )
			? sanitize_key(
				(string) $instance['id']
			)
			: '';

		if ( empty( $id ) ) {
			$id = self::generate_id( $type );
		}

		$settings = isset( $instance['settings'] )
			&& is_array( $instance['settings'] )
				? $instance['settings']
				: array();

		return array(
			'id'       => $id,
			'type'     => $type,
			'enabled'  => ! empty( $instance['enabled'] ),
			'order'    => max( 1, $order ),
			'settings' => wp_parse_args(
				$settings,
				self::defaults( $type )
			),
		);
	}

/**
 * Builds one complete REST API block.
 *
 * @param array<string, mixed> $instance Saved block instance.
 *
 * @return array<string, mixed>|null
 */
public static function build_api_block(
	array $instance
): ?array {
	$type = isset( $instance['type'] )
		? sanitize_key(
			(string) $instance['type']
		)
		: '';

	if ( empty( $type ) ) {
		return null;
	}

	$block = self::get_block( $type );

	if ( ! $block instanceof Kidia_Mobile_Block ) {
		return null;
	}

	return $block->build_api_block(
		$instance
	);
}
	/**
	 * Returns definitions used in the Add Element window.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function picker_definitions(): array {
		$definitions = array();

		foreach ( self::all() as $type => $definition ) {
			$definitions[ $type ] = array(
				'type'        => $type,
				'label'       => isset( $definition['label'] )
					? (string) $definition['label']
					: $type,
				'description' => isset( $definition['description'] )
					? (string) $definition['description']
					: '',
				'icon'        => isset( $definition['icon'] )
					? (string) $definition['icon']
					: 'dashicons-screenoptions',
				'duplicable'  => isset( $definition['duplicable'] )
					? (bool) $definition['duplicable']
					: true,
				'available'   => self::is_registered( $type ),
			);
		}

		return $definitions;
	}

	/**
	 * Generates a unique block ID.
	 *
	 * @param string $type Block type.
	 *
	 * @return string
	 */
	public static function generate_id(
		string $type
	): string {
		$type = sanitize_key( $type );

		if ( empty( $type ) ) {
			$type = 'block';
		}

		$uuid = function_exists( 'wp_generate_uuid4' )
			? wp_generate_uuid4()
			: uniqid( '', true );

		return sanitize_key(
			$type
			. '_'
			. str_replace(
				array( '-', '.' ),
				'',
				$uuid
			)
		);
	}

	/**
	 * Returns legacy definitions.
	 *
	 * These definitions keep the current project compatible while
	 * each block is gradually converted into a real block class.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	private static function legacy_definitions(): array {
		return array(
			'hero_slider' => array(
				'type'        => 'hero_slider',
				'label'       => 'Hero Slider',
				'description' => 'Main application slider.',
				'icon'        => 'dashicons-images-alt2',
				'duplicable'  => true,
				'defaults'    => array(
					'aspect_ratio' => 1.8,
					'auto_play'    => true,
					'interval_ms'  => 4500,
					'items'        => array(),
				),
			),

			'image_banner' => array(
				'type'        => 'image_banner',
				'label'       => 'Image Banner',
				'description' => 'Clickable promotional image.',
				'icon'        => 'dashicons-format-image',
				'duplicable'  => true,
				'defaults'    => array(
					'image_url'      => '',
					'semantic_label' => '',
					'aspect_ratio'   => 2.4,
					'border_radius'  => 20,
					'action_type'    => '',
					'action_value'   => '',
				),
			),

			'category_grid' => array(
				'type'        => 'category_grid',
				'label'       => 'Category Grid',
				'description' => 'WooCommerce product categories.',
				'icon'        => 'dashicons-grid-view',
				'duplicable'  => true,
				'defaults'    => array(
					'title'      => 'تسوق حسب القسم',
					'subtitle'   => 'اختر القسم المناسب لطفلك',
					'columns'    => 4,
					'limit'      => 8,
					'parent_id'  => 0,
					'show_names' => true,
					'hide_empty' => true,
				),
			),

			'product_grid' => array(
				'type'        => 'product_grid',
				'label'       => 'Product Grid',
				'description' => 'Products displayed in columns.',
				'icon'        => 'dashicons-screenoptions',
				'duplicable'  => true,
				'defaults'    => array(
					'title'         => 'وصل حديثًا',
					'source'        => 'latest',
					'limit'         => 8,
					'columns'       => 2,
					'category_id'   => 0,
					'show_view_all' => true,
				),
			),

			'brand_carousel' => array(
				'type'        => 'brand_carousel',
				'label'       => 'Brand Carousel',
				'description' => 'Store brands and logos.',
				'icon'        => 'dashicons-tag',
				'duplicable'  => true,
				'defaults'    => array(
					'title'      => 'علامات نحبها',
					'subtitle'   => 'تسوق من العلامات المتوفرة لدينا',
					'item_width' => 92,
					'items'      => array(),
				),
			),

			'section_header' => array(
				'type'        => 'section_header',
				'label'       => 'Section Header',
				'description' => 'Title, subtitle and optional action.',
				'icon'        => 'dashicons-heading',
				'duplicable'  => true,
				'defaults'    => array(
					'title'        => 'عنوان القسم',
					'subtitle'     => '',
					'action_label' => '',
					'action_type'  => '',
					'action_value' => '',
				),
			),

			'text_block' => array(
				'type'        => 'text_block',
				'label'       => 'Text Block',
				'description' => 'Custom formatted text.',
				'icon'        => 'dashicons-text',
				'duplicable'  => true,
				'defaults'    => array(
					'title'      => '',
					'content'    => '',
					'alignment'  => 'right',
					'background' => '',
				),
			),

			'promo_strip' => array(
				'type'        => 'promo_strip',
				'label'       => 'Promo Strip',
				'description' => 'Small promotional message strip.',
				'icon'        => 'dashicons-megaphone',
				'duplicable'  => true,
				'defaults'    => array(
					'text'             => '',
					'background_color' => '#4f9f8f',
					'text_color'       => '#ffffff',
					'action_type'      => '',
					'action_value'     => '',
				),
			),

			'coupon_banner' => array(
				'type'        => 'coupon_banner',
				'label'       => 'Coupon Banner',
				'description' => 'Promotional coupon card.',
				'icon'        => 'dashicons-tickets-alt',
				'duplicable'  => true,
				'defaults'    => array(
					'title'       => '',
					'description' => '',
					'coupon_code' => '',
					'image_url'   => '',
				),
			),

			'countdown' => array(
				'type'        => 'countdown',
				'label'       => 'Countdown',
				'description' => 'Countdown for an offer or launch.',
				'icon'        => 'dashicons-clock',
				'duplicable'  => true,
				'defaults'    => array(
					'title'        => '',
					'ends_at'      => '',
					'expired_text' => 'انتهى العرض',
				),
			),

			'video_banner' => array(
				'type'        => 'video_banner',
				'label'       => 'Video Banner',
				'description' => 'Video or external media banner.',
				'icon'        => 'dashicons-video-alt3',
				'duplicable'  => true,
				'defaults'    => array(
					'video_url'    => '',
					'poster_url'   => '',
					'aspect_ratio' => 1.8,
					'auto_play'    => false,
					'muted'        => true,
				),
			),

			'divider' => array(
				'type'        => 'divider',
				'label'       => 'Divider',
				'description' => 'Visual separator.',
				'icon'        => 'dashicons-minus',
				'duplicable'  => true,
				'defaults'    => array(
					'color'     => '#e5e7eb',
					'thickness' => 1,
					'margin'    => 16,
				),
			),

			'spacer' => array(
				'type'        => 'spacer',
				'label'       => 'Spacer',
				'description' => 'Empty vertical space.',
				'icon'        => 'dashicons-editor-expand',
				'duplicable'  => true,
				'defaults'    => array(
					'height' => 24,
				),
			),
		);
	}
}