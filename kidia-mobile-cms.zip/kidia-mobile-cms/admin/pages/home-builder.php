<?php
/**
 * Home Builder admin page.
 *
 * @package Kidia_Mobile_CMS
 */

defined( 'ABSPATH' ) || exit;

if (
	! isset( $definitions )
	|| ! is_array( $definitions )
) {
	$definitions =
		Kidia_Mobile_Block_Registry::picker_definitions();
}

if (
	! isset( $blocks )
	|| ! is_array( $blocks )
) {
	$blocks = array();
}

/**
 * Library option names by block type.
 *
 * @var array<string,string>
 */
$library_options = array(
	'app_header'       => 'kidia_mobile_app_headers',
	'hero_slider'      => 'kidia_mobile_hero_sliders',
	'image_banner'     => 'kidia_mobile_image_banners',
	'product_carousel' => 'kidia_mobile_product_carousels',
	'brand_carousel'   => 'kidia_mobile_brand_carousels',
	'category_grid'    => 'kidia_mobile_category_grids',
	'product_grid'     => 'kidia_mobile_product_grids',
	'section_header'   => 'kidia_mobile_section_headers',
	'promo_strip'      => 'kidia_mobile_promo_strips',
	'coupon_banner'    => 'kidia_mobile_coupon_banners',
	'countdown'        => 'kidia_mobile_countdowns',
	'video_banner'     => 'kidia_mobile_video_banners',
	'text_block'       => 'kidia_mobile_text_blocks',
	'divider'          => 'kidia_mobile_dividers',
	'spacer'           => 'kidia_mobile_spacers',
	'quick_links'      => 'kidia_mobile_quick_links',
	'banner_grid'      => 'kidia_mobile_banner_grids',
);

/**
 * Library records grouped by block type.
 *
 * @var array<string,array<int,array<string,mixed>>>
 */
$library_items = array();
$layout_counts = array();

/**
 * Friendly categories used to organise Home elements without changing their
 * saved page order.
 *
 * @var array<string,array{label:string,types:array<int,string>}>
 */
$element_categories = array(
	'page-structure' => array(
		'label' => __( 'Page Structure', 'kidia-mobile-cms' ),
		'types' => array( 'app_header' ),
	),
	'hero-banners' => array(
		'label' => __( 'Hero & Banners', 'kidia-mobile-cms' ),
		'types' => array( 'hero_slider', 'image_banner', 'banner_grid', 'video_banner' ),
	),
	'products' => array(
		'label' => __( 'Products', 'kidia-mobile-cms' ),
		'types' => array( 'category_grid', 'product_carousel', 'product_grid', 'brand_carousel', 'bundle_collection' ),
	),
	'content' => array(
		'label' => __( 'Content', 'kidia-mobile-cms' ),
		'types' => array( 'section_header', 'text_block', 'quick_links' ),
	),
	'layout' => array(
		'label' => __( 'Layout', 'kidia-mobile-cms' ),
		'types' => array( 'divider', 'spacer' ),
	),
	'marketing' => array(
		'label' => __( 'Marketing', 'kidia-mobile-cms' ),
		'types' => array( 'promo_strip', 'coupon_banner', 'countdown' ),
	),
);

$element_category_by_type = array();
foreach ( $element_categories as $category_key => $category ) {
	foreach ( $category['types'] as $category_type ) {
		$element_category_by_type[ $category_type ] = array(
			'key'   => $category_key,
			'label' => $category['label'],
		);
	}
}

foreach ( $blocks as $layout_block ) {
	if ( ! is_array( $layout_block ) ) {
		continue;
	}

	$layout_type = sanitize_key( (string) ( $layout_block['type'] ?? '' ) );

	if ( '' !== $layout_type ) {
		$layout_counts[ $layout_type ] = ( $layout_counts[ $layout_type ] ?? 0 ) + 1;
	}
}

foreach ( $library_options as $type => $option_name ) {
	$items = get_option(
		$option_name,
		array()
	);

	$library_items[ $type ] = is_array( $items )
		? array_values( $items )
		: array();
}
?>

<div class="wrap kidia-builder-wrap">

	<?php if ( isset( $_GET['restored'] ) ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Home page restored to defaults.', 'kidia-mobile-cms' ); ?></p></div>
	<?php elseif (
		isset( $_GET['updated'] )
		&& '1' === sanitize_key(
			wp_unslash( $_GET['updated'] )
		)
	) : ?>

		<div class="notice notice-success is-dismissible">

			<p>
				<?php
					esc_html_e(
						'Home Layout saved successfully.',
						'kidia-mobile-cms'
					);
					?>
			</p>

		</div>

	<?php endif; ?>

	<div class="kidia-builder-workspace">
		<aside class="kidia-mobile-preview" aria-label="<?php echo esc_attr__( 'Live mobile preview', 'kidia-mobile-cms' ); ?>">
			<div class="kidia-mobile-preview__device">
			<div class="kidia-mobile-preview__screen">
				<?php if ( file_exists( KIDIA_MOBILE_CMS_PATH . 'admin/flutter-preview/index.html' ) ) : ?>
					<iframe id="kidia-flutter-preview" class="kidia-flutter-preview" title="<?php echo esc_attr__( 'Flutter mobile preview', 'kidia-mobile-cms' ); ?>" src="<?php echo esc_url( add_query_arg( array( 'page' => 'home', 'v' => KIDIA_MOBILE_CMS_VERSION ), KIDIA_MOBILE_CMS_URL . 'admin/flutter-preview/index.html' ) ); ?>"></iframe>
					<div id="kidia-mobile-preview-content" class="kidia-mobile-preview__content kidia-legacy-preview-fallback" hidden></div>
				<?php else : ?>
					<div id="kidia-mobile-preview-content" class="kidia-mobile-preview__content"></div>
				<?php endif; ?>
				</div>
			</div>
		</aside>
		<div class="kidia-builder-editor">
	<form
		method="post"
		action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
		id="kidia-home-builder-form"
		novalidate
	>

		<input
			type="hidden"
			name="action"
			value="kidia_mobile_save_home_builder"
		>

		<input
			type="hidden"
			name="blocks_payload"
			id="kidia-home-builder-payload"
			value=""
		>

		<input
			type="hidden"
			name="blocks_payload_encoding"
			id="kidia-home-builder-payload-encoding"
			value="base64"
		>

		<input
			type="hidden"
			name="edit_after_save_type"
			id="kidia-edit-after-save-type"
			value=""
		>

		<input
			type="hidden"
			name="edit_after_save_id"
			id="kidia-edit-after-save-id"
			value=""
		>

		<?php
		wp_nonce_field(
			'kidia_mobile_save_home_builder',
			'kidia_mobile_home_builder_nonce'
		);
		?>

		<?php
		$kidia_toolbar_title = __( 'Home Page', 'kidia-mobile-cms' );
		$kidia_toolbar_save_label = __( 'Save Home Layout', 'kidia-mobile-cms' );
		$kidia_toolbar_show_add = true;
		$kidia_toolbar_show_restore = true;
		$kidia_toolbar_page_toggle = false;
		include KIDIA_MOBILE_CMS_PATH . 'admin/pages/builder-toolbar.php';
		?>
		<div class="kidia-builder-cards-scroll" data-kidia-builder-cards-scroll>
		<?php $chrome_layout = $home_chrome; $chrome_part = 'header'; $chrome_page = 'home'; include KIDIA_MOBILE_CMS_PATH . 'admin/pages/fixed-chrome-card.php'; ?>

		<div
			id="kidia-home-builder"
			class="kidia-builder-list"
		>

			<?php if ( empty( $blocks ) ) : ?>

				<div
					id="kidia-builder-empty"
					class="kidia-builder-empty"
				>
					<span class="dashicons dashicons-screenoptions"></span>

					<h2>
						<?php
							esc_html_e(
								'No elements on the Home Page',
								'kidia-mobile-cms'
							);
							?>
					</h2>

					<p>
						<?php
							esc_html_e(
								'Add an element to start building the application Home Page.',
								'kidia-mobile-cms'
							);
							?>
					</p>

					<button
						type="button"
						class="button button-primary"
						data-kidia-open-picker
					>
						<?php
							esc_html_e(
								'Add First Element',
								'kidia-mobile-cms'
							);
							?>
					</button>
				</div>

			<?php endif; ?>

			<?php foreach ( $blocks as $index => $block_data ) : ?>

				<?php
				if ( ! is_array( $block_data ) ) {
					continue;
				}

				$type = isset( $block_data['type'] )
					? sanitize_key(
						(string) $block_data['type']
					)
					: '';

				if ( '' === $type ) {
					continue;
				}

				$block =
					Kidia_Mobile_Block_Registry::get_block(
						$type
					);

				if (
					! $block instanceof Kidia_Mobile_Block
				) {
					continue;
				}

				$block_data['name'] = ! empty(
					$block_data['name']
				)
					? sanitize_text_field(
						(string) $block_data['name']
					)
					: $block->get_label();

				$block_data['library_id'] = ! empty(
					$block_data['library_id']
				)
					? sanitize_key(
						(string) $block_data['library_id']
					)
					: sanitize_key(
						(string) (
							$block_data['id']
							?? ''
						)
					);

				$definition = $block->get_definition();
				$category = $element_category_by_type[ $type ] ?? array(
					'key'   => 'content',
					'label' => __( 'Content', 'kidia-mobile-cms' ),
				);
				$block_data['element_icon'] = sanitize_html_class(
					(string) ( $definition['icon'] ?? 'dashicons-screenoptions' )
				);
				$block_data['element_category_key'] = sanitize_key( $category['key'] );
				$block_data['element_category_label'] = sanitize_text_field( $category['label'] );

				include
					KIDIA_MOBILE_CMS_PATH .
					'admin/templates/block-template.php';
				?>

			<?php endforeach; ?>

		</div>
		<?php $chrome_layout = $home_chrome; $chrome_part = 'footer'; $chrome_page = 'home'; include KIDIA_MOBILE_CMS_PATH . 'admin/pages/fixed-chrome-card.php'; ?>
		</div>

	</form>
		</div>
	</div>

</div>

<div
	id="kidia-element-picker"
	class="kidia-element-picker"
	hidden
	aria-hidden="true"
>

	<div
		class="kidia-element-picker__overlay"
		data-kidia-close-picker
	></div>

	<div
		class="kidia-element-picker__panel"
		role="dialog"
		aria-modal="true"
		aria-labelledby="kidia-element-picker-title"
	>
		<nav class="kidia-element-category-filter" aria-label="<?php echo esc_attr__( 'Filter elements by category', 'kidia-mobile-cms' ); ?>">
			<button type="button" class="button is-active" data-kidia-element-category="all" aria-pressed="true">
				<?php esc_html_e( 'All', 'kidia-mobile-cms' ); ?>
			</button>
			<?php foreach ( $element_categories as $category_key => $category ) : ?>
				<button type="button" class="button" data-kidia-element-category="<?php echo esc_attr( $category_key ); ?>" aria-pressed="false">
					<?php echo esc_html( $category['label'] ); ?>
				</button>
			<?php endforeach; ?>
		</nav>

		<div class="kidia-element-picker__header">

			<div>

				<h2 id="kidia-element-picker-title">
					<?php
						esc_html_e(
							'Add Element',
							'kidia-mobile-cms'
						);
						?>
				</h2>

				<p>
					<?php
						esc_html_e(
							'Choose an element type. Expand it only when you need a saved item.',
							'kidia-mobile-cms'
						);
						?>
				</p>

			</div>

			<button
				type="button"
				class="button-link kidia-element-picker__close"
				data-kidia-close-picker
				aria-label="<?php
					echo esc_attr__(
						'Close',
						'kidia-mobile-cms'
					);
				?>"
			>
				<span class="dashicons dashicons-no-alt"></span>
			</button>

		</div>

		<div class="kidia-element-picker__toolbar">

			<input
				type="search"
				id="kidia-element-picker-search"
				class="regular-text"
				placeholder="<?php
					echo esc_attr__(
						'Search elements...',
						'kidia-mobile-cms'
					);
				?>"
			>

		</div>

		<div class="kidia-element-picker__content">

			<?php foreach ( $definitions as $type => $definition ) : ?>

				<?php
				$type = sanitize_key(
					(string) (
						$definition['type']
						?? $type
					)
				);

				if (
					'' === $type
					|| empty( $definition['available'] )
				) {
					continue;
				}

				$label = isset( $definition['label'] )
					? (string) $definition['label']
					: $type;

				$description = isset(
					$definition['description']
				)
					? (string) $definition['description']
					: '';

				$icon = isset( $definition['icon'] )
					? (string) $definition['icon']
					: 'dashicons-screenoptions';

				// Home Builder is the only authoring surface. Legacy Library records
				// remain in the database for migration, but are not offered here.
				$type_items = array();
				$picker_category = $element_category_by_type[ $type ] ?? array(
					'key'   => 'content',
					'label' => __( 'Content', 'kidia-mobile-cms' ),
				);
				?>

				<button
					type="button"
					class="kidia-element-group"
					data-element-group="<?php echo esc_attr( $type ); ?>"
					data-element-category="<?php echo esc_attr( $picker_category['key'] ); ?>"
					data-block-type="<?php echo esc_attr( $type ); ?>"
					data-block-label="<?php echo esc_attr( $label ); ?>"
				>
					<span class="kidia-element-group__summary">
						<span class="kidia-element-group__identity">
								<span
									class="dashicons <?php echo esc_attr( $icon ); ?>"
							></span>
							<strong><?php echo esc_html( $label ); ?></strong>
							<small><?php echo esc_html( $picker_category['label'] ); ?></small>
						</span>
					</span>
				</button>

			<?php endforeach; ?>

			<div
				id="kidia-element-picker-no-results"
				class="kidia-element-picker__empty"
				hidden
			>
				<?php
					esc_html_e(
						'No matching elements found.',
						'kidia-mobile-cms'
					);
					?>
			</div>

		</div>

		<div class="kidia-element-picker__footer">

			<button
				type="button"
				class="button"
				data-kidia-close-picker
			>
				<?php
					esc_html_e(
						'Cancel',
						'kidia-mobile-cms'
					);
					?>
			</button>

		</div>

	</div>

</div>

<div
	id="kidia-create-element-modal"
	class="kidia-create-element-modal"
	hidden
	aria-hidden="true"
>

	<div
		class="kidia-create-element-modal__overlay"
		data-kidia-close-create-modal
	></div>

	<div
		class="kidia-create-element-modal__panel"
		role="dialog"
		aria-modal="true"
		aria-labelledby="kidia-create-element-title"
	>

		<div class="kidia-create-element-modal__header">

			<h2 id="kidia-create-element-title">
				<?php
					esc_html_e(
						'Create Element',
						'kidia-mobile-cms'
					);
					?>
			</h2>

			<button
				type="button"
				class="button-link"
				data-kidia-close-create-modal
				aria-label="<?php
					echo esc_attr__(
						'Close',
						'kidia-mobile-cms'
					);
				?>"
			>
				<span class="dashicons dashicons-no-alt"></span>
			</button>

		</div>

		<div class="kidia-create-element-modal__body">

			<label for="kidia-create-element-name">

				<strong>
					<?php
						esc_html_e(
							'Element Name',
							'kidia-mobile-cms'
						);
						?>
				</strong>

			</label>

			<input
				type="text"
				id="kidia-create-element-name"
				class="regular-text"
				autocomplete="off"
			>

			<p
				id="kidia-create-element-error"
				class="kidia-create-element-modal__error"
				hidden
			>
				<?php
					esc_html_e(
						'Please enter an element name.',
						'kidia-mobile-cms'
					);
					?>
			</p>

		</div>

		<div class="kidia-create-element-modal__footer">

			<button
				type="button"
				class="button"
				data-kidia-close-create-modal
			>
				<?php
					esc_html_e(
						'Cancel',
						'kidia-mobile-cms'
					);
					?>
			</button>

			<button
				type="button"
				class="button button-primary"
				id="kidia-create-element-submit"
			>
				<?php
					esc_html_e(
						'Create and Add',
						'kidia-mobile-cms'
					);
					?>
			</button>

		</div>

	</div>

</div>

<?php foreach ( $definitions as $type => $definition ) : ?>

	<?php
	$type = sanitize_key(
		(string) (
			$definition['type']
			?? $type
		)
	);

	if (
		'' === $type
		|| empty( $definition['available'] )
	) {
		continue;
	}

	$block =
		Kidia_Mobile_Block_Registry::get_block(
			$type
		);

	if (
		! $block instanceof Kidia_Mobile_Block
	) {
		continue;
	}

	$default_block_data =
		$block->create_instance();

	if ( ! is_array( $default_block_data ) ) {
		continue;
	}

	$default_block_data['id'] =
		'__BLOCK_ID__';

	$default_block_data['library_id'] =
		'__LIBRARY_ID__';

	$default_block_data['name'] =
		'__BLOCK_NAME__';

	$default_block_data['order'] =
		'__ORDER__';

	$default_block_data['status'] =
		'published';

	$index = 987654321;

	$block_data = $default_block_data;
	?>

	<script
		type="text/html"
		id="tmpl-kidia-block-<?php echo esc_attr( $type ); ?>"
	>
		<?php
		include
			KIDIA_MOBILE_CMS_PATH .
			'admin/templates/block-template.php';
		?>
	</script>

	<?php foreach ( $library_items[ $type ] ?? array() as $library_item ) : ?>

		<?php
		if (
			! is_array( $library_item )
			|| empty( $library_item['id'] )
		) {
			continue;
		}

		$library_id = sanitize_key(
			(string) $library_item['id']
		);

		$block_data = array(
			'id'         => '__BLOCK_ID__',
			'library_id' => $library_id,
			'type'       => $type,
			'name'       => ! empty( $library_item['name'] )
				? sanitize_text_field(
					(string) $library_item['name']
				)
				: $block->get_label(),
			'enabled'    => ! isset( $library_item['enabled'] )
				|| ! empty( $library_item['enabled'] ),
			'status'     => 'published' === ( $library_item['status'] ?? 'published' )
				? 'published'
				: 'draft',
			'order'      => '__ORDER__',
			'settings'   => isset( $library_item['settings'] )
				&& is_array( $library_item['settings'] )
					? $library_item['settings']
					: $block->get_default_settings(),
		);

		$index = 987654321;
		?>

		<script
			type="text/html"
			id="<?php
				echo esc_attr(
					'tmpl-kidia-library-' .
					$type .
					'-' .
					$library_id
				);
			?>"
		>
			<?php
			include
				KIDIA_MOBILE_CMS_PATH .
				'admin/templates/block-template.php';
			?>
		</script>

	<?php endforeach; ?>

<?php endforeach; ?>
