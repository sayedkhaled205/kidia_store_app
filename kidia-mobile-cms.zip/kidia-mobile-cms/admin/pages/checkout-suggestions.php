<?php
defined( 'ABSPATH' ) || exit;
?>
<div class="wrap kidia-page-builder">
	<header class="kidia-page-builder__heading">
		<h1><?php esc_html_e( 'Checkout Suggestions', 'kidia-mobile-cms' ); ?></h1>
		<p><?php esc_html_e( 'Offer useful add-on products before the customer places the order.', 'kidia-mobile-cms' ); ?></p>
	</header>
	<?php if ( isset( $_GET['updated'] ) ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Checkout Suggestions saved successfully.', 'kidia-mobile-cms' ); ?></p></div>
	<?php endif; ?>
	<div class="kidia-page-workspace kidia-commerce-preview-workspace">
		<aside class="kidia-page-preview">
			<div class="kidia-page-phone"><div class="kidia-page-phone__speaker"></div><div id="kidia-commerce-preview" class="kidia-page-phone__screen kidia-app-preview" data-preview-kind="checkout"></div></div>
			<p><?php esc_html_e( 'Live mobile preview', 'kidia-mobile-cms' ); ?></p>
		</aside>
		<form class="kidia-page-editor kidia-commerce-preview-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="kidia_mobile_save_checkout_suggestions">
			<?php wp_nonce_field( 'kidia_mobile_save_checkout_suggestions', 'kidia_mobile_checkout_suggestions_nonce' ); ?>
			<div class="kidia-page-toolbar"><strong><?php esc_html_e( 'Checkout Suggestions', 'kidia-mobile-cms' ); ?></strong><?php submit_button( __( 'Save Suggestions', 'kidia-mobile-cms' ), 'primary', 'submit', false ); ?></div>
			<section class="kidia-page-card is-open">
				<div class="kidia-page-card__header">
					<div><span class="dashicons dashicons-cart"></span><strong><?php esc_html_e( 'Suggested Products', 'kidia-mobile-cms' ); ?></strong></div>
					<label class="kidia-page-master-toggle"><input type="hidden" name="suggestions[enabled]" value="0"><input type="checkbox" name="suggestions[enabled]" value="1" <?php checked( ! empty( $settings['enabled'] ) ); ?>><span><?php esc_html_e( 'Show', 'kidia-mobile-cms' ); ?></span></label>
				</div>
				<div class="kidia-page-card__body">
					<div class="kidia-page-fields kidia-checkout-suggestions-fields">
						<div class="kidia-settings-section-title kidia-settings-section-title--suggested-appearance"><?php esc_html_e( 'Content & Appearance', 'kidia-mobile-cms' ); ?></div>
						<div class="kidia-page-field"><label><?php esc_html_e( 'Image ratio', 'kidia-mobile-cms' ); ?></label><input type="number" step="0.1" name="suggestions[image_ratio]" value="<?php echo esc_attr( (string) $settings['image_ratio'] ); ?>"></div>
						<div class="kidia-page-field"><label><?php esc_html_e( 'Section title', 'kidia-mobile-cms' ); ?></label><input type="text" name="suggestions[title]" value="<?php echo esc_attr( (string) $settings['title'] ); ?>"></div>
						<div class="kidia-page-field"><label><?php esc_html_e( 'Add button label', 'kidia-mobile-cms' ); ?></label><input type="text" name="suggestions[button_label]" value="<?php echo esc_attr( (string) $settings['button_label'] ); ?>"></div>
						<div class="kidia-page-field"><label><?php esc_html_e( 'Card style', 'kidia-mobile-cms' ); ?></label><select name="suggestions[card_style]"><?php foreach ( array( 'minimal' => 'Minimal', 'no_shadow' => 'No shadow', 'outlined' => 'Outlined', 'elevated' => 'Elevated' ) as $value => $label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $settings['card_style'], $value ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></div>
						<div class="kidia-page-field"><label><?php esc_html_e( 'Card radius', 'kidia-mobile-cms' ); ?></label><input type="number" name="suggestions[card_radius]" value="<?php echo esc_attr( (string) $settings['card_radius'] ); ?>"></div>
						<?php foreach ( array( 'show_price' => 'Show price', 'show_regular_price' => 'Show regular price', 'show_rating' => 'Show rating' ) as $key => $label ) : ?>
							<div class="kidia-page-field"><label><?php echo esc_html( $label ); ?></label><label class="kidia-page-toggle"><input type="hidden" name="suggestions[<?php echo esc_attr( $key ); ?>]" value="0"><input type="checkbox" name="suggestions[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( ! empty( $settings[ $key ] ) ); ?>><b><?php esc_html_e( 'Show', 'kidia-mobile-cms' ); ?></b></label></div>
						<?php endforeach; ?>
						<?php foreach ( array( 'button_color' => 'Button color', 'button_text_color' => 'Button text color' ) as $key => $label ) : ?>
							<div class="kidia-page-field"><label><?php echo esc_html( $label ); ?></label><input type="color" name="suggestions[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $settings[ $key ] ); ?>"></div>
						<?php endforeach; ?>

						<div class="kidia-settings-section-title kidia-settings-section-title--suggested-products-actions"><?php esc_html_e( 'Products & Actions', 'kidia-mobile-cms' ); ?></div>
						<div class="kidia-page-field"><label><?php esc_html_e( 'Source', 'kidia-mobile-cms' ); ?></label><select name="suggestions[source]"><?php foreach ( array( 'latest' => 'Latest', 'featured' => 'Featured', 'on_sale' => 'On sale', 'category' => 'Category', 'manual' => 'Manual IDs' ) as $value => $label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $settings['source'], $value ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></div>
						<?php foreach ( array( 'category_id' => 'Category ID', 'manual_product_ids' => 'Manual Product IDs', 'limit' => 'Product limit', 'columns' => 'Columns' ) as $key => $label ) : ?>
							<div class="kidia-page-field"><label><?php echo esc_html( $label ); ?></label><input type="<?php echo in_array( $key, array( 'category_id', 'limit', 'columns' ), true ) ? 'number' : 'text'; ?>" name="suggestions[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( (string) $settings[ $key ] ); ?>"></div>
						<?php endforeach; ?>
					</div>
				</div>
			</section>
		</form>
	</div>
</div>
