<?php
/**
 * Brand Carousel admin module.
 *
 * @package Kidia_Mobile_CMS
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'Kidia_Mobile_CMS_Brand_Carousel', false ) ) {
	return;
}

final class Kidia_Mobile_CMS_Brand_Carousel {

	private const OPTION_NAME = 'kidia_mobile_brand_carousel';
	private const CAPABILITY  = 'manage_options';
	private const PAGE_SLUG   = 'kidia-mobile-brand-carousel';

	/**
	 * Registers module hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action(
			'admin_menu',
			array( $this, 'register_menu' )
		);

		add_action(
			'admin_post_kidia_mobile_save_brand_carousel',
			array( $this, 'save' )
		);

		add_filter(
			'rest_post_dispatch',
			array( $this, 'append_brand_block_to_home_layout' ),
			10,
			3
		);
	}

	/**
	 * Registers Brand Carousel submenu.
	 *
	 * @return void
	 */
	public function register_menu(): void {
		add_submenu_page(
			'kidia-mobile-cms',
			__( 'Brand Carousel', 'kidia-mobile-cms' ),
			__( 'Brand Carousel', 'kidia-mobile-cms' ),
			self::CAPABILITY,
			self::PAGE_SLUG,
			array( $this, 'render_page' )
		);
	}

	/**
	 * Renders Brand Carousel page.
	 *
	 * @return void
	 */
	public function render_page(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die(
				esc_html__(
					'You do not have permission to access this page.',
					'kidia-mobile-cms'
				)
			);
		}

		wp_enqueue_media();

		$config = $this->get_config();
		$brands = $config['brands'];

		?>
		<div class="wrap kidia-brand-admin">
			<div class="kidia-brand-header">
				<div>
					<h1>
						<?php echo esc_html__( 'App Brand Carousel', 'kidia-mobile-cms' ); ?>
					</h1>

					<p>
						<?php
						echo esc_html__(
							'Manage the brands displayed on the application home page.',
							'kidia-mobile-cms'
						);
						?>
					</p>
				</div>
			</div>

			<?php if ( isset( $_GET['updated'] ) && '1' === sanitize_key( wp_unslash( $_GET['updated'] ) ) ) : ?>
				<div class="notice notice-success is-dismissible">
					<p>
						<?php
						echo esc_html__(
							'Brand Carousel saved successfully.',
							'kidia-mobile-cms'
						);
						?>
					</p>
				</div>
			<?php endif; ?>

			<form
				method="post"
				action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
			>
				<input
					type="hidden"
					name="action"
					value="kidia_mobile_save_brand_carousel"
				>

				<?php
				wp_nonce_field(
					'kidia_mobile_save_brand_carousel',
					'kidia_mobile_brand_carousel_nonce'
				);
				?>

				<div class="kidia-brand-settings">
					<div class="kidia-brand-setting-row">
						<div>
							<strong>
								<?php echo esc_html__( 'Carousel Status', 'kidia-mobile-cms' ); ?>
							</strong>

							<p>
								<?php
								echo esc_html__(
									'Show or hide the Brand Carousel in the app.',
									'kidia-mobile-cms'
								);
								?>
							</p>
						</div>

						<label class="kidia-brand-toggle">
							<input
								type="checkbox"
								name="enabled"
								value="1"
								<?php checked( true, (bool) $config['enabled'] ); ?>
							>

							<span class="kidia-brand-toggle__track"></span>
						</label>
					</div>

					<div class="kidia-brand-control">
						<label for="kidia-brand-title">
							<?php echo esc_html__( 'Section Title', 'kidia-mobile-cms' ); ?>
						</label>

						<input
							id="kidia-brand-title"
							type="text"
							name="title"
							value="<?php echo esc_attr( $config['title'] ); ?>"
						>
					</div>

					<div class="kidia-brand-control">
						<label for="kidia-brand-item-width">
							<?php echo esc_html__( 'Item Width', 'kidia-mobile-cms' ); ?>
						</label>

						<input
							id="kidia-brand-item-width"
							type="number"
							name="item_width"
							value="<?php echo esc_attr( (string) $config['item_width'] ); ?>"
							min="60"
							max="180"
							step="1"
						>
					</div>
				</div>

				<div class="kidia-brand-list-header">
					<h2>
						<?php echo esc_html__( 'Brands', 'kidia-mobile-cms' ); ?>
					</h2>

					<button
						type="button"
						class="button button-secondary"
						id="kidia-add-brand"
					>
						<?php echo esc_html__( 'Add Brand', 'kidia-mobile-cms' ); ?>
					</button>
				</div>

				<div id="kidia-brand-list">
					<?php foreach ( $brands as $index => $brand ) : ?>
						<?php $this->render_brand( $index, $brand ); ?>
					<?php endforeach; ?>
				</div>

				<div class="kidia-brand-save">
					<?php
					submit_button(
						__( 'Save Brand Carousel', 'kidia-mobile-cms' ),
						'primary',
						'submit',
						false
					);
					?>
				</div>
			</form>
		</div>

		<script type="text/html" id="tmpl-kidia-brand-item">
			<?php
			$this->render_brand(
				'__INDEX__',
				$this->get_empty_brand()
			);
			?>
		</script>

		<script>
			(function () {
				'use strict';

				const container = document.getElementById('kidia-brand-list');
				const addButton = document.getElementById('kidia-add-brand');
				const template = document.getElementById('tmpl-kidia-brand-item');

				if (!container || !addButton || !template) {
					return;
				}

				let index = container.children.length;

				addButton.addEventListener('click', function () {
					const html = template.innerHTML.replaceAll(
						'__INDEX__',
						String(index)
					);

					container.insertAdjacentHTML('beforeend', html);
					index += 1;
				});

				document.addEventListener('click', function (event) {
					const target = event.target;

					if (!(target instanceof HTMLElement)) {
						return;
					}

					if (target.classList.contains('kidia-remove-brand')) {
						const item = target.closest('.kidia-brand-item');

						if (item) {
							item.remove();
						}

						return;
					}

					if (!target.classList.contains('kidia-select-brand-logo')) {
						return;
					}

					const item = target.closest('.kidia-brand-item');

					if (!item || typeof wp === 'undefined' || !wp.media) {
						return;
					}

					const input = item.querySelector('.kidia-brand-logo-url');
					const preview = item.querySelector('.kidia-brand-logo-preview');

					const frame = wp.media({
						title: 'Select Brand Logo',
						button: {
							text: 'Use this logo'
						},
						multiple: false,
						library: {
							type: 'image'
						}
					});

					frame.on('select', function () {
						const attachment = frame
							.state()
							.get('selection')
							.first()
							.toJSON();

						if (input) {
							input.value = attachment.url || '';
						}

						if (preview) {
							preview.src = attachment.url || '';
							preview.style.display = attachment.url
								? 'block'
								: 'none';
						}
					});

					frame.open();
				});
			})();
		</script>

		<style>
			.kidia-brand-admin {
				max-width: 1120px;
			}

			.kidia-brand-header {
				margin-bottom: 18px;
			}

			.kidia-brand-header h1 {
				margin-bottom: 6px;
			}

			.kidia-brand-header p {
				margin: 0;
				color: #646970;
			}

			.kidia-brand-settings {
				display: grid;
				grid-template-columns: repeat(2, minmax(0, 1fr));
				gap: 18px;
				margin-bottom: 24px;
				padding: 20px;
				border: 1px solid #dcdcde;
				border-radius: 12px;
				background: #fff;
			}

			.kidia-brand-setting-row {
				grid-column: 1 / -1;
				display: flex;
				align-items: center;
				justify-content: space-between;
				gap: 24px;
				padding-bottom: 16px;
				border-bottom: 1px solid #f0f0f1;
			}

			.kidia-brand-setting-row p {
				margin: 4px 0 0;
				color: #646970;
			}

			.kidia-brand-control {
				display: flex;
				flex-direction: column;
				gap: 8px;
			}

			.kidia-brand-control label {
				font-weight: 600;
			}

			.kidia-brand-control input {
				width: 100%;
				min-height: 40px;
			}

			.kidia-brand-toggle {
				position: relative;
				display: inline-flex;
				width: 46px;
				height: 26px;
				flex: 0 0 auto;
			}

			.kidia-brand-toggle input {
				position: absolute;
				opacity: 0;
				pointer-events: none;
			}

			.kidia-brand-toggle__track {
				position: relative;
				display: block;
				width: 46px;
				height: 26px;
				border-radius: 999px;
				background: #c3c4c7;
				cursor: pointer;
				transition: 0.2s ease;
			}

			.kidia-brand-toggle__track::after {
				content: "";
				position: absolute;
				top: 3px;
				left: 3px;
				width: 20px;
				height: 20px;
				border-radius: 50%;
				background: #fff;
				box-shadow: 0 1px 3px rgba(0, 0, 0, 0.18);
				transition: 0.2s ease;
			}

			.kidia-brand-toggle input:checked + .kidia-brand-toggle__track {
				background: #2271b1;
			}

			.kidia-brand-toggle input:checked + .kidia-brand-toggle__track::after {
				transform: translateX(20px);
			}

			.kidia-brand-list-header {
				display: flex;
				align-items: center;
				justify-content: space-between;
				gap: 16px;
				margin-bottom: 14px;
			}

			.kidia-brand-list-header h2 {
				margin: 0;
			}

			.kidia-brand-item {
				margin-bottom: 18px;
				padding: 20px;
				border: 1px solid #dcdcde;
				border-radius: 12px;
				background: #fff;
			}

			.kidia-brand-item__header {
				display: flex;
				align-items: center;
				justify-content: space-between;
				gap: 16px;
				margin-bottom: 18px;
			}

			.kidia-brand-item__grid {
				display: grid;
				grid-template-columns: repeat(2, minmax(0, 1fr));
				gap: 18px;
			}

			.kidia-brand-field {
				display: flex;
				flex-direction: column;
				gap: 8px;
			}

			.kidia-brand-field label {
				font-weight: 600;
			}

			.kidia-brand-field--full {
				grid-column: 1 / -1;
			}

			.kidia-brand-field input,
			.kidia-brand-field select {
				width: 100%;
				min-height: 40px;
			}

			.kidia-brand-logo-preview {
				display: block;
				width: 160px;
				height: 110px;
				margin-top: 12px;
				border: 1px solid #dcdcde;
				border-radius: 10px;
				object-fit: contain;
				background: #fff;
			}

			.kidia-brand-save {
				display: flex;
				justify-content: flex-end;
				margin-top: 22px;
			}

			@media (max-width: 782px) {
				.kidia-brand-settings,
				.kidia-brand-item__grid {
					grid-template-columns: 1fr;
				}

				.kidia-brand-field--full,
				.kidia-brand-setting-row {
					grid-column: auto;
				}
			}
		</style>
		<?php
	}

	/**
	 * Saves Brand Carousel configuration.
	 *
	 * @return void
	 */
	public function save(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die(
				esc_html__(
					'You do not have permission to perform this action.',
					'kidia-mobile-cms'
				)
			);
		}

		check_admin_referer(
			'kidia_mobile_save_brand_carousel',
			'kidia_mobile_brand_carousel_nonce'
		);

		$submitted_brands = isset( $_POST['brands'] )
			? wp_unslash( $_POST['brands'] )
			: array();

		if ( ! is_array( $submitted_brands ) ) {
			$submitted_brands = array();
		}

		$brands = array();

		foreach ( $submitted_brands as $index => $submitted_brand ) {
			if ( ! is_array( $submitted_brand ) ) {
				continue;
			}

			$name = isset( $submitted_brand['name'] )
				? sanitize_text_field( $submitted_brand['name'] )
				: '';

			$logo_url = isset( $submitted_brand['logo_url'] )
				? esc_url_raw( $submitted_brand['logo_url'] )
				: '';

			if ( empty( $name ) || empty( $logo_url ) ) {
				continue;
			}

			$action_type = isset( $submitted_brand['action_type'] )
				? sanitize_key( $submitted_brand['action_type'] )
				: '';

			$allowed_action_types = array(
				'',
				'category',
				'collection',
				'search',
				'external',
			);

			if ( ! in_array( $action_type, $allowed_action_types, true ) ) {
				$action_type = '';
			}

			$brands[] = array(
				'id'           => absint( $index ) + 1,
				'name'         => $name,
				'logo_url'     => $logo_url,
				'action_type'  => $action_type,
				'action_value' => isset( $submitted_brand['action_value'] )
					? sanitize_text_field( $submitted_brand['action_value'] )
					: '',
			);
		}

		$item_width = isset( $_POST['item_width'] )
			? absint( $_POST['item_width'] )
			: 92;

		$item_width = max( 60, min( 180, $item_width ) );

		update_option(
			self::OPTION_NAME,
			array(
				'enabled'    => isset( $_POST['enabled'] ),
				'title'      => isset( $_POST['title'] )
					? sanitize_text_field( $_POST['title'] )
					: 'علامات نحبها',
				'item_width' => $item_width,
				'updated_at' => gmdate( 'c' ),
				'brands'     => $brands,
			),
			false
		);

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => self::PAGE_SLUG,
					'updated' => '1',
				),
				admin_url( 'admin.php' )
			)
		);

		exit;
	}

	/**
	 * Injects Brand Carousel into Home Layout response.
	 *
	 * @param WP_HTTP_Response|WP_Error $response REST response.
	 * @param WP_REST_Server            $server   REST server.
	 * @param WP_REST_Request           $request  REST request.
	 *
	 * @return WP_HTTP_Response|WP_Error
	 */
	public function append_brand_block_to_home_layout(
		$response,
		WP_REST_Server $server,
		WP_REST_Request $request
	) {
		unset( $server );

		if ( '/kidia/v1/home-layout' !== $request->get_route() ) {
			return $response;
		}

		if ( ! $response instanceof WP_REST_Response ) {
			return $response;
		}

		$brand_block = $this->build_brand_block();

		if ( null === $brand_block ) {
			return $response;
		}

		$data = $response->get_data();

		if (
			! is_array( $data )
			|| ! isset( $data['blocks'] )
			|| ! is_array( $data['blocks'] )
		) {
			return $response;
		}

		$blocks = array_values(
			array_filter(
				$data['blocks'],
				static function ( $block ): bool {
					return ! (
						is_array( $block )
						&& isset( $block['type'] )
						&& 'brand_carousel' === $block['type']
					);
				}
			)
		);

		$inserted = false;
		$result   = array();

		foreach ( $blocks as $block ) {
			if (
				! $inserted
				&& is_array( $block )
				&& isset( $block['type'] )
				&& 'spacer' === $block['type']
			) {
				$result[] = $brand_block;
				$inserted = true;
			}

			$result[] = $block;
		}

		if ( ! $inserted ) {
			$result[] = $brand_block;
		}

		$data['blocks'] = $result;

		$response->set_data( $data );

		return $response;
	}

	/**
	 * Builds Brand Carousel block.
	 *
	 * @return array<string, mixed>|null
	 */
	private function build_brand_block(): ?array {
		$config = get_option(
			self::OPTION_NAME,
			array()
		);

		if (
			! is_array( $config )
			|| empty( $config['enabled'] )
			|| empty( $config['brands'] )
			|| ! is_array( $config['brands'] )
		) {
			return null;
		}

		$items = array();

		foreach ( $config['brands'] as $brand ) {
			if (
				! is_array( $brand )
				|| empty( $brand['name'] )
				|| empty( $brand['logo_url'] )
			) {
				continue;
			}

			$items[] = array(
				'id'       => isset( $brand['id'] )
					? absint( $brand['id'] )
					: count( $items ) + 1,
				'name'     => wp_strip_all_tags( $brand['name'] ),
				'logo_url' => esc_url_raw( $brand['logo_url'] ),
				'action'   => $this->build_action(
					$brand['action_type'] ?? '',
					$brand['action_value'] ?? ''
				),
			);
		}

		if ( empty( $items ) ) {
			return null;
		}

		return array(
			'id'      => 'home_brand_carousel',
			'type'    => 'brand_carousel',
			'enabled' => true,
			'data'    => array(
				'title'      => ! empty( $config['title'] )
					? wp_strip_all_tags( $config['title'] )
					: 'علامات نحبها',
				'item_width' => isset( $config['item_width'] )
					? max( 60, min( 180, absint( $config['item_width'] ) ) )
					: 92,
				'items'      => $items,
			),
		);
	}

	/**
	 * Builds action data.
	 *
	 * @param mixed $type  Action type.
	 * @param mixed $value Action value.
	 *
	 * @return array<string, string>|null
	 */
	private function build_action( $type, $value ): ?array {
		$type  = sanitize_key( (string) $type );
		$value = trim( (string) $value );

		$allowed_types = array(
			'category',
			'collection',
			'search',
			'external',
		);

		if (
			empty( $type )
			|| empty( $value )
			|| ! in_array( $type, $allowed_types, true )
		) {
			return null;
		}

		if ( 'external' === $type ) {
			$value = esc_url_raw( $value );

			if ( empty( $value ) ) {
				return null;
			}
		} else {
			$value = sanitize_text_field( $value );
		}

		return array(
			'type'  => $type,
			'value' => $value,
		);
	}

	/**
	 * Returns saved configuration.
	 *
	 * @return array<string, mixed>
	 */
	private function get_config(): array {
		$config = get_option(
			self::OPTION_NAME,
			array()
		);

		if ( ! is_array( $config ) ) {
			$config = array();
		}

		$brands = isset( $config['brands'] ) && is_array( $config['brands'] )
			? array_values( $config['brands'] )
			: array();

		if ( empty( $brands ) ) {
			$brands = array(
				$this->get_empty_brand(),
			);
		}

		return array(
			'enabled'    => isset( $config['enabled'] )
				? (bool) $config['enabled']
				: true,
			'title'      => isset( $config['title'] )
				? (string) $config['title']
				: 'علامات نحبها',
			'item_width' => isset( $config['item_width'] )
				? absint( $config['item_width'] )
				: 92,
			'brands'     => $brands,
		);
	}

	/**
	 * Returns empty brand.
	 *
	 * @return array<string, mixed>
	 */
	private function get_empty_brand(): array {
		return array(
			'name'         => '',
			'logo_url'     => '',
			'action_type'  => '',
			'action_value' => '',
		);
	}

	/**
	 * Renders brand editor.
	 *
	 * @param int|string           $index Brand index.
	 * @param array<string, mixed> $brand Brand data.
	 *
	 * @return void
	 */
	private function render_brand( $index, array $brand ): void {
		$logo_url = isset( $brand['logo_url'] )
			? (string) $brand['logo_url']
			: '';

		?>
		<div class="kidia-brand-item">
			<div class="kidia-brand-item__header">
				<strong>
					<?php echo esc_html__( 'Brand', 'kidia-mobile-cms' ); ?>
				</strong>

				<button
					type="button"
					class="button-link-delete kidia-remove-brand"
				>
					<?php echo esc_html__( 'Remove', 'kidia-mobile-cms' ); ?>
				</button>
			</div>

			<div class="kidia-brand-item__grid">
				<div class="kidia-brand-field">
					<label>
						<?php echo esc_html__( 'Brand Name', 'kidia-mobile-cms' ); ?>
					</label>

					<input
						type="text"
						name="brands[<?php echo esc_attr( (string) $index ); ?>][name]"
						value="<?php echo esc_attr( (string) $brand['name'] ); ?>"
					>
				</div>

				<div class="kidia-brand-field kidia-brand-field--full">
					<label>
						<?php echo esc_html__( 'Brand Logo', 'kidia-mobile-cms' ); ?>
					</label>

					<input
						type="url"
						class="kidia-brand-logo-url"
						name="brands[<?php echo esc_attr( (string) $index ); ?>][logo_url]"
						value="<?php echo esc_attr( $logo_url ); ?>"
					>

					<button
						type="button"
						class="button kidia-select-brand-logo"
					>
						<?php echo esc_html__( 'Select from Media Library', 'kidia-mobile-cms' ); ?>
					</button>

					<img
						class="kidia-brand-logo-preview"
						src="<?php echo esc_url( $logo_url ); ?>"
						alt=""
						<?php echo empty( $logo_url ) ? 'style="display:none;"' : ''; ?>
					>
				</div>

				<div class="kidia-brand-field">
					<label>
						<?php echo esc_html__( 'Action Type', 'kidia-mobile-cms' ); ?>
					</label>

					<select
						name="brands[<?php echo esc_attr( (string) $index ); ?>][action_type]"
					>
						<option value="">
							<?php echo esc_html__( 'No Action', 'kidia-mobile-cms' ); ?>
						</option>

						<option value="category" <?php selected( 'category', $brand['action_type'] ); ?>>
							<?php echo esc_html__( 'Category', 'kidia-mobile-cms' ); ?>
						</option>

						<option value="collection" <?php selected( 'collection', $brand['action_type'] ); ?>>
							<?php echo esc_html__( 'Collection', 'kidia-mobile-cms' ); ?>
						</option>

						<option value="search" <?php selected( 'search', $brand['action_type'] ); ?>>
							<?php echo esc_html__( 'Search', 'kidia-mobile-cms' ); ?>
						</option>

						<option value="external" <?php selected( 'external', $brand['action_type'] ); ?>>
							<?php echo esc_html__( 'External URL', 'kidia-mobile-cms' ); ?>
						</option>
					</select>
				</div>

				<div class="kidia-brand-field">
					<label>
						<?php echo esc_html__( 'Action Value', 'kidia-mobile-cms' ); ?>
					</label>

					<input
						type="text"
						name="brands[<?php echo esc_attr( (string) $index ); ?>][action_value]"
						value="<?php echo esc_attr( (string) $brand['action_value'] ); ?>"
					>
				</div>
			</div>
		</div>
		<?php
	}
}