<?php
/**
 * Hero Slider admin module.
 *
 * @package Kidia_Mobile_CMS
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'Kidia_Mobile_CMS_Hero_Slider', false ) ) {
	return;
}

final class Kidia_Mobile_CMS_Hero_Slider {

	private const OPTION_NAME = 'kidia_mobile_hero_slider';
	private const CAPABILITY  = 'manage_options';
	private const PAGE_SLUG   = 'kidia-mobile-hero-slider';

	public function register(): void {
		add_action(
			'admin_menu',
			array( $this, 'register_menu' )
		);

		add_action(
			'admin_post_kidia_mobile_save_hero_slider',
			array( $this, 'save' )
		);
	}

	public function register_menu(): void {
		add_submenu_page(
			'kidia-mobile-cms',
			__( 'Hero Slider', 'kidia-mobile-cms' ),
			__( 'Hero Slider', 'kidia-mobile-cms' ),
			self::CAPABILITY,
			self::PAGE_SLUG,
			array( $this, 'render_page' )
		);
	}

	public function render_page(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die(
				esc_html__(
					'You do not have permission to access this page.',
					'kidia-mobile-cms'
				)
			);
		}

		wp_enqueue_media();

		$config = $this->get_config();
		$slides = $config['slides'];

		?>
		<div class="wrap kidia-hero-admin">
			<div class="kidia-hero-admin__header">
				<div>
					<h1>
						<?php echo esc_html__( 'App Hero Slider', 'kidia-mobile-cms' ); ?>
					</h1>

					<p>
						<?php
						echo esc_html__(
							'Manage the main slider displayed at the top of the application home page.',
							'kidia-mobile-cms'
						);
						?>
					</p>
				</div>
			</div>

			<?php if ( isset( $_GET['updated'] ) && '1' === sanitize_key( wp_unslash( $_GET['updated'] ) ) ) : ?>
				<div class="notice notice-success is-dismissible">
					<p>
						<?php
						echo esc_html__(
							'Hero Slider saved successfully.',
							'kidia-mobile-cms'
						);
						?>
					</p>
				</div>
			<?php endif; ?>

			<form
				method="post"
				action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
			>
				<input
					type="hidden"
					name="action"
					value="kidia_mobile_save_hero_slider"
				>

				<?php
				wp_nonce_field(
					'kidia_mobile_save_hero_slider',
					'kidia_mobile_hero_slider_nonce'
				);
				?>

				<div class="kidia-hero-settings">
					<div class="kidia-hero-setting">
						<div>
							<strong>
								<?php echo esc_html__( 'Slider Status', 'kidia-mobile-cms' ); ?>
							</strong>

							<p>
								<?php
								echo esc_html__(
									'Show or hide the Hero Slider in the app.',
									'kidia-mobile-cms'
								);
								?>
							</p>
						</div>

						<label class="kidia-toggle">
							<input
								type="checkbox"
								name="enabled"
								value="1"
								<?php checked( true, (bool) $config['enabled'] ); ?>
							>

							<span class="kidia-toggle__track"></span>
						</label>
					</div>

					<div class="kidia-hero-setting">
						<div>
							<strong>
								<?php echo esc_html__( 'Automatic Sliding', 'kidia-mobile-cms' ); ?>
							</strong>

							<p>
								<?php
								echo esc_html__(
									'Automatically move between slides.',
									'kidia-mobile-cms'
								);
								?>
							</p>
						</div>

						<label class="kidia-toggle">
							<input
								type="checkbox"
								name="auto_play"
								value="1"
								<?php checked( true, (bool) $config['auto_play'] ); ?>
							>

							<span class="kidia-toggle__track"></span>
						</label>
					</div>

					<div class="kidia-hero-settings__grid">
						<div class="kidia-control">
							<label for="kidia-hero-interval">
								<?php echo esc_html__( 'Interval', 'kidia-mobile-cms' ); ?>
							</label>

							<div class="kidia-control__inline">
								<input
									id="kidia-hero-interval"
									type="number"
									name="interval_ms"
									value="<?php echo esc_attr( (string) $config['interval_ms'] ); ?>"
									min="2000"
									max="15000"
									step="500"
								>

								<span>ms</span>
							</div>
						</div>

						<div class="kidia-control">
							<label for="kidia-hero-aspect-ratio">
								<?php echo esc_html__( 'Aspect Ratio', 'kidia-mobile-cms' ); ?>
							</label>

							<input
								id="kidia-hero-aspect-ratio"
								type="number"
								name="aspect_ratio"
								value="<?php echo esc_attr( (string) $config['aspect_ratio'] ); ?>"
								min="1"
								max="4"
								step="0.1"
							>
						</div>
					</div>
				</div>

				<div class="kidia-hero-slides-header">
					<h2>
						<?php echo esc_html__( 'Slides', 'kidia-mobile-cms' ); ?>
					</h2>

					<button
						type="button"
						class="button button-secondary"
						id="kidia-add-hero-slide"
					>
						<?php echo esc_html__( 'Add Slide', 'kidia-mobile-cms' ); ?>
					</button>
				</div>

				<div id="kidia-hero-slides">
					<?php foreach ( $slides as $index => $slide ) : ?>
						<?php $this->render_slide( $index, $slide ); ?>
					<?php endforeach; ?>
				</div>

				<div class="kidia-hero-save">
					<?php
					submit_button(
						__( 'Save Hero Slider', 'kidia-mobile-cms' ),
						'primary',
						'submit',
						false
					);
					?>
				</div>
			</form>
		</div>

		<script type="text/html" id="tmpl-kidia-hero-slide">
			<?php
			$this->render_slide(
				'__INDEX__',
				$this->get_empty_slide()
			);
			?>
		</script>

		<script>
			(function () {
				'use strict';

				const container = document.getElementById('kidia-hero-slides');
				const addButton = document.getElementById('kidia-add-hero-slide');
				const template = document.getElementById('tmpl-kidia-hero-slide');

				if (!container || !addButton || !template) {
					return;
				}

				let index = container.children.length;

				addButton.addEventListener('click', function () {
					const html = template.innerHTML.replaceAll(
						'__INDEX__',
						String(index)
					);

					container.insertAdjacentHTML('beforeend', html);
					index += 1;
				});

				document.addEventListener('click', function (event) {
					const target = event.target;

					if (!(target instanceof HTMLElement)) {
						return;
					}

					if (target.classList.contains('kidia-remove-slide')) {
						const slide = target.closest('.kidia-hero-slide');

						if (slide) {
							slide.remove();
						}

						return;
					}

					if (!target.classList.contains('kidia-select-hero-image')) {
						return;
					}

					const slide = target.closest('.kidia-hero-slide');

					if (!slide || typeof wp === 'undefined' || !wp.media) {
						return;
					}

					const input = slide.querySelector('.kidia-hero-image-url');
					const preview = slide.querySelector('.kidia-hero-image-preview');

					const frame = wp.media({
						title: 'Select Hero Image',
						button: {
							text: 'Use this image'
						},
						multiple: false,
						library: {
							type: 'image'
						}
					});

					frame.on('select', function () {
						const attachment = frame
							.state()
							.get('selection')
							.first()
							.toJSON();

						if (input) {
							input.value = attachment.url || '';
						}

						if (preview) {
							preview.src = attachment.url || '';
							preview.style.display = attachment.url
								? 'block'
								: 'none';
						}
					});

					frame.open();
				});
			})();
		</script>

		<style>
			.kidia-hero-admin {
				max-width: 1120px;
			}

			.kidia-hero-admin__header {
				display: flex;
				align-items: flex-start;
				justify-content: space-between;
				gap: 24px;
				margin-bottom: 18px;
			}

			.kidia-hero-admin__header h1 {
				margin-bottom: 6px;
			}

			.kidia-hero-admin__header p {
				margin: 0;
				color: #646970;
			}

			.kidia-hero-settings {
				margin-bottom: 24px;
				padding: 20px;
				border: 1px solid #dcdcde;
				border-radius: 12px;
				background: #fff;
			}

			.kidia-hero-setting {
				display: flex;
				align-items: center;
				justify-content: space-between;
				gap: 24px;
				padding: 14px 0;
				border-bottom: 1px solid #f0f0f1;
			}

			.kidia-hero-setting:last-of-type {
				border-bottom: 0;
			}

			.kidia-hero-setting p {
				margin: 4px 0 0;
				color: #646970;
			}

			.kidia-hero-settings__grid {
				display: grid;
				grid-template-columns: repeat(2, minmax(0, 1fr));
				gap: 18px;
				margin-top: 18px;
			}

			.kidia-control {
				display: flex;
				flex-direction: column;
				gap: 8px;
			}

			.kidia-control label {
				font-weight: 600;
			}

			.kidia-control input[type="number"] {
				width: 100%;
				max-width: 220px;
			}

			.kidia-control__inline {
				display: flex;
				align-items: center;
				gap: 8px;
			}

			.kidia-toggle {
				position: relative;
				display: inline-flex;
				align-items: center;
				width: 46px;
				height: 26px;
				flex: 0 0 auto;
			}

			.kidia-toggle input {
				position: absolute;
				opacity: 0;
				pointer-events: none;
			}

			.kidia-toggle__track {
				position: relative;
				display: block;
				width: 46px;
				height: 26px;
				border-radius: 999px;
				background: #c3c4c7;
				transition: 0.2s ease;
				cursor: pointer;
			}

			.kidia-toggle__track::after {
				content: "";
				position: absolute;
				top: 3px;
				left: 3px;
				width: 20px;
				height: 20px;
				border-radius: 50%;
				background: #fff;
				box-shadow: 0 1px 3px rgba(0, 0, 0, 0.18);
				transition: 0.2s ease;
			}

			.kidia-toggle input:checked + .kidia-toggle__track {
				background: #2271b1;
			}

			.kidia-toggle input:checked + .kidia-toggle__track::after {
				transform: translateX(20px);
			}

			.kidia-hero-slides-header {
				display: flex;
				align-items: center;
				justify-content: space-between;
				gap: 16px;
				margin-bottom: 14px;
			}

			.kidia-hero-slides-header h2 {
				margin: 0;
			}

			.kidia-hero-slide {
				margin: 0 0 18px;
				padding: 20px;
				border: 1px solid #dcdcde;
				border-radius: 12px;
				background: #fff;
				box-shadow: 0 1px 2px rgba(0, 0, 0, 0.03);
			}

			.kidia-hero-slide__header {
				display: flex;
				align-items: center;
				justify-content: space-between;
				gap: 16px;
				margin-bottom: 18px;
			}

			.kidia-hero-slide__header strong {
				font-size: 15px;
			}

			.kidia-hero-slide__grid {
				display: grid;
				grid-template-columns: repeat(2, minmax(0, 1fr));
				gap: 18px;
			}

			.kidia-hero-field {
				display: flex;
				flex-direction: column;
				gap: 8px;
			}

			.kidia-hero-field label {
				font-weight: 600;
			}

			.kidia-hero-field--full {
				grid-column: 1 / -1;
			}

			.kidia-hero-field input[type="text"],
			.kidia-hero-field input[type="url"],
			.kidia-hero-field select {
				width: 100%;
				min-height: 40px;
			}

			.kidia-hero-enabled-row {
				display: flex;
				align-items: center;
				justify-content: space-between;
				gap: 16px;
				padding: 12px 14px;
				border-radius: 8px;
				background: #f6f7f7;
			}

			.kidia-hero-image-actions {
				display: flex;
				align-items: center;
				gap: 10px;
				flex-wrap: wrap;
			}

			.kidia-hero-image-preview {
				display: block;
				width: 100%;
				max-width: 520px;
				height: 220px;
				margin-top: 12px;
				border: 1px solid #dcdcde;
				border-radius: 12px;
				object-fit: cover;
				background: #f0f0f1;
			}

			.kidia-hero-save {
				display: flex;
				justify-content: flex-end;
				margin-top: 22px;
			}

			.kidia-hero-save .button-primary {
				min-height: 42px;
				padding: 0 20px;
			}

			@media (max-width: 782px) {
				.kidia-hero-settings__grid,
				.kidia-hero-slide__grid {
					grid-template-columns: 1fr;
				}

				.kidia-hero-field--full {
					grid-column: auto;
				}

				.kidia-hero-setting,
				.kidia-hero-slides-header {
					align-items: flex-start;
				}
			}
		</style>
		<?php
	}

	public function save(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die(
				esc_html__(
					'You do not have permission to perform this action.',
					'kidia-mobile-cms'
				)
			);
		}

		check_admin_referer(
			'kidia_mobile_save_hero_slider',
			'kidia_mobile_hero_slider_nonce'
		);

		$submitted_slides = isset( $_POST['slides'] )
			? wp_unslash( $_POST['slides'] )
			: array();

		if ( ! is_array( $submitted_slides ) ) {
			$submitted_slides = array();
		}

		$slides = array();

		foreach ( $submitted_slides as $index => $submitted_slide ) {
			if ( ! is_array( $submitted_slide ) ) {
				continue;
			}

			$image_url = isset( $submitted_slide['image_url'] )
				? esc_url_raw( $submitted_slide['image_url'] )
				: '';

			if ( empty( $image_url ) ) {
				continue;
			}

			$action_type = isset( $submitted_slide['action_type'] )
				? sanitize_key( $submitted_slide['action_type'] )
				: '';

			$allowed_action_types = array(
				'',
				'product',
				'category',
				'collection',
				'search',
				'external',
			);

			if ( ! in_array( $action_type, $allowed_action_types, true ) ) {
				$action_type = '';
			}

			$slides[] = array(
				'id'           => 'hero_slide_' . ( absint( $index ) + 1 ),
				'enabled'      => isset( $submitted_slide['enabled'] ),
				'image_url'    => $image_url,
				'title'        => isset( $submitted_slide['title'] )
					? sanitize_text_field( $submitted_slide['title'] )
					: '',
				'subtitle'     => isset( $submitted_slide['subtitle'] )
					? sanitize_textarea_field( $submitted_slide['subtitle'] )
					: '',
				'action_type'  => $action_type,
				'action_value' => isset( $submitted_slide['action_value'] )
					? sanitize_text_field( $submitted_slide['action_value'] )
					: '',
			);
		}

		$interval_ms = isset( $_POST['interval_ms'] )
			? absint( $_POST['interval_ms'] )
			: 4500;

		$interval_ms = max( 2000, min( 15000, $interval_ms ) );

		$aspect_ratio = isset( $_POST['aspect_ratio'] )
			? (float) $_POST['aspect_ratio']
			: 1.8;

		$aspect_ratio = max( 1, min( 4, $aspect_ratio ) );

		update_option(
			self::OPTION_NAME,
			array(
				'enabled'      => isset( $_POST['enabled'] ),
				'auto_play'    => isset( $_POST['auto_play'] ),
				'interval_ms'  => $interval_ms,
				'aspect_ratio' => $aspect_ratio,
				'updated_at'   => gmdate( 'c' ),
				'slides'       => $slides,
			),
			false
		);

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => self::PAGE_SLUG,
					'updated' => '1',
				),
				admin_url( 'admin.php' )
			)
		);

		exit;
	}

	private function get_config(): array {
		$config = get_option(
			self::OPTION_NAME,
			array()
		);

		if ( ! is_array( $config ) ) {
			$config = array();
		}

		$slides = isset( $config['slides'] ) && is_array( $config['slides'] )
			? array_values( $config['slides'] )
			: array();

		if ( empty( $slides ) ) {
			$slides = array(
				$this->get_empty_slide(),
			);
		}

		return array(
			'enabled'      => isset( $config['enabled'] )
				? (bool) $config['enabled']
				: true,
			'auto_play'    => isset( $config['auto_play'] )
				? (bool) $config['auto_play']
				: true,
			'interval_ms'  => isset( $config['interval_ms'] )
				? absint( $config['interval_ms'] )
				: 4500,
			'aspect_ratio' => isset( $config['aspect_ratio'] )
				? (float) $config['aspect_ratio']
				: 1.8,
			'slides'       => $slides,
		);
	}

	private function get_empty_slide(): array {
		return array(
			'enabled'      => true,
			'image_url'    => '',
			'title'        => '',
			'subtitle'     => '',
			'action_type'  => '',
			'action_value' => '',
		);
	}

	private function render_slide( $index, array $slide ): void {
		$image_url = isset( $slide['image_url'] )
			? (string) $slide['image_url']
			: '';

		?>
		<div class="kidia-hero-slide">
			<div class="kidia-hero-slide__header">
				<strong>
					<?php echo esc_html__( 'Hero Slide', 'kidia-mobile-cms' ); ?>
				</strong>

				<button
					type="button"
					class="button-link-delete kidia-remove-slide"
				>
					<?php echo esc_html__( 'Remove', 'kidia-mobile-cms' ); ?>
				</button>
			</div>

			<div class="kidia-hero-slide__grid">
				<div class="kidia-hero-field kidia-hero-field--full">
					<div class="kidia-hero-enabled-row">
						<span>
							<?php echo esc_html__( 'Slide Status', 'kidia-mobile-cms' ); ?>
						</span>

						<label class="kidia-toggle">
							<input
								type="checkbox"
								name="slides[<?php echo esc_attr( (string) $index ); ?>][enabled]"
								value="1"
								<?php checked( true, ! empty( $slide['enabled'] ) ); ?>
							>

							<span class="kidia-toggle__track"></span>
						</label>
					</div>
				</div>

				<div class="kidia-hero-field kidia-hero-field--full">
					<label>
						<?php echo esc_html__( 'Image', 'kidia-mobile-cms' ); ?>
					</label>

					<input
						type="url"
						class="kidia-hero-image-url"
						name="slides[<?php echo esc_attr( (string) $index ); ?>][image_url]"
						value="<?php echo esc_attr( $image_url ); ?>"
					>

					<div class="kidia-hero-image-actions">
						<button
							type="button"
							class="button kidia-select-hero-image"
						>
							<?php
							echo esc_html__(
								'Select from Media Library',
								'kidia-mobile-cms'
							);
							?>
						</button>
					</div>

					<img
						class="kidia-hero-image-preview"
						src="<?php echo esc_url( $image_url ); ?>"
						alt=""
						<?php echo empty( $image_url ) ? 'style="display:none;"' : ''; ?>
					>
				</div>

				<div class="kidia-hero-field">
					<label>
						<?php echo esc_html__( 'Title', 'kidia-mobile-cms' ); ?>
					</label>

					<input
						type="text"
						name="slides[<?php echo esc_attr( (string) $index ); ?>][title]"
						value="<?php echo esc_attr( (string) $slide['title'] ); ?>"
					>
				</div>

				<div class="kidia-hero-field">
					<label>
						<?php echo esc_html__( 'Subtitle', 'kidia-mobile-cms' ); ?>
					</label>

					<input
						type="text"
						name="slides[<?php echo esc_attr( (string) $index ); ?>][subtitle]"
						value="<?php echo esc_attr( (string) $slide['subtitle'] ); ?>"
					>
				</div>

				<div class="kidia-hero-field">
					<label>
						<?php echo esc_html__( 'Action Type', 'kidia-mobile-cms' ); ?>
					</label>

					<select
						name="slides[<?php echo esc_attr( (string) $index ); ?>][action_type]"
					>
						<option value="">
							<?php echo esc_html__( 'No Action', 'kidia-mobile-cms' ); ?>
						</option>

						<option value="product" <?php selected( 'product', $slide['action_type'] ); ?>>
							<?php echo esc_html__( 'Product', 'kidia-mobile-cms' ); ?>
						</option>

						<option value="category" <?php selected( 'category', $slide['action_type'] ); ?>>
							<?php echo esc_html__( 'Category', 'kidia-mobile-cms' ); ?>
						</option>

						<option value="collection" <?php selected( 'collection', $slide['action_type'] ); ?>>
							<?php echo esc_html__( 'Collection', 'kidia-mobile-cms' ); ?>
						</option>

						<option value="search" <?php selected( 'search', $slide['action_type'] ); ?>>
							<?php echo esc_html__( 'Search', 'kidia-mobile-cms' ); ?>
						</option>

						<option value="external" <?php selected( 'external', $slide['action_type'] ); ?>>
							<?php echo esc_html__( 'External URL', 'kidia-mobile-cms' ); ?>
						</option>
					</select>
				</div>

				<div class="kidia-hero-field">
					<label>
						<?php echo esc_html__( 'Action Value', 'kidia-mobile-cms' ); ?>
					</label>

					<input
						type="text"
						name="slides[<?php echo esc_attr( (string) $index ); ?>][action_value]"
						value="<?php echo esc_attr( (string) $slide['action_value'] ); ?>"
					>
				</div>
			</div>
		</div>
		<?php
	}
}