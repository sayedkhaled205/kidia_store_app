(function () {
  "use strict";
  var dragged = null;
  var previewConfig = window.kidiaChromePreviewConfig || {};
  function field(card, key) {
    var values = card ? card.querySelectorAll('[name$="[' + key + ']"]') : [];
    return values.length ? values[values.length - 1] : null;
  }
  function value(card, key, fallback) {
    var input = field(card, key);
    return input && input.value !== "" ? input.value : fallback;
  }
  function checked(card, key, fallback) {
    var input = field(card, key);
    return input ? input.checked : fallback;
  }
  function esc(text) {
    var node = document.createElement("div");
    node.textContent = text == null ? "" : String(text);
    return node.innerHTML;
  }
  function number(card, key, fallback, min, max) {
    var result = Number(value(card, key, fallback));
    if (!Number.isFinite(result)) {
      result = fallback;
    }
    return Math.max(min, Math.min(max, result));
  }
  function shadow(card) {
    var style = value(card, "shadow", "subtle");
    return style === "none"
      ? "none"
      : style === "strong"
        ? "0 4px 12px rgba(31,41,51,.20)"
        : "0 1px 5px rgba(31,41,51,.08)";
  }
  function iconDefault(item) {
    return (
      {
        back: "arrow",
        search: "rounded",
        cart: "bag",
        wishlist: "heart",
        account: "person",
        orders: "receipt",
        support: "headset",
        menu: "menu",
        home: "home",
        categories: "grid",
        share: "upload",
        like: "heart",
      }[item] || item
    );
  }
  function materialIconCode(item, variant, filled) {
    if (item === "back") {
      return variant === "chevron"
        ? "f63a"
        : variant === "rounded"
          ? "f82f"
          : "f572";
    }
    if (item === "search") {
      return variant === "classic"
        ? "e567"
        : variant === "minimal"
          ? "f1ad"
          : "f013d";
    }
    if (item === "cart") {
      if (variant === "cart") {
        return filled ? "e59c" : "f37f";
      }
      if (variant === "basket") {
        return filled ? "e59b" : "f37e";
      }
      return filled ? "e59a" : "f37d";
    }
    if (item === "wishlist" || item === "like") {
      return variant === "bookmark"
        ? filled
          ? "e0f1"
          : "e0f4"
        : filled
          ? "f738"
          : "f737";
    }
    if (item === "account") {
      if (variant === "circle") {
        return "ee35";
      }
      if (variant === "profile") {
        return "f1ac";
      }
      return filled ? "f0071" : "f006c";
    }
    if (item === "orders") {
      return variant === "box" ? "f134" : variant === "list" ? "f792" : "f2ef";
    }
    if (item === "support") {
      return variant === "chat"
        ? "f62f"
        : variant === "support"
          ? "f01f5"
          : "f0ee";
    }
    if (item === "menu") {
      return variant === "dots" ? "f8d9" : variant === "grid" ? "f7c4" : "f8b6";
    }
    if (item === "home") {
      return variant === "filled" || filled
        ? "f7f5"
        : variant === "rounded"
          ? "f244"
          : "f107";
    }
    if (item === "categories") {
      return variant === "list"
        ? "f498"
        : variant === "category"
          ? "ef37"
          : filled
            ? "f7c4"
            : "f0d7";
    }
    if (item === "share") {
      return variant === "send"
        ? "f355"
        : variant === "share"
          ? "f378"
          : "f138";
    }
    return "ef53";
  }
  function icon(card, item, filled) {
    var variant = value(card, item + "_icon_variant", iconDefault(item)),
      visual =
        { wishlist: "heart", account: "person", like: "heart", cart: "bag" }[
          item
        ] || item,
      code = materialIconCode(item, variant, !!filled);
    return (
      '<span class="kidia-app-icon kidia-app-icon--material kidia-app-icon--' +
      visual +
      " kidia-app-icon--" +
      item +
      "-" +
      esc(variant) +
      '" aria-hidden="true">&#x' +
      code +
      ";</span>"
    );
  }
  function equalWidths(count) {
    var base = Math.floor(10000 / count) / 100,
      last = Math.round((100 - base * (count - 1)) * 100) / 100;
    return Array.apply(null, { length: count }).map(function (_, index) {
      return index === count - 1 ? last : base;
    });
  }
  function makeRow(count) {
    var widths = equalWidths(count);
    return {
      columns: widths.map(function (width, index) {
        return {
          width: width,
          align:
            index === 0 ? "left" : index === count - 1 ? "right" : "center",
          items: [],
        };
      }),
    };
  }
  function legacyHeader(value) {
    return {
      rows: (value.rows || []).map(function (row) {
        return {
          columns: [
            { width: 33.33, align: "left", items: row.left || [] },
            { width: 33.34, align: "center", items: row.center || [] },
            { width: 33.33, align: "right", items: row.right || [] },
          ],
        };
      }),
    };
  }
  function legacyFooter(value) {
    var items = value.items || [];
    var row = makeRow(Math.max(1, items.length));
    items.forEach(function (item, index) {
      row.columns[index].items = [item];
    });
    return { rows: [row] };
  }
  function parse(input, part) {
    var raw = {};
    try {
      raw = JSON.parse((input && input.value) || "{}");
    } catch (error) {}
    if (
      Array.isArray(raw.rows) &&
      raw.rows.length &&
      Array.isArray(raw.rows[0].columns)
    ) {
      return raw;
    }
    if (part === "header" && Array.isArray(raw.rows)) {
      return legacyHeader(raw);
    }
    if (part === "footer" && Array.isArray(raw.items)) {
      return legacyFooter(raw);
    }
    return { rows: [makeRow(part === "footer" ? 4 : 3)] };
  }
  function normalize(layout) {
    var seen = {};
    layout.rows = (layout.rows || []).slice(0, 3).map(function (row) {
      var columns = Array.isArray(row.columns) ? row.columns.slice(0, 6) : [];
      if (!columns.length) {
        columns = makeRow(1).columns;
      }
      var widths = equalWidths(columns.length);
      columns = columns.map(function (column, index) {
        var width = Number(column.width);
        return {
          width: Number.isFinite(width)
            ? Math.max(1, Math.min(100, width))
            : widths[index],
          align:
            ["left", "center", "right"].indexOf(column.align) >= 0
              ? column.align
              : "center",
          items: (column.items || []).filter(function (item) {
            if (item === "subtitle" || seen[item]) {
              return false;
            }
            seen[item] = true;
            return true;
          }),
        };
      });
      return { columns: columns };
    });
    if (!layout.rows.length) {
      layout.rows = [makeRow(1)];
    }
    return layout;
  }
  function pageDefault(part, page) {
    if (part === "footer") {
      var footer = makeRow(page === "product" ? 3 : 4);
      var footerItems =
        page === "product"
          ? ["share", "like", "add_to_cart"]
          : ["home", "categories", "wishlist", "account"];
      footerItems.forEach(function (item, index) {
        footer.columns[index].items = [item];
      });
      return { rows: [footer] };
    }
    var first = makeRow(3),
      second = makeRow(1);
    var layouts = {
      home: function () {
        first.columns[0].items = ["logo"];
        first.columns[2].items = ["cart"];
        second.columns[0].items = ["search_bar"];
        return { rows: [first, second] };
      },
      catalog: function () {
        first.columns[0].items = ["cart", "search"];
        first.columns[1].items = ["title"];
        first.columns[2].items = ["back"];
        return { rows: [first] };
      },
      product: function () {
        first.columns[0].items = ["back"];
        first.columns[2].items = ["support", "cart"];
        return { rows: [first] };
      },
      category: function () {
        first.columns[0].items = ["search", "cart"];
        first.columns[1].items = ["title"];
        return { rows: [first] };
      },
      wishlist: function () {
        first.columns[1].items = ["title"];
        first.columns[2].items = ["cart"];
        return { rows: [first] };
      },
      account: function () {
        first.columns[1].items = ["title"];
        first.columns[2].items = ["orders"];
        return { rows: [first] };
      },
    };
    return (layouts[page] || layouts.catalog)();
  }
  function collapsedDefault() {
    var row = makeRow(2);
    row.columns[0].width = 84;
    row.columns[0].align = "left";
    row.columns[0].items = ["search_bar"];
    row.columns[1].width = 16;
    row.columns[1].align = "right";
    row.columns[1].items = ["cart"];
    return { rows: [row] };
  }
  function previewLayout(card, part, key) {
    return normalize(
      parse(field(card, key || "layout_json") || { value: "" }, part),
    );
  }
  function itemStyle(card, item) {
    var prefix =
        item === "search"
          ? "search_icon"
          : item === "account"
            ? "account_icon"
            : item,
      backgroundKey =
        item === "account" ? "account_background" : prefix + "_background",
      radiusKey = item === "account" ? "account_radius" : prefix + "_radius";
    var style = value(
      card,
      prefix + "_style",
      item === "account" ? value(card, "account_style", "icon") : "outline",
    );
    var color = value(
      card,
      prefix + "_color",
      value(card, "icon_color", "#1F2933"),
    );
    var background = value(card, backgroundKey, "#FFFFFF");
    return (
      "color:" +
      color +
      ";background:" +
      (style === "circle" || style === "filled" ? background : "transparent") +
      ";border:" +
      (style === "circle" ? "1px solid " + color : "0") +
      ";border-radius:" +
      (style === "circle" ? "50%" : number(card, radiusKey, 12, 0, 24) + "px") +
      ";--item-icon-size:" +
      number(
        card,
        prefix + "_size",
        number(card, "icon_size", 24, 14, 40),
        14,
        40,
      ) +
      "px;"
    );
  }
  function positionStyle(card, item) {
    var prefix = item === "search" ? "search_icon" : item;
    return (
      "transform:translate(" +
      number(card, prefix + "_offset_x", 0, -80, 80) +
      "px," +
      number(card, prefix + "_offset_y", 0, -80, 80) +
      "px);"
    );
  }
  function badgeStyle(card) {
    var size = number(card, "cart_badge_size", 18, 12, 30),
      shape = value(card, "cart_badge_shape", "circle"),
      radius =
        shape === "circle"
          ? "50%"
          : shape === "pill"
            ? size / 2 + "px"
            : Math.max(3, size * 0.28) + "px";
    return (
      "min-width:" +
      size +
      "px;height:" +
      size +
      "px;padding:" +
      (shape === "pill" ? "0 4px" : "0") +
      ";border-radius:" +
      radius +
      ";background:" +
      value(card, "cart_badge_background", "#E94B5F") +
      ";color:" +
      value(card, "cart_badge_text_color", "#FFFFFF") +
      ";font-size:" +
      Math.max(7, Math.round(size * 0.52)) +
      "px;"
    );
  }
  function headerItem(card, item, defaultTitle) {
    if (item === "logo") {
      var url = value(card, "logo_url", ""),
        subtitle = esc(value(card, "subtitle", "")),
        text = esc(value(card, "logo_text", "Kidia")),
        textColor = value(
          card,
          "logo_text_color",
          value(card, "icon_color", "#1F2933"),
        ),
        logo = url
          ? '<img class="kidia-app-header-logo" src="' +
            esc(url) +
            '" alt="" style="width:' +
            number(card, "logo_width", 118, 32, 220) +
            "px;height:" +
            number(card, "logo_height", 38, 20, 80) +
            'px">'
          : '<strong class="kidia-app-header-logo-text" style="color:' +
            textColor +
            '">' +
            text +
            "</strong>";
      return (
        '<span class="kidia-app-header-brand" style="' +
        positionStyle(card, item) +
        '">' +
        logo +
        (subtitle
          ? '<small class="kidia-app-header-subtitle" style="color:' +
            textColor +
            '">' +
            subtitle +
            "</small>"
          : "") +
        "</span>"
      );
    }
    if (item === "title") {
      var title = String(value(card, "title", defaultTitle || "Kidia")),
        transform = value(card, "title_transform", "none"),
        align =
          { start: "left", center: "center", end: "right" }[
            value(card, "title_alignment", "center")
          ] || "center";
      if (transform === "uppercase") {
        title = title.toUpperCase();
      } else if (transform === "lowercase") {
        title = title.toLowerCase();
      }
      return (
        '<strong class="kidia-app-header-title" style="display:block;max-width:' +
        number(card, "title_max_width_percent", 100, 20, 100) +
        "%;color:" +
        value(card, "title_color", "#1F2933") +
        ";font-size:" +
        number(card, "title_font_size", 18, 10, 42) +
        "px;font-weight:" +
        number(card, "title_font_weight", 700, 400, 800) +
        ";letter-spacing:" +
        number(card, "title_letter_spacing", 0, -2, 8) +
        "px;line-height:" +
        number(card, "title_line_height", 1.2, 0.8, 2) +
        ";text-align:" +
        align +
        ";" +
        positionStyle(card, item) +
        '">' +
        esc(title) +
        "</strong>"
      );
    }
    if (item === "search_bar") {
      return (
        '<div class="kidia-app-search" style="' +
        positionStyle(card, item) +
        "width:" +
        number(card, "search_width_percent", 100, 30, 100) +
        "%;height:" +
        number(card, "search_height", 40, 32, 64) +
        "px;border:" +
        number(card, "search_border_width", 0, 0, 6) +
        "px solid " +
        value(card, "search_border_color", "#DDE3E8") +
        ";border-radius:" +
        number(card, "search_radius", 14, 0, 32) +
        "px;background:" +
        value(card, "search_background", "#F1F3F4") +
        ";color:" +
        value(card, "search_text_color", "#5F6368") +
        '">' +
        icon(card, "search", false) +
        "<span>" +
        esc(value(card, "search_placeholder", "Search products")) +
        "</span></div>"
      );
    }
    var prefix =
        item === "search"
          ? "search_icon"
          : item === "account"
            ? "account_icon"
            : item,
      style = value(
        card,
        prefix + "_style",
        item === "account" ? value(card, "account_style", "icon") : "outline",
      );
    return (
      '<span class="kidia-app-header-item kidia-app-header-item--' +
      item +
      " is-" +
      esc(style) +
      '" style="' +
      itemStyle(card, item) +
      positionStyle(card, item) +
      '">' +
      icon(card, item, style === "filled") +
      (item === "cart" && checked(card, "show_cart_badge", false)
        ? '<i class="kidia-app-icon-badge" style="' +
          badgeStyle(card) +
          '">1</i>'
        : "") +
      "</span>"
    );
  }
  function collapsedHeaderOverrides(card, collapsed) {
    if (!collapsed) {
      return "";
    }
    var style = value(card, "compact_style", "standard"),
      margin = number(
        card,
        "compact_side_margin",
        style === "floating" || style === "pill" ? 8 : 0,
        0,
        32,
      ),
      radius = number(
        card,
        "compact_radius",
        style === "pill" ? 40 : style === "floating" ? 16 : 0,
        0,
        40,
      ),
      background =
        style === "transparent"
          ? "transparent"
          : value(card, "compact_background_color", "#FFFFFF"),
      shadowValue = value(
        card,
        "compact_shadow",
        style === "transparent" ? "none" : "subtle",
      ),
      shadowCss =
        shadowValue === "none"
          ? "none"
          : shadowValue === "strong"
            ? "0 8px 24px rgba(31,41,51,.22)"
            : "0 4px 12px rgba(31,41,51,.12)";
    return (
      "margin-left:" +
      margin +
      "px;margin-right:" +
      margin +
      "px;background:" +
      background +
      ";border:" +
      number(card, "compact_border_width", 0, 0, 6) +
      "px solid " +
      value(card, "compact_border_color", "#E2E6E4") +
      ";border-radius:" +
      radius +
      "px;box-shadow:" +
      shadowCss +
      ";"
    );
  }
  function collapseTransition(card) {
    var transition = value(card, "collapse_transition", "smooth_compact");
    return [
      "smooth_compact",
      "instant",
      "fade",
      "slide",
      "fade_slide",
      "scale",
    ].indexOf(transition) >= 0
      ? transition
      : "smooth_compact";
  }
  function collapseDuration(card) {
    var speed = value(card, "collapse_speed", "medium");
    return speed === "fast" ? 160 : speed === "slow" ? 420 : 260;
  }
  function rowHeight(card, index) {
    return number(
      card,
      index === 0 ? "row_1_height" : "row_2_height",
      48,
      24,
      100,
    );
  }
  function rowPosition(card, index, count) {
    return value(
      card,
      count === 1
        ? "header_position"
        : index === 0
          ? "row_1_position"
          : "row_2_position",
      "center",
    );
  }
  function rowAlignment(position) {
    return position === "up"
      ? "flex-start"
      : position === "down"
        ? "flex-end"
        : "center";
  }
  function effectiveRowGap(card) {
    return Math.max(
      0,
      number(card, "row_gap", 8, 0, 24) - number(card, "row_merge", 0, 0, 24),
    );
  }
  function visibleHeaderHeight(card, collapsed, layout) {
    if (collapsed) {
      return number(card, "compact_height", 60, 44, 100);
    }
    layout = layout || previewLayout(card, "header", "layout_json");
    var count = (layout.rows || []).length;
    if (count <= 1) {
      return number(card, "height", 64, 48, 120);
    }
    var height =
      number(card, "vertical_padding", 8, 0, 24) * 2 +
      effectiveRowGap(card) * Math.max(0, count - 1);
    for (var index = 0; index < count; index += 1) {
      height += rowHeight(card, index);
    }
    return Math.max(48, Math.min(360, height));
  }
  function headerRows(card, defaultTitle, layout) {
    var count = layout.rows.length;
    return layout.rows
      .map(function (row, index) {
        var fixedHeight = count > 1 ? rowHeight(card, index) + "px" : "100%",
          align = rowAlignment(rowPosition(card, index, count));
        return (
          '<div class="kidia-app-header-row kidia-app-layout-row" style="height:' +
          fixedHeight +
          ";align-items:" +
          align +
          ";grid-template-columns:" +
          row.columns
            .map(function (column) {
              return "minmax(0," + column.width + "fr)";
            })
            .join(" ") +
          '">' +
          row.columns
            .map(function (column) {
              return (
                '<div class="kidia-app-header-slot is-' +
                column.align +
                '" style="align-self:' +
                align +
                '">' +
                column.items
                  .map(function (item) {
                    return headerItem(card, item, defaultTitle);
                  })
                  .join("") +
                "</div>"
              );
            })
            .join("") +
          "</div>"
        );
      })
      .join("");
  }
  function collapseProgress(options, enabled) {
    if (!enabled) {
      return 0;
    }
    var raw = Number(options.collapseProgress);
    if (isFinite(raw)) {
      return Math.max(0, Math.min(1, raw));
    }
    return options.collapsed === true ? 1 : 0;
  }
  function interpolate(start, end, progress) {
    return start + (end - start) * progress;
  }
  function mixHex(start, end, progress) {
    var parse = function (value) {
        var match =
          /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})?$/i.exec(
            value || "",
          );
        return match
          ? [
              parseInt(match[1], 16),
              parseInt(match[2], 16),
              parseInt(match[3], 16),
              match[4] ? parseInt(match[4], 16) / 255 : 1,
            ]
          : null;
      },
      a = parse(start),
      b = parse(end);
    if (!a || !b) {
      return progress < 0.5 ? start : end;
    }
    return (
      "rgba(" +
      a
        .slice(0, 3)
        .map(function (channel, index) {
          return Math.round(interpolate(channel, b[index], progress));
        })
        .join(",") +
      "," +
      interpolate(a[3], b[3], progress).toFixed(3) +
      ")"
    );
  }
  function layoutItems(layout) {
    var items = [];
    (layout.rows || []).forEach(function (row) {
      (row.columns || []).forEach(function (column) {
        items = items.concat(column.items || []);
      });
    });
    return items;
  }
  function withoutItems(layout, removed) {
    return {
      rows: (layout.rows || [])
        .map(function (row) {
          return {
            columns: (row.columns || []).map(function (column) {
              return {
                width: column.width,
                align: column.align,
                items: (column.items || []).filter(function (item) {
                  return removed.indexOf(item) < 0;
                }),
              };
            }),
          };
        })
        .filter(function (row) {
          return row.columns.some(function (column) {
            return column.items.length;
          });
        }),
    };
  }
  function itemWidth(layout, item, fallback) {
    var result = fallback;
    (layout.rows || []).some(function (row) {
      return (row.columns || []).some(function (column) {
        if ((column.items || []).indexOf(item) < 0) {
          return false;
        }
        result = Math.max(10, Math.min(100, Number(column.width) || 100)) / 100;
        return true;
      });
    });
    return result;
  }
  function rowItemHeight(card, item) {
    if (item === "search_bar") {
      return number(card, "search_height", 40, 32, 64);
    }
    if (item === "logo") {
      return (
        number(card, "logo_height", 38, 20, 80) +
        (String(value(card, "subtitle", "")).trim() ? 11 : 0)
      );
    }
    if (item === "title") {
      return (
        number(card, "title_font_size", 18, 10, 42) *
        number(card, "title_line_height", 1.2, 0.8, 2)
      );
    }
    var prefix = item === "search" ? "search_icon" : item;
    return number(
      card,
      prefix + "_size",
      number(card, "icon_size", 24, 14, 40),
      14,
      40,
    );
  }
  function itemTop(card, layout, item) {
    var top = 0,
      count = (layout.rows || []).length,
      gap = effectiveRowGap(card);
    (layout.rows || []).some(function (row, index) {
      var items = [];
      (row.columns || []).forEach(function (column) {
        items = items.concat(column.items || []);
      });
      var content = items.reduce(function (result, current) {
          return Math.max(result, rowItemHeight(card, current));
        }, 0),
        height =
          count > 1
            ? rowHeight(card, index)
            : Math.max(
                content,
                visibleHeaderHeight(card, false, layout) -
                  number(card, "vertical_padding", 8, 0, 24) * 2,
              ),
        position = rowPosition(card, index, count),
        inside =
          position === "down"
            ? Math.max(0, height - content)
            : position === "center"
              ? Math.max(0, (height - content) / 2)
              : 0;
      if (items.indexOf(item) >= 0) {
        top += inside;
        return true;
      }
      top += height + gap;
      return false;
    });
    return top;
  }
  function smoothHeaderLayers(
    card,
    defaultTitle,
    regularLayout,
    compactLayout,
    progress,
  ) {
    var regularItems = layoutItems(regularLayout),
      compactItems = layoutItems(compactLayout),
      morphSearch =
        regularItems.indexOf("search_bar") >= 0 &&
        compactItems.indexOf("search_bar") >= 0;
    if (!morphSearch) {
      return (
        '<div class="kidia-app-header-transition-layer kidia-app-header-transition-layer--regular" style="opacity:' +
        (1 - progress) +
        '">' +
        headerRows(card, defaultTitle, regularLayout) +
        '</div><div class="kidia-app-header-transition-layer kidia-app-header-transition-layer--compact" style="opacity:' +
        progress +
        '">' +
        headerRows(card, defaultTitle, compactLayout) +
        "</div>"
      );
    }
    var fixedActions = ["cart", "orders", "wishlist", "account"],
      persistent = regularItems.filter(function (item) {
        return fixedActions.indexOf(item) >= 0;
      }),
      removed = ["search_bar"].concat(persistent),
      regularOnly = withoutItems(regularLayout, removed),
      compactOnly = withoutItems(compactLayout, removed),
      searchWidth =
        interpolate(
          itemWidth(regularLayout, "search_bar", 1),
          number(card, "compact_search_width_percent", 84, 30, 100) / 100,
          progress,
        ) * 100,
      availableHeight =
        visibleHeaderHeight(card, false, regularLayout) -
        number(card, "vertical_padding", 8, 0, 24) * 2 -
        number(card, "search_height", 40, 32, 64),
      searchTop = interpolate(
        Math.max(
          0,
          Math.min(availableHeight, itemTop(card, regularLayout, "search_bar")),
        ),
        0,
        progress,
      );
    var fixedTop = persistent.length
      ? Math.max(
          2,
          Math.min.apply(
            null,
            persistent.map(function (item) {
              return itemTop(card, regularLayout, item);
            }),
          ),
        )
      : 0;
    return (
      '<div class="kidia-app-header-transition-layer kidia-app-header-transition-layer--regular" style="opacity:' +
      (1 - progress) +
      '">' +
      headerRows(card, defaultTitle, regularOnly) +
      '</div><div class="kidia-app-header-transition-layer kidia-app-header-transition-layer--compact" style="opacity:' +
      progress +
      '">' +
      headerRows(card, defaultTitle, compactOnly) +
      '</div><div class="kidia-app-header-morphing-search" style="top:' +
      searchTop +
      "px;width:" +
      searchWidth +
      '%">' +
      headerItem(card, "search_bar", defaultTitle) +
      '</div><div class="kidia-app-header-fixed-actions" style="top:' +
      fixedTop +
      'px">' +
      persistent
        .map(function (item) {
          return headerItem(card, item, defaultTitle);
        })
        .join("") +
      "</div>"
    );
  }
  function updateHeaderProgress(header, progress) {
    if (!header) {
      return;
    }
    progress = Math.max(0, Math.min(1, Number(progress) || 0));
    var regular = Number(header.dataset.regularHeight) || 64,
      compact = Number(header.dataset.compactHeight) || 60,
      regularPadding = Number(header.dataset.regularPadding) || 0,
      compactPadding = Number(header.dataset.compactPadding) || regularPadding,
      sideMargin = Number(header.dataset.compactSideMargin) || 0,
      regularRadius = Number(header.dataset.regularRadius) || 0,
      compactRadius = Number(header.dataset.compactRadius) || 0,
      regularBorder = Number(header.dataset.regularBorder) || 0,
      compactBorder = Number(header.dataset.compactBorder) || 0;
    header.style.height = interpolate(regular, compact, progress) + "px";
    header.style.paddingLeft =
      interpolate(regularPadding, compactPadding, progress) + "px";
    header.style.paddingRight =
      interpolate(regularPadding, compactPadding, progress) + "px";
    header.style.marginLeft = interpolate(0, sideMargin, progress) + "px";
    header.style.marginRight = interpolate(0, sideMargin, progress) + "px";
    header.style.borderRadius =
      interpolate(regularRadius, compactRadius, progress) + "px";
    header.style.borderWidth =
      interpolate(regularBorder, compactBorder, progress) + "px";
    header.style.borderColor = mixHex(
      header.dataset.regularBorderColor,
      header.dataset.compactBorderColor,
      progress,
    );
    header.style.background = mixHex(
      header.dataset.regularBackground,
      header.dataset.compactBackground,
      progress,
    );
    header.classList.toggle("is-collapsed", progress >= 0.999);
    var regularLayer = header.querySelector(
        ".kidia-app-header-transition-layer--regular",
      ),
      compactLayer = header.querySelector(
        ".kidia-app-header-transition-layer--compact",
      ),
      search = header.querySelector(".kidia-app-header-morphing-search");
    if (regularLayer) {
      regularLayer.style.opacity = String(1 - progress);
      regularLayer.style.transform = "translateY(" + -8 * progress + "px)";
    }
    if (compactLayer) {
      compactLayer.style.opacity = String(progress);
      compactLayer.style.transform = "translateY(" + 8 * (1 - progress) + "px)";
    }
    if (search) {
      var startTop = Number(search.dataset.startTop) || 0,
        startWidth = Number(search.dataset.startWidth) || 100,
        endWidth = Number(search.dataset.endWidth) || 84;
      search.style.top = interpolate(startTop, 0, progress) + "px";
      search.style.width = interpolate(startWidth, endWidth, progress) + "%";
    }
  }
  function renderHeader(card, defaultTitle, options) {
    if (!card || !checked(card, "enabled", true)) {
      return "";
    }
    options = options || {};
    var enabled = checked(card, "collapse_on_scroll", false),
      progress = collapseProgress(options, enabled),
      collapsed = progress >= 0.999,
      transition = collapseTransition(card),
      duration = collapseDuration(card),
      regularLayout = previewLayout(card, "header", "layout_json"),
      compactLayout = previewLayout(card, "header", "compact_layout_json"),
      regularRows = headerRows(card, defaultTitle, regularLayout),
      compactRows = headerRows(card, defaultTitle, compactLayout),
      rows = collapsed ? compactRows : regularRows,
      regularBackground =
        value(card, "style", "standard") === "transparent"
          ? "#FFFFFF00"
          : value(card, "background_color", "#FFFFFF"),
      compactBackground =
        value(card, "compact_style", "standard") === "transparent"
          ? "#FFFFFF00"
          : value(card, "compact_background_color", "#FFFFFF"),
      smooth = transition === "smooth_compact",
      background = mixHex(regularBackground, compactBackground, progress),
      regularHeight = visibleHeaderHeight(card, false, regularLayout),
      searchHeight = number(card, "search_height", 40, 32, 64),
      compactHeight = Math.max(
        visibleHeaderHeight(card, true, compactLayout),
        searchHeight + number(card, "vertical_padding", 8, 0, 24) * 2,
      ),
      height = interpolate(regularHeight, compactHeight, progress),
      regularPadding = number(card, "horizontal_padding", 16, 0, 32),
      compactPadding = number(card, "compact_horizontal_padding", 16, 0, 32),
      padding = interpolate(regularPadding, compactPadding, progress),
      compactSideMargin = number(card, "compact_side_margin", 0, 0, 32),
      regularRadius = number(card, "corner_radius", 0, 0, 32),
      compactRadius = number(card, "compact_radius", 0, 0, 40),
      regularBorder = number(card, "border_width", 0, 0, 6),
      compactBorder = number(card, "compact_border_width", 0, 0, 6),
      regularBorderColor = value(card, "border_color", "#E2E6E4"),
      compactBorderColor = value(card, "compact_border_color", "#E2E6E4"),
      layers = smooth
        ? smoothHeaderLayers(
            card,
            defaultTitle,
            regularLayout,
            compactLayout,
            progress,
          )
        : rows,
      startTop = Math.max(
        0,
        Math.min(
          regularHeight -
            searchHeight -
            number(card, "vertical_padding", 8, 0, 24) * 2,
          itemTop(card, regularLayout, "search_bar"),
        ),
      ),
      startWidth = itemWidth(regularLayout, "search_bar", 1) * 100,
      endWidth = number(
        card,
        "compact_search_width_percent",
        84,
        30,
        100,
      );
    return (
      '<header class="kidia-app-header kidia-app-header--composed is-transition-' +
      transition +
      (collapsed ? " is-collapsed" : "") +
      '" data-regular-height="' +
      regularHeight +
      '" data-compact-height="' +
      compactHeight +
      '" data-regular-padding="' +
      regularPadding +
      '" data-compact-padding="' +
      compactPadding +
      '" data-compact-side-margin="' +
      compactSideMargin +
      '" data-regular-radius="' +
      regularRadius +
      '" data-compact-radius="' +
      compactRadius +
      '" data-regular-border="' +
      regularBorder +
      '" data-compact-border="' +
      compactBorder +
      '" data-regular-border-color="' +
      regularBorderColor +
      '" data-compact-border-color="' +
      compactBorderColor +
      '" data-regular-background="' +
      regularBackground +
      '" data-compact-background="' +
      compactBackground +
      '" style="box-sizing:border-box;overflow:hidden;--collapse-duration:' +
      duration +
      "ms;--regular-height:" +
      regularHeight +
      "px;--compact-height:" +
      compactHeight +
      "px;--search-height:" +
      searchHeight +
      "px;height:" +
      height +
      "px;margin:" +
      number(card, "margin_top", 0, 0, 80) +
      "px " +
      interpolate(0, compactSideMargin, progress) +
      "px " +
      number(card, "margin_bottom", 0, 0, 80) +
      "px;padding:" +
      number(card, "vertical_padding", 8, 0, 24) +
      "px " +
      padding +
      "px!important;background:" +
      background +
      ";color:" +
      value(card, "icon_color", "#1F2933") +
      ";border:" +
      interpolate(regularBorder, compactBorder, progress) +
      "px solid " +
      mixHex(regularBorderColor, compactBorderColor, progress) +
      ";border-radius:" +
      interpolate(regularRadius, compactRadius, progress) +
      "px;box-shadow:" +
      shadow(card) +
      ";--icon-size:" +
      number(card, "icon_size", 24, 14, 40) +
      "px;--item-gap:" +
      number(card, "icon_gap", 6, 0, 24) +
      "px;--row-gap:" +
      effectiveRowGap(card) +
      'px">' +
      layers.replace(
        'class="kidia-app-header-morphing-search"',
        'class="kidia-app-header-morphing-search" data-start-top="' +
          startTop +
          '" data-start-width="' +
          startWidth +
          '" data-end-width="' +
          endWidth +
          '"',
      ) +
      "</header>"
    );
  }
  function arabicLabel(card, item, fallback) {
    var configured = String(value(card, item + "_label", "") || "").trim();
    return /[\u0600-\u06ff]/.test(configured) ? configured : fallback;
  }
  function configNumber(raw, fallback, min, max) {
    var parsed = Number(raw);
    if (!Number.isFinite(parsed)) {
      parsed = fallback;
    }
    return Math.max(min, Math.min(max, parsed));
  }
  function footerMetrics(card, page) {
    var reference = previewConfig.footerSize || {},
      useCard = page === "category";
    return {
      height: useCard
        ? number(card, "height", 76, 48, 100)
        : configNumber(reference.height, 76, 48, 100),
      iconSize: useCard
        ? number(card, "icon_size", 24, 14, 40)
        : configNumber(reference.iconSize, 24, 14, 40),
      labelSize: useCard
        ? number(card, "label_size", 11, 8, 20)
        : configNumber(reference.labelSize, 11, 8, 20),
      gap: number(card, "icon_label_gap", 3, 0, 12),
    };
  }
  function alphaColor(hex, alpha) {
    var match = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex || "");
    return match
      ? "rgba(" +
          parseInt(match[1], 16) +
          "," +
          parseInt(match[2], 16) +
          "," +
          parseInt(match[3], 16) +
          "," +
          alpha +
          ")"
      : hex;
  }
  function buttonRadius(card, height) {
    var shape = value(card, "button_shape", "custom");
    if (shape === "rectangle") {
      return 0;
    }
    if (shape === "rounded") {
      return 12;
    }
    if (shape === "pill") {
      return height / 2;
    }
    return number(card, "button_radius", 28, 0, 40);
  }
  function footerItem(card, item, metrics, activeItem, itemColumnWidth) {
    var labels = {
      home: "الرئيسية",
      categories: "الأقسام",
      search: "بحث",
      cart: "السلة",
      wishlist: "المفضلة",
      account: "حسابي",
      orders: "طلباتي",
      share: "مشاركة",
      like: "المفضلة",
    };
    if (item === "add_to_cart") {
      var buttonColor = value(card, "button_color", "#1F2933"),
        buttonText = value(card, "button_text_color", "#FFFFFF"),
        buttonStyle = value(card, "button_style", "filled"),
        buttonHeight = number(card, "button_height", 52, 36, 80),
        buttonBorderWidth = number(card, "button_border_width", 0, 0, 6),
        buttonBorderColor = value(card, "button_border_color", buttonColor),
        background =
          buttonStyle === "outline"
            ? "transparent"
            : buttonStyle === "soft"
              ? alphaColor(buttonColor, 0.14)
              : buttonColor,
        borderWidth =
          buttonStyle === "outline"
            ? Math.max(1, buttonBorderWidth)
            : buttonBorderWidth,
        buttonWidth = Math.min(
          100,
          (number(card, "button_width_percent", 58, 20, 95) /
            Math.max(0.01, itemColumnWidth)) *
            100,
        );
      return (
        '<button class="kidia-app-footer-add is-' +
        esc(buttonStyle) +
        '" style="width:' +
        buttonWidth +
        "%;height:" +
        buttonHeight +
        "px;align-self:center;background:" +
        background +
        ";color:" +
        buttonText +
        ";border:" +
        borderWidth +
        "px solid " +
        buttonBorderColor +
        ";border-radius:" +
        buttonRadius(card, buttonHeight) +
        'px">' +
        esc(arabicLabel(card, "add_to_cart", "أضف إلى السلة")) +
        "</button>"
      );
    }
    var active = item === activeItem,
      color = active
        ? value(card, "active_color", "#1F6F61")
        : value(card, "inactive_color", "#6B7280"),
      style = value(card, item + "_icon_style", "outline");
    return (
      '<span class="kidia-app-footer-item kidia-app-footer-item--' +
      item +
      " is-" +
      esc(style) +
      (active ? " is-active" : "") +
      '" style="color:' +
      color +
      ";--item-icon-size:" +
      metrics.iconSize +
      'px"><i class="kidia-app-footer-icon-shell" style="background:' +
      (style === "outline" ? "transparent" : color) +
      ";color:" +
      (style === "outline" ? color : "#FFFFFF") +
      ";border:" +
      (style === "circle" ? "1px solid " + color : "0") +
      ";border-radius:" +
      (style === "circle" ? "50%" : "8px") +
      '">' +
      icon(card, item, active || style === "filled") +
      "</i>" +
      (checked(card, "show_labels", true)
        ? "<b>" + esc(arabicLabel(card, item, labels[item] || item)) + "</b>"
        : "") +
      "</span>"
    );
  }
  function renderFooter(card, options) {
    if (!card || !checked(card, "enabled", true)) {
      return "";
    }
    options = options || {};
    var page = options.page || card.dataset.page || "home",
      active =
        {
          home: "home",
          category: "categories",
          catalog: "categories",
          wishlist: "wishlist",
          account: "account",
        }[page] || "",
      supported = [
        "home",
        "categories",
        "search",
        "cart",
        "wishlist",
        "account",
        "orders",
        "share",
        "like",
        "add_to_cart",
      ],
      metrics = footerMetrics(card, page),
      footerHeight =
        page === "product"
          ? Math.max(metrics.height, number(card, "button_height", 52, 36, 80))
          : metrics.height,
      layout = previewLayout(card, "footer"),
      placements = [];
    layout.rows.forEach(function (row) {
      row.columns.forEach(function (column) {
        var supportedItems = column.items.filter(function (item) {
            return supported.indexOf(item) !== -1;
          }),
          itemWidth = supportedItems.length
            ? column.width / supportedItems.length
            : column.width;
        supportedItems.forEach(function (item) {
          placements.push({ item: item, width: itemWidth });
        });
      });
    });
    var rows = placements.length
      ? '<div class="kidia-app-footer-row kidia-app-layout-row" style="grid-template-columns:' +
        placements
          .map(function (placement) {
            return "minmax(0," + placement.width + "fr)";
          })
          .join(" ") +
        '">' +
        placements
          .map(function (placement) {
            return (
              '<div class="kidia-app-footer-column">' +
              footerItem(
                card,
                placement.item,
                metrics,
                active,
                placement.width,
              ) +
              "</div>"
            );
          })
          .join("") +
        "</div>"
      : "";
    return (
      '<footer class="kidia-app-footer kidia-app-footer--composed" style="height:' +
      footerHeight +
      "px;margin:" +
      number(card, "margin_top", 0, 0, 80) +
      "px 0 " +
      number(card, "margin_bottom", 0, 0, 80) +
      "px;background:" +
      value(card, "background_color", "#FFFFFF") +
      ";padding:0 " +
      number(card, "side_spacing_percent", 0, 0, 25) +
      "%;border-top:" +
      number(card, "border_width", 1, 0, 6) +
      "px solid " +
      value(card, "border_color", "#E2E6E4") +
      ";border-radius:" +
      number(card, "top_radius", 0, 0, 32) +
      "px " +
      number(card, "top_radius", 0, 0, 32) +
      "px 0 0;box-shadow:" +
      shadow(card) +
      ";--icon-size:" +
      metrics.iconSize +
      "px;--label-gap:" +
      metrics.gap +
      "px;--label-size:" +
      metrics.labelSize +
      'px">' +
      rows +
      "</footer>"
    );
  }
  function sectionSpaced(markup, card) {
    var up = number(card, "space_up", 0, 0, 80),
      down = number(card, "space_down", 0, 0, 80);
    if (!markup || (up === 0 && down === 0)) {
      return markup;
    }
    return markup.replace(
      '">',
      ";box-sizing:content-box!important;padding-top:" +
        up +
        "px!important;padding-bottom:" +
        down +
        'px!important">',
    );
  }
  window.KidiaChromePreview = {
    renderHeader: function (card, title, options) {
      return sectionSpaced(renderHeader(card, title, options), card);
    },
    renderFooter: function (card, options) {
      return sectionSpaced(renderFooter(card, options), card);
    },
    updateHeaderProgress: updateHeaderProgress,
  };
  function transferStorageKey(card) {
    return (
      "kidia_mobile_cms_" + (card.dataset.chromePart || "chrome") + "_settings"
    );
  }
  function transferStatus(card, message, error) {
    var status = card.querySelector(".kidia-chrome-transfer-status");
    if (!status) {
      return;
    }
    status.textContent = message;
    status.classList.toggle("is-error", !!error);
    window.setTimeout(function () {
      if (status.textContent === message) {
        status.textContent = "";
        status.classList.remove("is-error");
      }
    }, 2400);
  }
  function readTransferPayload(card) {
    var settings = {};
    Array.prototype.forEach.call(
      card.querySelectorAll('[name*="[settings]["]'),
      function (control) {
        var match = /\[settings\]\[([^\]]+)\]$/.exec(control.name || "");
        if (!match || field(card, match[1]) !== control) {
          return;
        }
        settings[match[1]] =
          control.type === "checkbox" ? control.checked : control.value;
      },
    );
    var enabled = field(card, "enabled");
    return {
      version: 1,
      part: card.dataset.chromePart || "",
      enabled: enabled ? enabled.checked : true,
      settings: settings,
    };
  }
  function refreshIconChoices(card) {
    Array.prototype.forEach.call(
      card.querySelectorAll(".kidia-chrome-icon-select"),
      function (select) {
        var choice = select.closest(".kidia-chrome-icon-choice");
        if (!choice) {
          return;
        }
        Array.prototype.forEach.call(
          choice.querySelectorAll(".kidia-chrome-icon-option"),
          function (option) {
            var selected = option.dataset.iconValue === select.value;
            option.classList.toggle("is-selected", selected);
            option.setAttribute("aria-pressed", selected ? "true" : "false");
          },
        );
      },
    );
  }
  function applyTransferPayload(card, payload) {
    if (
      !payload ||
      payload.part !== (card.dataset.chromePart || "") ||
      !payload.settings
    ) {
      return false;
    }
    var enabled = field(card, "enabled");
    if (enabled) {
      enabled.checked = !!payload.enabled;
      enabled.dispatchEvent(new Event("change", { bubbles: true }));
    }
    Object.keys(payload.settings).forEach(function (key) {
      var control = field(card, key);
      if (!control) {
        return;
      }
      if (control.type === "checkbox") {
        control.checked = !!payload.settings[key];
      } else {
        control.value = String(payload.settings[key]);
      }
      control.dispatchEvent(new Event("input", { bubbles: true }));
      control.dispatchEvent(new Event("change", { bubbles: true }));
    });
    refreshIconChoices(card);
    Array.prototype.forEach.call(
      card.querySelectorAll(".kidia-chrome-composer"),
      function (composer) {
        composer.dispatchEvent(new Event("kidia:chrome-layout-replaced"));
      },
    );
    return true;
  }
  function syncCollapsedVisibility(card) {
    if (
      !card ||
      (card.dataset.chromePart !== "header" &&
        !card.querySelector(".kidia-collapsed-header-enabled"))
    ) {
      return;
    }
    var toggle = card.querySelector(".kidia-collapsed-header-enabled"),
      visible = !!(toggle && toggle.checked),
      smooth =
        value(card, "collapse_transition", "smooth_compact") ===
        "smooth_compact";
    var composer = card.querySelector(".kidia-chrome-composer--collapsed"),
      settings = card.querySelector(".kidia-collapsed-header-settings"),
      searchTransition = card.querySelector(
        ".kidia-compact-search-transition",
      );
    if (composer) {
      composer.hidden = smooth;
      composer.classList.toggle("is-disabled", !visible);
      composer.setAttribute("aria-disabled", visible ? "false" : "true");
    }
    if (searchTransition) {
      searchTransition.hidden = !smooth;
      searchTransition.classList.toggle("is-disabled", !visible);
      searchTransition.setAttribute(
        "aria-disabled",
        visible ? "false" : "true",
      );
    }
    if (settings) {
      settings.hidden = !visible;
    }
  }
  document.addEventListener("click", function (event) {
    var button =
      event.target.closest &&
      event.target.closest(".kidia-fixed-chrome-expand");
    if (!button) {
      return;
    }
    var card = button.closest(".kidia-fixed-chrome-card"),
      body = card && card.querySelector(":scope > .kidia-page-card__body");
    if (!body) {
      return;
    }
    event.preventDefault();
    var opening = body.hidden;
    body.hidden = !opening;
    button.setAttribute("aria-expanded", opening ? "true" : "false");
    card.classList.toggle("is-open", opening);
  });
  document.addEventListener("click", function (event) {
    var trigger =
      event.target.closest &&
      event.target.closest("#kidia-collapse-all,#kidia-expand-all");
    if (!trigger) {
      return;
    }
    var opening = trigger.id === "kidia-expand-all";
    Array.prototype.forEach.call(
      document.querySelectorAll(".kidia-fixed-chrome-card"),
      function (card) {
        var body = card.querySelector(":scope > .kidia-page-card__body"),
          button = card.querySelector(".kidia-fixed-chrome-expand");
        if (body) {
          body.hidden = !opening;
        }
        card.classList.toggle("is-open", opening);
        if (button) {
          button.setAttribute("aria-expanded", opening ? "true" : "false");
        }
      },
    );
  });
  document.addEventListener("change", function (event) {
    if (
      !event.target.matches ||
      !event.target.matches(
        ".kidia-collapsed-header-enabled,[name$='[collapse_transition]']",
      )
    ) {
      return;
    }
    syncCollapsedVisibility(event.target.closest(".kidia-fixed-chrome-card"));
  });
  document.addEventListener("click", function (event) {
    var button =
      event.target.closest &&
      event.target.closest("[data-chrome-copy],[data-chrome-paste]");
    if (!button) {
      return;
    }
    var card = button.closest(".kidia-fixed-chrome-card");
    if (!card) {
      return;
    }
    event.preventDefault();
    if (button.hasAttribute("data-chrome-copy")) {
      try {
        window.localStorage.setItem(
          transferStorageKey(card),
          JSON.stringify(readTransferPayload(card)),
        );
        transferStatus(card, "Settings copied", false);
      } catch (error) {
        transferStatus(card, "Copy failed", true);
      }
      return;
    }
    try {
      var raw = window.localStorage.getItem(transferStorageKey(card)),
        payload = raw ? JSON.parse(raw) : null;
      if (applyTransferPayload(card, payload)) {
        transferStatus(card, "Settings pasted", false);
      } else {
        transferStatus(card, "No copied settings", true);
      }
    } catch (error) {
      transferStatus(card, "Paste failed", true);
    }
  });
  document.addEventListener("click", function (event) {
    var trigger =
      event.target.closest &&
      event.target.closest(
        ".kidia-fixed-chrome-card .kidia-page-media-choose, .kidia-fixed-chrome-card .kidia-page-media-preview",
      );
    if (!trigger || !window.wp || !wp.media) {
      return;
    }
    var mediaField = trigger.closest(".kidia-page-field--image"),
      card = trigger.closest(".kidia-fixed-chrome-card"),
      input = mediaField && mediaField.querySelector(".kidia-page-media-url"),
      preview =
        mediaField && mediaField.querySelector(".kidia-page-media-preview"),
      clear = card && card.querySelector(".kidia-page-media-clear");
    if (!mediaField || !input || !preview) {
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    var frame = wp.media({
      title: "Choose logo image",
      button: { text: "Use image" },
      library: { type: "image" },
      multiple: false,
    });
    frame.on("select", function () {
      var attachment = frame.state().get("selection").first().toJSON(),
        url = attachment.url || "";
      input.value = url;
      preview.src = url;
      preview.hidden = !url;
      if (clear) {
        clear.hidden = !url;
      }
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
    });
    frame.open();
  });
  document.addEventListener("click", function (event) {
    var clear =
      event.target.closest &&
      event.target.closest(".kidia-fixed-chrome-card .kidia-page-media-clear");
    if (!clear) {
      return;
    }
    var card = clear.closest(".kidia-fixed-chrome-card"),
      mediaField =
        card &&
        (card.querySelector('.kidia-page-field[data-setting="logo_url"]') ||
          clear.closest(".kidia-page-field--image")),
      input = mediaField && mediaField.querySelector(".kidia-page-media-url"),
      preview =
        mediaField && mediaField.querySelector(".kidia-page-media-preview"),
      textInput =
        card &&
        card.querySelector(
          '.kidia-page-field[data-setting="logo_text"] input[type="text"]',
        );
    if (!input || !preview) {
      return;
    }
    event.preventDefault();
    input.value = "";
    preview.src = "";
    preview.hidden = true;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    if (textInput) {
      textInput.dispatchEvent(new Event("input", { bubbles: true }));
      textInput.focus();
    }
  });
  document.addEventListener("input", function (event) {
    if (
      !event.target.matches ||
      !event.target.matches(".kidia-fixed-chrome-card .kidia-page-media-url")
    ) {
      return;
    }
    var fieldNode = event.target.closest(".kidia-page-field--image"),
      card = event.target.closest(".kidia-fixed-chrome-card"),
      preview =
        fieldNode && fieldNode.querySelector(".kidia-page-media-preview"),
      clear = card && card.querySelector(".kidia-page-media-clear"),
      url = event.target.value || "";
    if (preview) {
      preview.src = url;
      preview.hidden = !url;
    }
    if (clear) {
      clear.hidden = !url;
    }
  });
  function allItems(layout) {
    var items = [];
    layout.rows.forEach(function (row) {
      row.columns.forEach(function (column) {
        items = items.concat(column.items);
      });
    });
    return items;
  }
  function restoreSettings(card, part, page) {
    var values =
      part === "footer"
        ? {
            style: page === "product" ? "product_action" : "navigation",
            height: page === "product" ? 84 : 76,
            margin_top: 0,
            margin_bottom: 0,
            space_up: 0,
            space_down: 0,
            side_spacing_percent: 0,
            icon_size: 24,
            label_size: 11,
            icon_label_gap: 3,
            show_labels: true,
            background_color: "#FFFFFF",
            active_color: "#1F6F61",
            inactive_color: "#6B7280",
            button_color: "#2F806E",
            button_text_color: "#FFFFFF",
            button_width_percent: 58,
            button_height: 52,
            button_style: "filled",
            button_shape: "custom",
            button_radius: 28,
            button_border_color: "#1F2933",
            button_border_width: 0,
          }
        : page === "home"
          ? {
              collapse_transition: "smooth_compact",
              compact_search_width_percent: 84,
              height: 120,
              margin_top: 0,
              margin_bottom: 0,
              space_up: 0,
              space_down: 0,
              row_gap: 8,
              vertical_padding: 8,
              horizontal_padding: 16,
              logo_text: "Kidia",
              logo_text_color: "#1F2933",
              logo_width: 132,
              logo_height: 42,
              cart_size: 26,
              search_width_percent: 100,
              search_height: 44,
              search_radius: 22,
              search_background: "#F4F5F5",
              search_text_color: "#5F6368",
              background_color: "#FFFFFF",
              icon_color: "#1F2933",
              show_cart_badge: false,
            }
          : {
              height: 64,
              margin_top: 0,
              margin_bottom: 0,
              space_up: 0,
              space_down: 0,
              row_gap: 8,
              vertical_padding: 8,
              horizontal_padding: 16,
              logo_text: "Kidia",
              logo_text_color: "#1F2933",
              background_color: "#FFFFFF",
              icon_color: "#1F2933",
              show_cart_badge: false,
            };
    Object.keys(values).forEach(function (key) {
      var input = field(card, key);
      if (!input) {
        return;
      }
      if (input.type === "checkbox") {
        input.checked = !!values[key];
      } else {
        input.value = String(values[key]);
      }
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
    });
  }
  function syncHeaderRowFields(card, layout, part, variant) {
    if (part !== "header" || variant === "collapsed") {
      return;
    }
    var rows = layout.rows || [],
      multi = rows.length > 1,
      secondActive =
        multi &&
        rows[1] &&
        (rows[1].columns || []).some(function (column) {
          return (column.items || []).length > 0;
        }),
      single = ["height"],
      multiple = [
        "row_1_height",
        "row_1_position",
        "row_2_height",
        "row_2_position",
        "row_merge",
      ];
    single.forEach(function (key) {
      var input = field(card, key),
        wrap = input && input.closest(".kidia-page-field");
      if (wrap) {
        wrap.hidden = multi;
      }
    });
    multiple.forEach(function (key) {
      var input = field(card, key),
        wrap = input && input.closest(".kidia-page-field");
      if (wrap) {
        wrap.hidden = !multi;
        wrap.classList.toggle(
          "is-disabled",
          multi &&
            !secondActive &&
            (key === "row_2_height" ||
              key === "row_2_position" ||
              key === "row_merge"),
        );
      }
      if (input) {
        input.disabled =
          multi &&
          !secondActive &&
          (key === "row_2_height" ||
            key === "row_2_position" ||
            key === "row_merge");
      }
    });
  }
  function boot(composer) {
    var part = composer.dataset.part,
      variant = composer.dataset.variant || "original",
      input = composer.querySelector(".kidia-chrome-layout-json"),
      canvas = composer.querySelector(".kidia-chrome-layout"),
      palette = composer.querySelector(".kidia-chrome-palette__items"),
      reset = composer.querySelector(".kidia-chrome-reset"),
      card = composer.closest(".kidia-fixed-chrome-card");
    if (!input || !canvas || !palette || !card) {
      return;
    }
    var layout = normalize(parse(input, part));
    function tile(item) {
      var source = palette.querySelector('[data-item="' + item + '"]'),
        node = document.createElement("button");
      node.type = "button";
      node.draggable = true;
      node.className = "kidia-chrome-item is-active";
      node.dataset.item = item;
      node.innerHTML =
        '<span class="dashicons dashicons-move"></span>' +
        (source ? source.textContent.trim() : item) +
        '<span class="kidia-chrome-remove">×</span>';
      return node;
    }
    function rowTotal(row) {
      return (
        Math.round(
          row.columns.reduce(function (total, column) {
            return total + Number(column.width || 0);
          }, 0) * 100,
        ) / 100
      );
    }
    function valid() {
      return layout.rows.every(function (row) {
        return Math.abs(rowTotal(row) - 100) < 0.01;
      });
    }
    function save() {
      normalize(layout);
      input.value = JSON.stringify(layout);
      composer.classList.toggle("has-invalid-layout", !valid());
      input.dispatchEvent(new Event("input", { bubbles: true }));
    }
    function columnsTemplate(row) {
      return row.columns
        .map(function (column) {
          return "minmax(0," + column.width + "fr)";
        })
        .join(" ");
    }
    function render() {
      normalize(layout);
      syncHeaderRowFields(card, layout, part, variant);
      canvas.innerHTML = "";
      layout.rows.forEach(function (row, rowIndex) {
        var wrap = document.createElement("div");
        wrap.className = "kidia-chrome-row";
        var toolbar = document.createElement("div");
        toolbar.className = "kidia-chrome-row-toolbar";
        toolbar.innerHTML =
          "<strong>Row " +
          (rowIndex + 1) +
          '</strong><label>Columns <select class="kidia-row-column-count" data-row="' +
          rowIndex +
          '">' +
          [1, 2, 3, 4, 5, 6]
            .map(function (count) {
              return (
                '<option value="' +
                count +
                '"' +
                (count === row.columns.length ? " selected" : "") +
                ">" +
                count +
                "</option>"
              );
            })
            .join("") +
          '</select></label><span class="kidia-row-total">Total: ' +
          Math.round(
            row.columns.reduce(function (total, column) {
              return total + Number(column.width);
            }, 0) * 100,
          ) /
            100 +
          "%</span>" +
          (rowIndex === layout.rows.length - 1 && layout.rows.length < 3
            ? '<button type="button" class="button kidia-chrome-add-row">+ Add row</button>'
            : "") +
          (layout.rows.length > 1
            ? '<button type="button" class="kidia-chrome-remove-row" data-row="' +
              rowIndex +
              '">×</button>'
            : "");
        wrap.appendChild(toolbar);
        var grid = document.createElement("div");
        grid.className = "kidia-chrome-row-grid";
        grid.style.gridTemplateColumns = columnsTemplate(row);
        row.columns.forEach(function (column, columnIndex) {
          var cell = document.createElement("div");
          cell.className = "kidia-chrome-column";
          cell.innerHTML =
            '<label>Width % <input class="kidia-column-width" type="number" min="1" max="100" step="0.01" data-row="' +
            rowIndex +
            '" data-column="' +
            columnIndex +
            '" value="' +
            column.width +
            '"></label>';
          var zone = document.createElement("div");
          zone.className = "kidia-chrome-zone";
          zone.dataset.row = String(rowIndex);
          zone.dataset.column = String(columnIndex);
          column.items.forEach(function (item) {
            zone.appendChild(tile(item));
          });
          if (!column.items.length) {
            zone.innerHTML = "<span>Drop here</span>";
          }
          cell.appendChild(zone);
          grid.appendChild(cell);
        });
        wrap.appendChild(grid);
        canvas.appendChild(wrap);
      });
      var used = allItems(layout),
        configured = [];
      Array.prototype.forEach.call(
        card.querySelectorAll(".kidia-chrome-composer"),
        function (other) {
          var otherInput = other.querySelector(".kidia-chrome-layout-json");
          configured = configured.concat(
            allItems(normalize(parse(otherInput, part))),
          );
        },
      );
      Array.prototype.forEach.call(
        palette.querySelectorAll(".kidia-chrome-item"),
        function (item) {
          item.hidden = used.indexOf(item.dataset.item) !== -1;
        },
      );
      Array.prototype.forEach.call(
        card.querySelectorAll("[data-item-section],[data-footer-item-setting]"),
        function (section) {
          var item =
            section.dataset.itemSection || section.dataset.footerItemSetting;
          section.hidden = configured.indexOf(item) === -1;
        },
      );
    }
    function removeItem(item) {
      layout.rows.forEach(function (row) {
        row.columns.forEach(function (column) {
          column.items = column.items.filter(function (value) {
            return value !== item;
          });
        });
      });
    }
    function insert(item, target, before) {
      removeItem(item);
      var destination =
          layout.rows[Number(target.dataset.row)].columns[
            Number(target.dataset.column)
          ].items,
        index = before ? destination.indexOf(before) : -1;
      if (index < 0) {
        destination.push(item);
      } else {
        destination.splice(index, 0, item);
      }
      save();
      render();
    }
    function fillAutomaticWidth(target) {
      if (
        !target ||
        !target.matches(".kidia-column-width") ||
        String(target.value).trim() !== ""
      ) {
        return;
      }
      var rowNode = target.closest(".kidia-chrome-row"),
        total = 0;
      if (!rowNode) {
        return;
      }
      Array.prototype.forEach.call(
        rowNode.querySelectorAll(".kidia-column-width"),
        function (control) {
          if (control !== target) {
            total += Number(control.value) || 0;
          }
        },
      );
      target.value = String(
        Math.max(1, Math.min(100, Math.round((100 - total) * 100) / 100)),
      );
      target.dispatchEvent(new Event("input", { bubbles: true }));
    }
    composer.addEventListener("dragstart", function (event) {
      var item = event.target.closest(".kidia-chrome-item");
      if (!item) {
        return;
      }
      dragged = item.dataset.item;
      event.dataTransfer.setData("text/plain", dragged);
    });
    composer.addEventListener("dragover", function (event) {
      if (event.target.closest(".kidia-chrome-zone,.kidia-chrome-palette")) {
        event.preventDefault();
      }
    });
    composer.addEventListener("drop", function (event) {
      var paletteTarget = event.target.closest(".kidia-chrome-palette");
      if (paletteTarget) {
        event.preventDefault();
        removeItem(dragged || event.dataTransfer.getData("text/plain"));
        dragged = null;
        save();
        render();
        return;
      }
      var target = event.target.closest(".kidia-chrome-zone");
      if (!target) {
        return;
      }
      event.preventDefault();
      var before = event.target.closest(".kidia-chrome-item");
      insert(
        dragged || event.dataTransfer.getData("text/plain"),
        target,
        before ? before.dataset.item : null,
      );
      dragged = null;
    });
    composer.addEventListener("focusin", function (event) {
      fillAutomaticWidth(event.target);
    });
    composer.addEventListener("click", function (event) {
      fillAutomaticWidth(event.target);
    });
    composer.addEventListener("input", function (event) {
      if (event.target.matches(".kidia-column-width")) {
        var rowIndex = Number(event.target.dataset.row),
          row = layout.rows[rowIndex],
          rowNode = event.target.closest(".kidia-chrome-row");
        row.columns[Number(event.target.dataset.column)].width =
          Number(event.target.value) || 1;
        save();
        rowNode.querySelector(
          ".kidia-chrome-row-grid",
        ).style.gridTemplateColumns = columnsTemplate(row);
        rowNode.querySelector(".kidia-row-total").textContent =
          "Total: " + rowTotal(row) + "%";
        rowNode.classList.toggle(
          "is-invalid",
          Math.abs(rowTotal(row) - 100) > 0.01,
        );
      }
    });
    composer.addEventListener("change", function (event) {
      if (event.target.matches(".kidia-row-column-count")) {
        var row = layout.rows[Number(event.target.dataset.row)],
          count = Number(event.target.value),
          items = [];
        row.columns.forEach(function (column) {
          items = items.concat(column.items);
        });
        row.columns = makeRow(count).columns;
        items.forEach(function (item, index) {
          row.columns[Math.min(index, count - 1)].items.push(item);
        });
        save();
        render();
      }
    });
    composer.addEventListener("click", function (event) {
      var remove = event.target.closest(".kidia-chrome-remove");
      if (remove) {
        removeItem(remove.closest(".kidia-chrome-item").dataset.item);
        save();
        render();
        return;
      }
      var paletteItem = event.target.closest(
        ".kidia-chrome-palette .kidia-chrome-item",
      );
      if (paletteItem) {
        var target = canvas.querySelector(".kidia-chrome-zone");
        if (target) {
          insert(paletteItem.dataset.item, target, null);
        }
        return;
      }
      var add = event.target.closest(".kidia-chrome-add-row");
      if (add) {
        layout.rows.push(makeRow(1));
        save();
        render();
        return;
      }
      var removeRow = event.target.closest(".kidia-chrome-remove-row");
      if (removeRow) {
        layout.rows.splice(Number(removeRow.dataset.row), 1);
        save();
        render();
        return;
      }
    });
    card.addEventListener("click", function (event) {
      var option = event.target.closest(".kidia-chrome-icon-option");
      if (!option) {
        return;
      }
      var choice = option.closest(
        ".kidia-chrome-icon-choice,.kidia-chrome-footer-icon-row",
      );
      if (!choice) {
        return;
      }
      var select = choice.querySelector(".kidia-chrome-icon-select");
      if (!select) {
        return;
      }
      select.value = option.dataset.iconValue;
      Array.prototype.forEach.call(
        choice.querySelectorAll(".kidia-chrome-icon-option"),
        function (button) {
          button.classList.toggle("is-selected", button === option);
          button.setAttribute(
            "aria-pressed",
            button === option ? "true" : "false",
          );
        },
      );
      select.dispatchEvent(new Event("input", { bubbles: true }));
      select.dispatchEvent(new Event("change", { bubbles: true }));
    });
    composer.addEventListener("kidia:chrome-layout-replaced", function () {
      layout = normalize(parse(input, part));
      render();
      composer.classList.toggle("has-invalid-layout", !valid());
    });
    var form = composer.closest("form");
    if (form) {
      form.addEventListener(
        "submit",
        function (event) {
          if (!valid()) {
            event.preventDefault();
            event.stopImmediatePropagation();
            composer.classList.add("has-invalid-layout");
            Array.prototype.forEach.call(
              canvas.querySelectorAll(".kidia-chrome-row"),
              function (node, index) {
                node.classList.toggle(
                  "is-invalid",
                  Math.abs(rowTotal(layout.rows[index]) - 100) > 0.01,
                );
              },
            );
            var invalid = canvas.querySelector(".is-invalid");
            if (invalid && invalid.scrollIntoView) {
              invalid.scrollIntoView({ behavior: "smooth", block: "center" });
            }
          }
        },
        true,
      );
    }
    reset.addEventListener("click", function () {
      var page = composer.dataset.page || "catalog";
      layout =
        variant === "collapsed" ? collapsedDefault() : pageDefault(part, page);
      if (variant !== "collapsed") {
        restoreSettings(card, part, page);
      }
      save();
      render();
    });
    render();
    composer.classList.toggle("has-invalid-layout", !valid());
  }
  document.addEventListener("DOMContentLoaded", function () {
    Array.prototype.forEach.call(
      document.querySelectorAll(".kidia-fixed-chrome-card"),
      syncCollapsedVisibility,
    );
    Array.prototype.forEach.call(
      document.querySelectorAll(".kidia-chrome-composer"),
      boot,
    );
  });
})();
