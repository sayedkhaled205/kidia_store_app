<?php
/**
 * Image Banner admin module.
 *
 * @package Kidia_Mobile_CMS
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'Kidia_Mobile_CMS_Image_Banner', false ) ) {
	return;
}

final class Kidia_Mobile_CMS_Image_Banner {

	private const OPTION_NAME = 'kidia_mobile_image_banner';
	private const CAPABILITY  = 'manage_options';
	private const PAGE_SLUG   = 'kidia-mobile-image-banner';

	/**
	 * Registers module hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action(
			'admin_menu',
			array( $this, 'register_menu' )
		);

		add_action(
			'admin_post_kidia_mobile_save_image_banner',
			array( $this, 'save' )
		);
	}

	/**
	 * Registers submenu.
	 *
	 * @return void
	 */
	public function register_menu(): void {
		add_submenu_page(
			'kidia-mobile-cms',
			__( 'Image Banner', 'kidia-mobile-cms' ),
			__( 'Image Banner', 'kidia-mobile-cms' ),
			self::CAPABILITY,
			self::PAGE_SLUG,
			array( $this, 'render_page' )
		);
	}

	/**
	 * Renders Image Banner page.
	 *
	 * @return void
	 */
	public function render_page(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die(
				esc_html__(
					'You do not have permission to access this page.',
					'kidia-mobile-cms'
				)
			);
		}

		wp_enqueue_media();

		$config = $this->get_config();

		?>
		<div class="wrap">
			<h1>
				<?php echo esc_html__( 'App Image Banner', 'kidia-mobile-cms' ); ?>
			</h1>

			<?php if ( isset( $_GET['updated'] ) && '1' === sanitize_key( wp_unslash( $_GET['updated'] ) ) ) : ?>
				<div class="notice notice-success is-dismissible">
					<p>
						<?php echo esc_html__( 'Image Banner saved successfully.', 'kidia-mobile-cms' ); ?>
					</p>
				</div>
			<?php endif; ?>

			<form
				method="post"
				action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
			>
				<input
					type="hidden"
					name="action"
					value="kidia_mobile_save_image_banner"
				>

				<?php
				wp_nonce_field(
					'kidia_mobile_save_image_banner',
					'kidia_mobile_image_banner_nonce'
				);
				?>

				<table class="form-table" role="presentation">
					<tbody>
						<tr>
							<th scope="row">
								<?php echo esc_html__( 'Status', 'kidia-mobile-cms' ); ?>
							</th>

							<td>
								<label>
									<input
										type="checkbox"
										name="enabled"
										value="1"
										<?php checked( true, (bool) $config['enabled'] ); ?>
									>

									<?php echo esc_html__( 'Show Image Banner in the app', 'kidia-mobile-cms' ); ?>
								</label>
							</td>
						</tr>

						<tr>
							<th scope="row">
								<label for="kidia-banner-image-url">
									<?php echo esc_html__( 'Banner Image', 'kidia-mobile-cms' ); ?>
								</label>
							</th>

							<td>
								<input
									id="kidia-banner-image-url"
									type="url"
									name="image_url"
									value="<?php echo esc_attr( $config['image_url'] ); ?>"
									class="regular-text"
								>

								<button
									type="button"
									class="button"
									id="kidia-select-banner-image"
								>
									<?php echo esc_html__( 'Select from Media Library', 'kidia-mobile-cms' ); ?>
								</button>

								<br>

								<img
									id="kidia-banner-preview"
									src="<?php echo esc_url( $config['image_url'] ); ?>"
									alt=""
									style="
										<?php echo empty( $config['image_url'] ) ? 'display:none;' : ''; ?>
										width:100%;
										max-width:650px;
										height:240px;
										margin-top:14px;
										border-radius:12px;
										object-fit:cover;
										background:#f0f0f1;
									"
								>
							</td>
						</tr>

						<tr>
							<th scope="row">
								<label for="kidia-banner-label">
									<?php echo esc_html__( 'Accessibility Label', 'kidia-mobile-cms' ); ?>
								</label>
							</th>

							<td>
								<input
									id="kidia-banner-label"
									type="text"
									name="semantic_label"
									value="<?php echo esc_attr( $config['semantic_label'] ); ?>"
									class="regular-text"
								>
							</td>
						</tr>

						<tr>
							<th scope="row">
								<label for="kidia-banner-aspect-ratio">
									<?php echo esc_html__( 'Aspect Ratio', 'kidia-mobile-cms' ); ?>
								</label>
							</th>

							<td>
								<input
									id="kidia-banner-aspect-ratio"
									type="number"
									name="aspect_ratio"
									value="<?php echo esc_attr( (string) $config['aspect_ratio'] ); ?>"
									min="1"
									max="5"
									step="0.1"
								>
							</td>
						</tr>

						<tr>
							<th scope="row">
								<label for="kidia-banner-radius">
									<?php echo esc_html__( 'Border Radius', 'kidia-mobile-cms' ); ?>
								</label>
							</th>

							<td>
								<input
									id="kidia-banner-radius"
									type="number"
									name="border_radius"
									value="<?php echo esc_attr( (string) $config['border_radius'] ); ?>"
									min="0"
									max="48"
									step="1"
								>
							</td>
						</tr>

						<tr>
							<th scope="row">
								<label for="kidia-banner-action-type">
									<?php echo esc_html__( 'Action Type', 'kidia-mobile-cms' ); ?>
								</label>
							</th>

							<td>
								<select
									id="kidia-banner-action-type"
									name="action_type"
								>
									<option value="">
										<?php echo esc_html__( 'No Action', 'kidia-mobile-cms' ); ?>
									</option>

									<option value="product" <?php selected( 'product', $config['action_type'] ); ?>>
										<?php echo esc_html__( 'Product', 'kidia-mobile-cms' ); ?>
									</option>

									<option value="category" <?php selected( 'category', $config['action_type'] ); ?>>
										<?php echo esc_html__( 'Category', 'kidia-mobile-cms' ); ?>
									</option>

									<option value="collection" <?php selected( 'collection', $config['action_type'] ); ?>>
										<?php echo esc_html__( 'Collection', 'kidia-mobile-cms' ); ?>
									</option>

									<option value="search" <?php selected( 'search', $config['action_type'] ); ?>>
										<?php echo esc_html__( 'Search', 'kidia-mobile-cms' ); ?>
									</option>

									<option value="external" <?php selected( 'external', $config['action_type'] ); ?>>
										<?php echo esc_html__( 'External URL', 'kidia-mobile-cms' ); ?>
									</option>
								</select>
							</td>
						</tr>

						<tr>
							<th scope="row">
								<label for="kidia-banner-action-value">
									<?php echo esc_html__( 'Action Value', 'kidia-mobile-cms' ); ?>
								</label>
							</th>

							<td>
								<input
									id="kidia-banner-action-value"
									type="text"
									name="action_value"
									value="<?php echo esc_attr( $config['action_value'] ); ?>"
									class="regular-text"
								>
							</td>
						</tr>
					</tbody>
				</table>

				<?php
				submit_button(
					__( 'Save Image Banner', 'kidia-mobile-cms' )
				);
				?>
			</form>
		</div>

		<script>
			(function () {
				'use strict';

				const button = document.getElementById(
					'kidia-select-banner-image'
				);

				const input = document.getElementById(
					'kidia-banner-image-url'
				);

				const preview = document.getElementById(
					'kidia-banner-preview'
				);

				if (!button || !input || !preview) {
					return;
				}

				button.addEventListener('click', function () {
					if (typeof wp === 'undefined' || !wp.media) {
						return;
					}

					const frame = wp.media({
						title: 'Select Banner Image',
						button: {
							text: 'Use this image'
						},
						multiple: false,
						library: {
							type: 'image'
						}
					});

					frame.on('select', function () {
						const attachment = frame
							.state()
							.get('selection')
							.first()
							.toJSON();

						input.value = attachment.url || '';
						preview.src = attachment.url || '';
						preview.style.display = attachment.url
							? 'block'
							: 'none';
					});

					frame.open();
				});
			})();
		</script>
		<?php
	}

	/**
	 * Saves Image Banner.
	 *
	 * @return void
	 */
	public function save(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die(
				esc_html__(
					'You do not have permission to perform this action.',
					'kidia-mobile-cms'
				)
			);
		}

		check_admin_referer(
			'kidia_mobile_save_image_banner',
			'kidia_mobile_image_banner_nonce'
		);

		$action_type = isset( $_POST['action_type'] )
			? sanitize_key( $_POST['action_type'] )
			: '';

		$allowed_action_types = array(
			'',
			'product',
			'category',
			'collection',
			'search',
			'external',
		);

		if ( ! in_array( $action_type, $allowed_action_types, true ) ) {
			$action_type = '';
		}

		$aspect_ratio = isset( $_POST['aspect_ratio'] )
			? (float) $_POST['aspect_ratio']
			: 2.4;

		$aspect_ratio = max( 1, min( 5, $aspect_ratio ) );

		$border_radius = isset( $_POST['border_radius'] )
			? (float) $_POST['border_radius']
			: 20;

		$border_radius = max( 0, min( 48, $border_radius ) );

		update_option(
			self::OPTION_NAME,
			array(
				'enabled'        => isset( $_POST['enabled'] ),
				'image_url'      => isset( $_POST['image_url'] )
					? esc_url_raw( $_POST['image_url'] )
					: '',
				'semantic_label' => isset( $_POST['semantic_label'] )
					? sanitize_text_field( $_POST['semantic_label'] )
					: '',
				'aspect_ratio'   => $aspect_ratio,
				'border_radius'  => $border_radius,
				'action_type'    => $action_type,
				'action_value'   => isset( $_POST['action_value'] )
					? sanitize_text_field( $_POST['action_value'] )
					: '',
				'updated_at'     => gmdate( 'c' ),
			),
			false
		);

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => self::PAGE_SLUG,
					'updated' => '1',
				),
				admin_url( 'admin.php' )
			)
		);

		exit;
	}

	/**
	 * Returns configuration.
	 *
	 * @return array<string, mixed>
	 */
	private function get_config(): array {
		$config = get_option(
			self::OPTION_NAME,
			array()
		);

		if ( ! is_array( $config ) ) {
			$config = array();
		}

		return array(
			'enabled'        => isset( $config['enabled'] )
				? (bool) $config['enabled']
				: true,
			'image_url'      => isset( $config['image_url'] )
				? (string) $config['image_url']
				: '',
			'semantic_label' => isset( $config['semantic_label'] )
				? (string) $config['semantic_label']
				: '',
			'aspect_ratio'   => isset( $config['aspect_ratio'] )
				? (float) $config['aspect_ratio']
				: 2.4,
			'border_radius'  => isset( $config['border_radius'] )
				? (float) $config['border_radius']
				: 20,
			'action_type'    => isset( $config['action_type'] )
				? (string) $config['action_type']
				: '',
			'action_value'   => isset( $config['action_value'] )
				? (string) $config['action_value']
				: '',
		);
	}
}