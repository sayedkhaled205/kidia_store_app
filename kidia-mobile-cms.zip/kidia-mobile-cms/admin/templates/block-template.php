<?php
/**
 * Home Builder block template.
 *
 * Available variables:
 *
 * @var Kidia_Mobile_Block $block
 * @var array<string,mixed> $block_data
 * @var int|string $index
 */

defined( 'ABSPATH' ) || exit;

$type = isset( $block_data['type'] )
	? (string) $block_data['type']
	: '';

$name = isset( $block_data['name'] )
	? (string) $block_data['name']
	: $block->get_label();

$library_id = isset( $block_data['library_id'] )
	? (string) $block_data['library_id']
	: (string) $block_data['id'];

$status = 'published' === ( $block_data['status'] ?? 'draft' )
	? 'published'
	: 'draft';
$settings = isset( $block_data['settings'] ) && is_array( $block_data['settings'] ) ? $block_data['settings'] : $block->get_default_settings();
$element_icon = isset( $block_data['element_icon'] ) ? (string) $block_data['element_icon'] : 'dashicons-screenoptions';
$element_category_key = isset( $block_data['element_category_key'] ) ? (string) $block_data['element_category_key'] : 'content';
$element_category_label = isset( $block_data['element_category_label'] ) ? (string) $block_data['element_category_label'] : __( 'Content', 'kidia-mobile-cms' );
?>

<div
	class="kidia-builder-block is-collapsed"
	draggable="true"
	data-type="<?php echo esc_attr( $type ); ?>"
	data-library-id="<?php echo esc_attr( $library_id ); ?>"
	data-label="<?php echo esc_attr( $block->get_label() ); ?>"
	data-element-category="<?php echo esc_attr( $element_category_key ); ?>"
>

	<div class="kidia-builder-block__header">

		<div class="kidia-builder-block__left">

			<span class="dashicons dashicons-move kidia-builder-drag" title="<?php esc_attr_e( 'Drag to reorder', 'kidia-mobile-cms' ); ?>"></span>

			<span class="kidia-builder-block__icon" aria-hidden="true">
				<span class="dashicons <?php echo esc_attr( $element_icon ); ?>"></span>
			</span>

			<div class="kidia-builder-block__title">

				<strong class="kidia-block-name">
					<?php echo esc_html( $name ); ?>
				</strong>

				<span class="kidia-builder-block__type">
					<?php echo esc_html( $block->get_label() ); ?>
				</span>

				<span class="kidia-builder-block__category">
					<?php echo esc_html( $element_category_label ); ?>
				</span>

			</div>

		</div>

		<div class="kidia-builder-block__actions kidia-card-actions">

			<label class="kidia-builder-switch kidia-builder-switch--card kidia-card-action kidia-card-action--toggle" title="<?php esc_attr_e( 'Show or hide this element', 'kidia-mobile-cms' ); ?>">
				<input type="checkbox" name="blocks[<?php echo esc_attr( (string) $index ); ?>][enabled]" value="1" <?php checked( true, ! empty( $block_data['enabled'] ) ); ?>>
				<span class="kidia-builder-switch__track"></span>
				<span class="kidia-builder-switch__state"></span>
			</label>

			<button
				type="button"
				class="button kidia-toggle-block-settings kidia-card-action kidia-card-action--expand"
				aria-label="<?php esc_attr_e( 'Open element settings', 'kidia-mobile-cms' ); ?>"
			>
				<span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>
			</button>

			<button
				type="button"
				class="button kidia-duplicate-block kidia-card-action kidia-card-action--secondary"
			>
				<span class="dashicons dashicons-admin-page" aria-hidden="true"></span>
				<?php esc_html_e(
					'Duplicate',
					'kidia-mobile-cms'
				); ?>
			</button>

			<button
				type="button"
				class="button button-link-delete kidia-delete-block kidia-card-action kidia-card-action--primary"
			>
				<span class="dashicons dashicons-trash" aria-hidden="true"></span>
				<?php esc_html_e(
					'Remove',
					'kidia-mobile-cms'
				); ?>
			</button>

		</div>

	</div>
	<div class="kidia-builder-block__body">

		<input
			type="hidden"
			class="kidia-block-id"
			name="blocks[<?php echo esc_attr( (string) $index ); ?>][id]"
			value="<?php echo esc_attr( (string) $block_data['id'] ); ?>"
		>

		<input
			type="hidden"
			class="kidia-block-library-id"
			name="blocks[<?php echo esc_attr( (string) $index ); ?>][library_id]"
			value="<?php echo esc_attr( $library_id ); ?>"
		>

		<input
			type="hidden"
			class="kidia-block-source-library-id"
			name="blocks[<?php echo esc_attr( (string) $index ); ?>][source_library_id]"
			value=""
		>

		<input
			type="hidden"
			class="kidia-block-create-intent"
			name="blocks[<?php echo esc_attr( (string) $index ); ?>][create_intent]"
			value="0"
		>

		<input
			type="hidden"
			class="kidia-block-type"
			name="blocks[<?php echo esc_attr( (string) $index ); ?>][type]"
			value="<?php echo esc_attr( $type ); ?>"
		>

		<input
			type="hidden"
			class="kidia-block-order"
			name="blocks[<?php echo esc_attr( (string) $index ); ?>][order]"
			value="<?php echo esc_attr( (string) $block_data['order'] ); ?>"
		>

		<input
			type="hidden"
			class="kidia-block-status"
			name="blocks[<?php echo esc_attr( (string) $index ); ?>][status]"
			value="<?php echo esc_attr( $status ); ?>"
		>

		<div class="kidia-builder-essentials">

			<div class="kidia-builder-field kidia-builder-field--name">

			<label>

				<?php
				esc_html_e(
					'Element Name',
					'kidia-mobile-cms'
				);
				?>

			</label>

			<input
				type="text"
				class="kidia-block-name-input"
				name="blocks[<?php echo esc_attr( (string) $index ); ?>][name]"
				value="<?php echo esc_attr( $name ); ?>"
			>

			</div>

			<div class="kidia-builder-field kidia-builder-field--visibility">
				<label for="kidia-status-<?php echo esc_attr( (string) $index ); ?>">
					<?php esc_html_e( 'Visibility', 'kidia-mobile-cms' ); ?>
				</label>
				<select class="kidia-block-status-select" id="kidia-status-<?php echo esc_attr( (string) $index ); ?>">
					<option value="published" <?php selected( 'published', $status ); ?>><?php esc_html_e( 'Published', 'kidia-mobile-cms' ); ?></option>
					<option value="draft" <?php selected( 'draft', $status ); ?>><?php esc_html_e( 'Draft', 'kidia-mobile-cms' ); ?></option>
				</select>
			</div>

		</div>

		<div class="kidia-builder-inline-settings">
			<div class="kidia-builder-settings-heading">
				<span class="dashicons dashicons-admin-generic" aria-hidden="true"></span>
				<strong><?php esc_html_e( 'Element Settings', 'kidia-mobile-cms' ); ?></strong>
			</div>

			<div class="kidia-builder-settings-content">
				<div class="kidia-builder-field kidia-section-layout-field"><label><?php esc_html_e( 'Merge up', 'kidia-mobile-cms' ); ?></label><input type="number" min="0" max="80" name="blocks[<?php echo esc_attr( (string) $index ); ?>][settings][margin_top]" value="<?php echo esc_attr( (string) ( $settings['margin_top'] ?? 0 ) ); ?>"></div>
				<div class="kidia-builder-field kidia-section-layout-field"><label><?php esc_html_e( 'Merge down', 'kidia-mobile-cms' ); ?></label><input type="number" min="0" max="80" name="blocks[<?php echo esc_attr( (string) $index ); ?>][settings][margin_bottom]" value="<?php echo esc_attr( (string) ( $settings['margin_bottom'] ?? 0 ) ); ?>"></div>
				<div class="kidia-builder-field kidia-section-layout-field"><label><?php esc_html_e( 'Space up', 'kidia-mobile-cms' ); ?></label><input type="number" min="0" max="80" name="blocks[<?php echo esc_attr( (string) $index ); ?>][settings][space_up]" value="<?php echo esc_attr( (string) ( $settings['space_up'] ?? $settings['padding_vertical'] ?? 0 ) ); ?>"></div>
				<div class="kidia-builder-field kidia-section-layout-field"><label><?php esc_html_e( 'Space down', 'kidia-mobile-cms' ); ?></label><input type="number" min="0" max="80" name="blocks[<?php echo esc_attr( (string) $index ); ?>][settings][space_down]" value="<?php echo esc_attr( (string) ( $settings['space_down'] ?? $settings['padding_vertical'] ?? 0 ) ); ?>"></div>
				<div class="kidia-builder-field kidia-builder-field--background kidia-section-layout-field"><label><?php esc_html_e( 'Background color', 'kidia-mobile-cms' ); ?></label><div class="kidia-builder-background-control"><input type="color" class="kidia-block-background-picker" value="<?php echo esc_attr( sanitize_hex_color( (string) ( $settings['block_background'] ?? '' ) ) ?: '#FFFFFF' ); ?>"><input type="text" class="kidia-block-background-value" name="blocks[<?php echo esc_attr( (string) $index ); ?>][settings][block_background]" value="<?php echo esc_attr( (string) ( $settings['block_background'] ?? '' ) ); ?>" placeholder="transparent"></div></div>
				<?php
				$block->render_settings( (int) $index, $settings );
				?>
			</div>
		</div>

	</div>

</div>
