"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { JSDOM } = require("jsdom");

const pluginRoot = path.join(__dirname, "..");
const script = fs.readFileSync(path.join(pluginRoot, "admin/assets/settings-sections.js"), "utf8");
const css = fs.readFileSync(path.join(pluginRoot, "admin/assets/admin-theme.css"), "utf8");
const pageCss = fs.readFileSync(path.join(pluginRoot, "admin/assets/page-builder.css"), "utf8");
const toolbar = fs.readFileSync(path.join(pluginRoot, "admin/pages/builder-toolbar.php"), "utf8");
const page = fs.readFileSync(path.join(pluginRoot, "admin/pages/page-builder.php"), "utf8");

assert.ok(
  page.indexOf("kidia-wishlist-access-mode") < page.indexOf("$chrome_part = 'header'"),
  "Wishlist access mode must render before Fixed Header.",
);
assert.match(
  pageCss,
  /\.kidia-page-settings-card \+ \.kidia-wishlist-access-mode\s*\{\s*margin-top:10px;\s*\}/,
  "Wishlist Page Settings and access mode cards must keep the same 10px gap as the other page cards.",
);
const home = fs.readFileSync(path.join(pluginRoot, "admin/pages/home-builder.php"), "utf8");
const category = fs.readFileSync(path.join(pluginRoot, "admin/pages/category-builder.php"), "utf8");

const field = (key, type = "text", extraClass = "") => `<div class="kidia-page-field ${extraClass}"><label>${key}<input type="${type}" name="layout[elements][0][settings][${key}]" value="1"></label></div>`;
const position = (key) => `<div class="kidia-page-field"><label>${key}<select name="layout[elements][0][settings][${key}]"><option value="top_start">Top</option><option value="bottom_end">Bottom</option></select></label></div>`;
const dom = new JSDOM(`<!doctype html><body><div class="kidia-page-builder"><section data-element="wishlist_grid"><div class="kidia-page-card__body"><div class="kidia-page-fields">
  ${field("image_ratio")}${field("gap")}${field("card_radius")}${field("products_per_page")}
  ${field("quick_add_enabled", "checkbox")}${position("quick_add_position")}${field("quick_add_icon_variant")}${field("quick_add_icon_style")}${field("quick_add_icon_size")}${field("quick_add_icon_color")}${field("quick_add_background_size")}${field("quick_add_radius")}${field("quick_add_background_color")}${field("quick_add_show_background", "checkbox")}
  ${field("show_wishlist", "checkbox")}${position("product_wishlist_position")}${field("product_wishlist_icon_variant")}${field("product_wishlist_icon_style")}${field("product_wishlist_icon_size")}${field("product_wishlist_icon_color")}${field("product_wishlist_background_size")}${field("product_wishlist_radius")}${field("product_wishlist_background_color")}${field("product_wishlist_show_background", "checkbox")}
</div></div></section></div></body>`, { runScripts: "outside-only" });
dom.window.eval(script);
dom.window.document.dispatchEvent(new dom.window.Event("DOMContentLoaded"));

const document = dom.window.document;
assert.equal(document.querySelectorAll(".kidia-settings-section-title--wishlist_products").length, 1, "The four Wishlist Products groups must become one section.");
assert.equal(document.querySelectorAll(".kidia-settings-section-title--image,.kidia-settings-section-title--layout,.kidia-settings-section-title--colors,.kidia-settings-section-title--products").length, 0, "Wishlist Products must not keep the four old headings.");
assert.equal(document.querySelector(".kidia-product-icon-panel--quick_add > .kidia-settings-section-title").textContent.trim().startsWith("Cart Settings"), true, "Wishlist cart controls must use one Cart Settings panel.");
assert.equal(document.querySelector(".kidia-product-icon-panel--carousel_wishlist > .kidia-settings-section-title").textContent.trim().startsWith("Wishlist Settings"), true, "Wishlist icon controls must use one Wishlist Settings panel.");
assert.match(css, /:is\(\[data-element="product_grid"\], \[data-element="wishlist_grid"\]\).*kidia-product-icon-panel__body/, "Wishlist panels must reuse the approved three-column Product Grid arrangement.");

assert.match(toolbar, /kidia-collapse-all[\s\S]*kidia-expand-all/, "The shared toolbar must provide Collapse All and Expand All.");
[home, page, category].forEach((template) => assert.match(template, /admin\/pages\/builder-toolbar\.php/, "Every builder must render the same toolbar template."));
assert.match(toolbar, /name="layout\[enabled\]"/, "Every shared page builder toolbar must expose a page-level On/Off value.");
assert.match(toolbar, /kidia-page-availability/, "The page-level On/Off control must have one shared visual contract.");
assert.match(home, /\$kidia_toolbar_page_toggle\s*=\s*false;/, "Home must not expose Page status because it is always required.");
assert.match(page, /\$kidia_toolbar_page_toggle\s*=\s*true;/, "Every optional shared page must expose Page status in its toolbar.");
assert.match(category, /\$kidia_toolbar_page_toggle\s*=\s*true;/, "Category must expose Page status in its toolbar.");
assert.match(css, /\.kidia-shared-builder-toolbar \.kidia-page-availability\s*\{[^}]*width:236px;[^}]*grid-template-columns:42px minmax\(118px,1fr\) 38px;/, "Page status must reserve separate switch, label, and icon columns without overlap.");
assert.match(css, /\.kidia-shared-builder-toolbar \.kidia-page-availability__copy\s*\{[^}]*display:\s*flex !important;[^}]*flex-direction:\s*row;[^}]*white-space:\s*nowrap;/, "Page status and Active or Disabled must stay on one line on every optional page.");
assert.doesNotMatch(toolbar, /kidia-builder-toolbar__context/, "The shared toolbar must not repeat the current page title.");
assert.match(css, /kidia-builder-toolbar__actions,.kidia-builder-toolbar__save\)[^{]*\{[^}]*flex-wrap:\s*nowrap;/, "Desktop builder toolbar controls must stay on one row.");

console.log("Shared builder toolbar and Wishlist Products settings layout: ok");

const relatedDom = new JSDOM(`<!doctype html><body><div class="kidia-page-builder"><section data-element="related_products"><div class="kidia-page-card__body"><div class="kidia-page-fields">
  ${field("title")}${field("columns")}${field("gap")}${field("image_ratio")}${field("show_price", "checkbox")}${field("show_quick_add", "checkbox")}
  ${field("margin_top", "number", "kidia-section-layout-field")}${field("margin_bottom", "number", "kidia-section-layout-field")}${field("space_up", "number", "kidia-section-layout-field")}${field("space_down", "number", "kidia-section-layout-field")}${field("background_color", "color", "kidia-section-layout-field")}
</div></div></section></div></body>`, { runScripts: "outside-only" });
relatedDom.window.eval(script);
relatedDom.window.document.dispatchEvent(new relatedDom.window.Event("DOMContentLoaded"));
const relatedDocument = relatedDom.window.document;
assert.equal(relatedDocument.querySelectorAll(".kidia-settings-section-title--related_products").length, 1, "Related Products must merge every content section into one.");
assert.equal(relatedDocument.querySelectorAll(".kidia-section-layout-panel").length, 1, "Related Products must keep one isolated standard Section Layout Settings panel.");
assert.equal(relatedDocument.querySelectorAll(".kidia-section-layout-panel .kidia-page-field").length, 5, "The standard Related Products layout panel must contain only the five canonical layout fields.");
