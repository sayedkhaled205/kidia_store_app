"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { JSDOM } = require("jsdom");

const script = fs.readFileSync(
  path.resolve(__dirname, "..", "admin", "assets", "cms-shell.js"),
  "utf8"
);
const admin = fs.readFileSync(path.resolve(__dirname, "..", "admin", "class-kidia-mobile-cms-admin.php"), "utf8");
const styles = fs.readFileSync(
  path.resolve(__dirname, "..", "admin", "assets", "cms-shell.css"),
  "utf8"
);

assert.match(
  styles,
  /#wpbody-content\{\s*min-height:calc\(100vh - 68px\)!important;/,
  "Every desktop CMS workspace must reach at least the bottom of the shared sidebar."
);
assert.match(
  styles,
  /html\{[\s\S]*overflow-x:clip;[\s\S]*overflow-y:scroll;[\s\S]*scrollbar-gutter:stable;/,
  "The WordPress document must keep a stable vertical gutter without horizontal page scrolling."
);
assert.match(
  styles,
  /html\.kidia-cms-builder-screen,\s*html:has\(body\.kidia-cms-builder-screen\)\{[\s\S]*overflow-x:clip!important;[\s\S]*overflow-y:scroll!important;[\s\S]*scrollbar-gutter:stable!important;/,
  "Entering Customize must keep the outer scrollbar gutter reserved so the shared sidebar cannot shift horizontally."
);
assert.doesNotMatch(
  styles,
  /html\.kidia-cms-builder-screen,\s*html:has\(body\.kidia-cms-builder-screen\),\s*body\.kidia-cms-builder-screen\{[\s\S]*overflow:hidden!important;/,
  "Customize must not hide overflow on the document root and release the shared scrollbar gutter."
);
assert.match(
  styles,
  /\.kidia-cms-sidebar\{[\s\S]*inset-inline-start:-16px;[\s\S]*width:236px;/,
  "The shared sidebar must retain its full width and outer-gutter extension."
);
assert.match(
  styles,
  /body\.kidia-cms-builder-screen #wpbody-content\{[^}]*overflow:visible!important;/,
  "Customize must not clip the sidebar's 16px outer-gutter extension."
);
assert.doesNotMatch(
  styles,
  /body\.kidia-cms-builder-screen #wpbody-content\{[^}]*overflow:hidden!important;/,
  "Customize must not pull the visible sidebar edge left by clipping its outer gutter."
);
assert.match(
  styles,
  /#wpbody-content\{[\s\S]*width:calc\(100% - 36px\);[\s\S]*max-width:calc\(100% - 36px\);/,
  "The shared frame must fit the WordPress content box on every desktop CMS view."
);
assert.doesNotMatch(
  styles,
  /#wpbody-content\{[^}]*width:calc\(100vw/,
  "Viewport-based CMS frame widths must not reintroduce horizontal overflow."
);
assert.match(
  styles,
  /:is\(\.kidia-page-master-toggle,\.kidia-page-toggle\) input\[type="checkbox"\]:checked::before\{[\s\S]*inset-inline-start:23px!important;[\s\S]*transform:none!important;/,
  "Standard page switches must position their thumb logically in both RTL and LTR."
);
assert.match(
  styles,
  /\.kidia-builder-switch input:checked \+ \.kidia-builder-switch__track::after\{[\s\S]*inset-inline-start:21px!important;[\s\S]*transform:none!important;/,
  "Card switches must use the same reliable logical thumb positioning."
);
assert.match(admin, /private const CMS_VIEWS = array[\s\S]*store-data/, "Navigation destinations must be views of one CMS screen.");
assert.match(admin, /wp_ajax_kidia_mobile_cms_view[\s\S]*cms_view_fragment/, "CMS views must use the fragment endpoint.");
assert.match(admin, /Returns one CMS view without another WordPress document, sidebar or frame/, "The endpoint must return view content only.");
assert.match(admin, /'builderScreen'\s*=>\s*\$this->is_builder_screen/, "Every fragment must report whether its view owns the fixed Builder workspace.");
assert.match(admin, /'version'\s*=>\s*KIDIA_MOBILE_CMS_VERSION/, "The shell and every fragment must expose the active plugin version.");
assert.match(script, /version:\s*currentVersion/, "Every fragment request must identify the version of the running shell.");
assert.match(script, /pluginAsset\(asset\)[\s\S]*loaded\.conflict[\s\S]*hardNavigate\(cacheKey\)/, "Only conflicting plugin assets may force a clean document load.");
assert.doesNotMatch(script, /classList\.add\('is-kidia-page-loading'\)/, "Fragment navigation must not dim the existing shell while the next view loads.");
assert.doesNotMatch(script.slice(0, script.indexOf("installPersistentCmsNavigation();")), /window\.location\.assign\(/, "Navigation must not destroy the shell.");
assert.doesNotMatch(script.slice(0, script.indexOf("installPersistentCmsNavigation();")), /DOMParser|response\.text\(/, "Navigation must not fetch and parse another WordPress document.");
const initial = `<!doctype html><html><head><title>Overview</title></head>
<body class="wp-admin kidia-mobile-cms">
  <main id="wpbody-content">
    <aside data-kidia-cms-sidebar>
      <nav class="kidia-cms-sidebar__nav">
        <a class="is-active" data-kidia-sidebar-view="overview" href="https://store.test/wp-admin/admin.php?page=kidia-mobile-cms">Overview</a>
        <a data-kidia-sidebar-view="pages" href="https://store.test/wp-admin/admin.php?page=kidia-mobile-cms&view=home">Design Your Pages</a>
        <a data-kidia-sidebar-view="setup" href="https://store.test/wp-admin/admin.php?page=kidia-mobile-cms&view=setup">Setup Wizard</a>
      </nav>
    </aside>
    <div class="kidia-cms-shell" data-kidia-cms-shell>
      <nav class="kidia-cms-tabs">
        <a class="is-active" data-kidia-page-view="overview" href="https://store.test/wp-admin/admin.php?page=kidia-mobile-cms">Overview</a>
        <a data-kidia-page-view="home" href="https://store.test/wp-admin/admin.php?page=kidia-mobile-cms&view=home">Home</a>
        <a data-kidia-page-view="setup" href="https://store.test/wp-admin/admin.php?page=kidia-mobile-cms&view=setup">Setup Wizard</a>
      </nav>
    </div>
    <section data-page-content>Overview content</section>
  </main>
</body></html>`;
const dom = new JSDOM(initial, {
  runScripts: "outside-only",
  url: "https://store.test/wp-admin/admin.php?page=kidia-mobile-cms"
});
dom.window.scrollTo = () => {};
dom.window.kidiaCMSNavigation = {
  ajaxUrl: "https://store.test/wp-admin/admin-ajax.php",
  nonce: "test-nonce",
  version: "1.45.60"
};
const requestedVersions = [];
dom.window.fetch = async (_url, options = {}) => {
  const request = new URLSearchParams(String(options.body || ""));
  const target = request.get("target") || "";
  requestedVersions.push(request.get("version"));
  const builderScreen = target.includes("view=home");
  return {
    ok: true,
    json: async () => ({
      success: true,
      data: {
        html: `<section data-page-content>${builderScreen ? "Home" : "Setup"} content</section>`,
        view: builderScreen ? "home" : "setup",
        activeSidebar: builderScreen ? "pages" : "setup",
        showPageTabs: builderScreen,
        builderScreen,
        version: "1.45.60",
        styles: [],
        scripts: []
      }
    })
  };
};

const originalSidebar = dom.window.document.querySelector("[data-kidia-cms-sidebar]");
const originalShell = dom.window.document.querySelector("[data-kidia-cms-shell]");
const originalWorkspace = dom.window.document.querySelector("#wpbody-content");
dom.window.eval(script);
originalSidebar.querySelector('[data-kidia-sidebar-view="pages"]').dispatchEvent(
  new dom.window.MouseEvent("click", { bubbles: true, cancelable: true, button: 0 })
);

setTimeout(() => {
  const currentSidebar = dom.window.document.querySelector("[data-kidia-cms-sidebar]");
  assert.strictEqual(currentSidebar, originalSidebar, "Navigation must retain the exact Overview sidebar DOM node.");
  assert.strictEqual(
    dom.window.document.querySelector("[data-kidia-cms-shell]"),
    originalShell,
    "Navigation must retain the exact shared top frame DOM node."
  );
  assert.strictEqual(
    dom.window.document.querySelector("#wpbody-content"),
    originalWorkspace,
    "Navigation must retain the exact shared CMS workspace frame."
  );
  assert.equal(dom.window.document.querySelector("[data-page-content]").textContent, "Home content");
  assert.equal(currentSidebar.querySelector("a.is-active").textContent, "Design Your Pages");
  assert.equal(originalShell.hidden, false);
  assert.equal(dom.window.location.search, "?page=kidia-mobile-cms&view=home");
  assert.equal(dom.window.document.body.classList.contains("kidia-cms-builder-screen"), true, "Entering a Builder fragment must restore the fixed body workspace.");
  assert.equal(dom.window.document.documentElement.classList.contains("kidia-cms-builder-screen"), true, "The document root must lock with the Builder body.");

  originalSidebar.querySelector('[data-kidia-sidebar-view="setup"]').dispatchEvent(
    new dom.window.MouseEvent("click", { bubbles: true, cancelable: true, button: 0 })
  );
  setTimeout(() => {
    assert.equal(dom.window.document.querySelector("[data-page-content]").textContent, "Setup content");
    assert.equal(currentSidebar.querySelector("a.is-active").textContent, "Setup Wizard");
    assert.equal(originalShell.hidden, true);
    assert.equal(dom.window.location.search, "?page=kidia-mobile-cms&view=setup");
    assert.equal(dom.window.document.body.classList.contains("kidia-cms-builder-screen"), false, "Leaving a Builder fragment must release the fixed body workspace.");
    assert.equal(dom.window.document.documentElement.classList.contains("kidia-cms-builder-screen"), false, "The document root must be released with the Builder body.");
    assert.equal(dom.window.document.querySelectorAll("[data-kidia-cms-sidebar]").length, 1);
    assert.equal(dom.window.document.querySelectorAll("[data-kidia-cms-shell]").length, 1);
    assert.deepEqual(requestedVersions, ["1.45.60", "1.45.60"], "Every navigation request must carry the running asset version.");

    const staleDom = new JSDOM(`<!doctype html><html><head>
      <link id="legacy-kidia-shell-css" rel="stylesheet" href="https://store.test/wp-content/plugins/kidia-mobile-cms/admin/assets/cms-shell.css?ver=1.45.52-old">
    </head><body class="wp-admin kidia-mobile-cms">
      <main id="wpbody-content">
        <aside data-kidia-cms-sidebar>
          <a data-kidia-sidebar-view="pages" href="https://store.test/wp-admin/admin.php?page=kidia-mobile-cms&view=home">Design Your Pages</a>
        </aside>
        <div class="kidia-cms-shell" data-kidia-cms-shell>
          <a data-kidia-page-view="home" href="https://store.test/wp-admin/admin.php?page=kidia-mobile-cms&view=home">Home</a>
        </div>
        <section data-page-content>Overview content</section>
      </main>
    </body></html>`, {
      runScripts: "outside-only",
      url: "https://store.test/wp-admin/admin.php?page=kidia-mobile-cms"
    });
    staleDom.window.scrollTo = () => {};
    staleDom.window.kidiaCMSNavigation = {
      ajaxUrl: "https://store.test/wp-admin/admin-ajax.php",
      nonce: "test-nonce",
      version: "1.45.60"
    };
    let forcedUrl = "";
    staleDom.window.kidiaCmsHardNavigate = (url) => {
      forcedUrl = url;
    };
    staleDom.window.fetch = async () => ({
      ok: true,
      json: async () => ({
        success: true,
        data: {
          html: "<section data-page-content>Home content</section>",
          view: "home",
          activeSidebar: "pages",
          showPageTabs: true,
          builderScreen: true,
          version: "1.45.60",
          styles: [{
            handle: "kidia-mobile-cms-shell",
            src: "https://store.test/wp-content/plugins/kidia-mobile-cms/admin/assets/cms-shell.css?ver=1.45.60-new"
          }],
          scripts: []
        }
      })
    });
    staleDom.window.eval(script);
    staleDom.window.document.querySelector('[data-kidia-sidebar-view="pages"]').dispatchEvent(
      new staleDom.window.MouseEvent("click", { bubbles: true, cancelable: true, button: 0 })
    );
    setTimeout(() => {
      assert.equal(
        forcedUrl,
        "https://store.test/wp-admin/admin.php?page=kidia-mobile-cms&view=home",
        "A stale stylesheet must reload the requested view as a clean document."
      );
      assert.equal(
        staleDom.window.document.querySelector("[data-page-content]").textContent,
        "Overview content",
        "The stale shell must not be mutated before the clean document load."
      );
      assert.equal(
        staleDom.window.document.querySelectorAll('link[href*="cms-shell.css"]').length,
        1,
        "Navigation must never combine old and current copies of the shell stylesheet."
      );

      const builderDom = new JSDOM(`<!doctype html><html><head>
        <link id="wp-media-css" rel="stylesheet" href="https://store.test/wp-admin/load-styles.php?c=1&dir=rtl&load=media-views&ver=6.9">
        <link id="kidia-mobile-cms-shell-css" rel="stylesheet" href="https://store.test/wp-content/plugins/kidia-mobile-cms/admin/assets/cms-shell.css?ver=1.45.60-current">
        <script id="jquery-core-js" src="https://store.test/wp-includes/js/jquery/jquery.min.js?ver=3.7.1"></script>
      </head><body class="wp-admin kidia-mobile-cms">
        <main id="wpbody-content">
          <aside data-kidia-cms-sidebar>
            <a data-kidia-sidebar-view="pages" href="https://store.test/wp-admin/admin.php?page=kidia-mobile-cms&view=home">Design Your Pages</a>
          </aside>
          <div class="kidia-cms-shell" data-kidia-cms-shell>
            <a data-kidia-page-view="home" href="https://store.test/wp-admin/admin.php?page=kidia-mobile-cms&view=home">Home</a>
          </div>
          <section data-page-content>Overview content</section>
        </main>
      </body></html>`, {
        runScripts: "outside-only",
        url: "https://store.test/wp-admin/admin.php?page=kidia-mobile-cms"
      });
      builderDom.window.scrollTo = () => {};
      builderDom.window.kidiaCMSNavigation = {
        ajaxUrl: "https://store.test/wp-admin/admin-ajax.php",
        nonce: "test-nonce",
        version: "1.45.60"
      };
      let builderForcedUrl = "";
      builderDom.window.kidiaCmsHardNavigate = (url) => {
        builderForcedUrl = url;
      };
      builderDom.window.fetch = async () => ({
        ok: true,
        json: async () => ({
          success: true,
          data: {
            html: "<section data-page-content>Home Builder content</section>",
            view: "home",
            activeSidebar: "pages",
            showPageTabs: true,
            builderScreen: true,
            version: "1.45.60",
            styles: [
              {
                handle: "wp-media",
                src: "https://store.test/wp-admin/load-styles.php?c=1&dir=rtl&load=media-views&ver=6.9.1"
              },
              {
                handle: "kidia-mobile-cms-shell",
                src: "https://store.test/wp-content/plugins/kidia-mobile-cms/admin/assets/cms-shell.css?ver=1.45.60-current"
              }
            ],
            scripts: [{
              handle: "jquery-core",
              src: "https://store.test/wp-includes/js/jquery/jquery.min.js?ver=3.7.2"
            }]
          }
        })
      });
      const builderSidebar = builderDom.window.document.querySelector("[data-kidia-cms-sidebar]");
      const builderShell = builderDom.window.document.querySelector("[data-kidia-cms-shell]");
      builderDom.window.eval(script);
      builderSidebar.querySelector('[data-kidia-sidebar-view="pages"]').dispatchEvent(
        new builderDom.window.MouseEvent("click", { bubbles: true, cancelable: true, button: 0 })
      );
      setTimeout(() => {
        assert.equal(builderForcedUrl, "", "WordPress and Media query-version differences must not reload the document.");
        assert.strictEqual(builderDom.window.document.querySelector("[data-kidia-cms-sidebar]"), builderSidebar, "Builder navigation must retain the sidebar DOM node.");
        assert.strictEqual(builderDom.window.document.querySelector("[data-kidia-cms-shell]"), builderShell, "Builder navigation must retain the shared frame DOM node.");
        assert.equal(builderDom.window.document.querySelector("[data-page-content]").textContent, "Home Builder content");
        assert.equal(builderDom.window.document.querySelector("#wpbody-content").classList.contains("is-kidia-page-loading"), false);
        console.log("Persistent CMS sidebar and asset version runtime tests passed.");
      }, 25);
    }, 25);
  }, 25);
}, 25);
