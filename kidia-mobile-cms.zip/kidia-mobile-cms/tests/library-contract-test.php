<?php
/**
 * Library normalization contract test with lightweight WordPress stubs.
 *
 * Run with: php kidia-mobile-cms/tests/library-contract-test.php
 */

declare( strict_types=1 );

define( 'ABSPATH', __DIR__ );
define( 'KIDIA_MOBILE_CMS_PATH', dirname( __DIR__ ) . '/' );

$GLOBALS['kidia_test_options'] = array();

function __( string $text, string $domain = '' ): string {
	unset( $domain );
	return $text;
}

function sanitize_key( $value ): string {
	$value = strtolower( (string) $value );
	return preg_replace( '/[^a-z0-9_\-]/', '', $value ) ?: '';
}

function sanitize_text_field( $value ): string {
	return trim( strip_tags( (string) $value ) );
}

function sanitize_textarea_field( $value ): string {
	return sanitize_text_field( $value );
}

function sanitize_hex_color( $value ): string {
	$value = (string) $value;
	return preg_match( '/^#[a-f0-9]{6}$/i', $value ) ? $value : '';
}

function esc_url_raw( $value ): string {
	return filter_var( (string) $value, FILTER_VALIDATE_URL )
		? (string) $value
		: '';
}

function absint( $value ): int {
	return abs( (int) $value );
}

function get_option( string $name, $default = false ) {
	return array_key_exists( $name, $GLOBALS['kidia_test_options'] )
		? $GLOBALS['kidia_test_options'][ $name ]
		: $default;
}

function kidia_assert( bool $condition, string $message ): void {
	if ( ! $condition ) {
		throw new RuntimeException( $message );
	}
}

require dirname( __DIR__ ) . '/admin/framework/class-library.php';

$GLOBALS['kidia_test_options']['kidia_mobile_dividers'] = array(
	'legacy scalar',
	(object) array( 'id' => 'legacy_object' ),
	array( 'name' => 'Missing ID' ),
	array(
		'id'       => 'Divider! One',
		'name'     => '<b>Primary</b>',
		'status'   => 'invalid',
		'enabled'  => false,
		'settings' => 'broken',
	),
	array(
		'id'       => 'dividerone',
		'name'     => 'Duplicate',
		'settings' => array(),
	),
	array(
		'id'   => 'divider_two',
		'name' => '',
	),
);

$library = new Kidia_Mobile_Library(
	'kidia_mobile_dividers',
	'Dividers',
	'kidia-mobile-dividers',
	'divider',
	'kidia_create_divider',
	'kidia_save_divider',
	'kidia_duplicate_divider',
	'kidia_delete_divider'
);

$items = $library->get_items();

kidia_assert( 2 === count( $items ), 'Malformed and duplicate records must be quarantined.' );
kidia_assert( 'dividerone' === $items[0]['id'], 'IDs must be normalized at the read boundary.' );
kidia_assert( 'Primary' === $items[0]['name'], 'Names must be sanitized at the read boundary.' );
kidia_assert( 'draft' === $items[0]['status'], 'Invalid statuses must fall back to Draft.' );
kidia_assert( false === $items[0]['enabled'], 'Explicit disabled state must be preserved.' );
kidia_assert( '#e5e7eb' === $items[0]['settings']['color'], 'Broken settings must use schema defaults.' );
kidia_assert( 'published' === $items[1]['status'], 'Legacy records without status stay Published.' );
kidia_assert( true === $items[1]['enabled'], 'Legacy records without enabled state stay enabled.' );
kidia_assert( 'Untitled Item' === $items[1]['name'], 'Empty legacy names need a safe fallback.' );

fwrite( STDOUT, "Library contract test passed.\n" );
