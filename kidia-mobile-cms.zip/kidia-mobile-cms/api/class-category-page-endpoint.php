<?php
/** Ordered WooCommerce category page REST endpoint. */
defined( 'ABSPATH' ) || exit;

final class Kidia_Mobile_CMS_Category_Page_Endpoint {
	public function register(): void {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes(): void {
		register_rest_route(
			'woo-mobile/v1',
			'/category-page',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_categories' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'page'     => array( 'type' => 'integer', 'default' => 1, 'minimum' => 1 ),
					'per_page' => array( 'type' => 'integer', 'default' => 100, 'minimum' => 1, 'maximum' => 100 ),
				),
			)
		);
	}

	public function get_categories( WP_REST_Request $request ): WP_REST_Response {
		$terms = taxonomy_exists( 'product_cat' )
			? get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => true ) )
			: array();
		if ( is_wp_error( $terms ) ) {
			return new WP_REST_Response( array(), 200 );
		}

		$settings  = get_option( 'kidia_mobile_category_page', array() );
		$settings  = is_array( $settings ) ? $settings : array();
		$by_parent = array();
		foreach ( $terms as $term ) {
			$by_parent[ (int) $term->parent ][] = $term;
		}
		foreach ( $by_parent as &$siblings ) {
			usort( $siblings, static function ( $left, $right ) use ( $settings ): int {
				$left_order  = isset( $settings[ $left->term_id ]['order'] ) ? (int) $settings[ $left->term_id ]['order'] : PHP_INT_MAX;
				$right_order = isset( $settings[ $right->term_id ]['order'] ) ? (int) $settings[ $right->term_id ]['order'] : PHP_INT_MAX;
				return $left_order === $right_order ? strcasecmp( $left->name, $right->name ) : $left_order <=> $right_order;
			} );
		}
		unset( $siblings );

		$ordered = array();
		$append  = function ( int $parent, bool $ancestor_hidden = false ) use ( &$append, &$ordered, $by_parent, $settings ): void {
			foreach ( $by_parent[ $parent ] ?? array() as $term ) {
				$setting = is_array( $settings[ $term->term_id ] ?? null ) ? $settings[ $term->term_id ] : array();
				$hidden  = $ancestor_hidden || ! empty( $setting['hidden'] );
				if ( ! $hidden ) {
					$ordered[] = $this->format_term( $term, $setting );
				}
				$append( (int) $term->term_id, $hidden );
			}
		};
		$append( 0 );

		$page       = max( 1, (int) $request->get_param( 'page' ) );
		$per_page   = min( 100, max( 1, (int) $request->get_param( 'per_page' ) ) );
		$total      = count( $ordered );
		$total_page = 0 === $total ? 0 : (int) ceil( $total / $per_page );
		$response   = new WP_REST_Response( array_slice( $ordered, ( $page - 1 ) * $per_page, $per_page ), 200 );
		$response->header( 'X-WP-Total', (string) $total );
		$response->header( 'X-WP-TotalPages', (string) $total_page );
		$response->header( 'Cache-Control', 'no-cache, must-revalidate, max-age=0' );
		return $response;
	}

	private function format_term( WP_Term $term, array $setting ): array {
		$image_id = absint( $setting['image_id'] ?? 0 );
		if ( 0 === $image_id ) {
			$image_id = absint( get_term_meta( $term->term_id, 'thumbnail_id', true ) );
		}
		$image = null;
		if ( $image_id ) {
			$source    = wp_get_attachment_image_url( $image_id, 'full' );
			$thumbnail = wp_get_attachment_image_url( $image_id, 'thumbnail' );
			if ( $source ) {
				$image = array( 'id' => $image_id, 'src' => $source, 'thumbnail' => $thumbnail ?: $source, 'alt' => get_post_meta( $image_id, '_wp_attachment_image_alt', true ) );
			}
		}
		$link = get_term_link( $term );
		return array(
			'id'          => (int) $term->term_id,
			'name'        => $term->name,
			'slug'        => $term->slug,
			'parent'      => (int) $term->parent,
			'description' => $term->description,
			'count'       => (int) $term->count,
			'image'       => $image,
			'permalink'   => is_wp_error( $link ) ? '' : $link,
			'presentation' => array(
				'image_size'   => min( 120, max( 32, absint( $setting['image_size'] ?? 68 ) ) ),
				'image_shape'  => in_array( $setting['image_shape'] ?? '', array( 'square', 'rounded', 'circle' ), true ) ? $setting['image_shape'] : 'rounded',
				'image_fit'    => in_array( $setting['image_fit'] ?? '', array( 'contain', 'cover' ), true ) ? $setting['image_fit'] : 'contain',
				'image_effect' => in_array( $setting['image_effect'] ?? '', array( 'none', 'shadow', 'grayscale' ), true ) ? $setting['image_effect'] : 'none',
				'image_scale'  => min( 150, max( 80, absint( $setting['image_scale'] ?? 100 ) ) ),
				'image_position' => in_array( $setting['image_position'] ?? '', array( 'center', 'top', 'bottom', 'left', 'right' ), true ) ? $setting['image_position'] : 'center',
				'border_width' => min( 8, max( 0, absint( $setting['border_width'] ?? 0 ) ) ),
				'border_color' => sanitize_hex_color( $setting['border_color'] ?? '' ) ?: '#DDE5E2',
				'background_color' => sanitize_hex_color( $setting['background_color'] ?? '' ) ?: '#FFFFFF',
			),
		);
	}
}
