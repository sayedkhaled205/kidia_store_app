<?php
/**
 * Server-driven Home Layout REST Endpoint.
 *
 * @package Kidia_Mobile_CMS
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'Kidia_Mobile_CMS_Home_Layout_Endpoint_V4', false ) ) {
	return;
}

final class Kidia_Mobile_CMS_Home_Layout_Endpoint_V4 {

	private Kidia_Mobile_Layout_Store $layout_store;

	public function __construct() {
		$this->layout_store =
			new Kidia_Mobile_Layout_Store();
	}

	/**
	 * Registers REST hooks.
	 *
	 * @return void
	 */
	public function register(): void {

		add_action(
			'rest_api_init',
			array(
				$this,
				'register_routes',
			)
		);
	}

	/**
	 * Registers REST routes.
	 *
	 * @return void
	 */
	public function register_routes(): void {

		register_rest_route(
			'kidia/v1',
			'/home-layout',
			array(
				'methods' => WP_REST_Server::READABLE,

				'callback' => array(
					$this,
					'get_home_layout',
				),

				'permission_callback' => '__return_true',

				'args' => array(

					'locale' => array(

						'type' => 'string',

						'default' => 'ar',

						'sanitize_callback' => 'sanitize_key',

					),

				),

			)
		);
	}

	/**
	 * Returns Home Layout.
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response
	 */
	public function get_home_layout(
		WP_REST_Request $request
	): WP_REST_Response {

		$locale = sanitize_key(
			(string) $request->get_param(
				'locale'
			)
		);

		if ( empty( $locale ) ) {
			$locale = 'ar';
		}

		$layout =
			$this->layout_store->get_layout();

		$blocks = array();

		foreach ( $layout as $block ) {

			$api_block =
				Kidia_Mobile_Block_Registry::build_api_block(
					$block
				);

			if ( null === $api_block ) {
				continue;
			}

			$blocks[] = $api_block;
		}

		return new WP_REST_Response(

			array(

				'version' => 4,

				'page' => 'home',

				'locale' => $locale,

				'updated_at' => current_time(
					'c',
					true
				),

				'blocks' => array_values(
					$blocks
				),

			),

			200

		);
	}
		/**
    	 * Builds Flutter action.
    	 *
    	 * @param mixed $type Action type.
    	 * @param mixed $value Action value.
    	 *
    	 * @return array<string,string>|null
    	 */
    	private function build_action(
    		$type,
    		$value
    	): ?array {

    		$type = sanitize_key(
    			(string) $type
    		);

    		$value = trim(
    			(string) $value
    		);

    		$allowed = array(
    			'product',
    			'category',
    			'collection',
    			'search',
    			'external',
    		);

    		if (
    			empty( $type ) ||
    			empty( $value ) ||
    			! in_array(
    				$type,
    				$allowed,
    				true
    			)
    		) {
    			return null;
    		}

    		if ( 'external' === $type ) {

    			$value = esc_url_raw(
    				$value
    			);

    			if ( empty( $value ) ) {
    				return null;
    			}

    		} else {

    			$value = sanitize_text_field(
    				$value
    			);

    		}

    		return array(

    			'type' => $type,

    			'value' => $value,

    		);
    	}

    	/**
    	 * Returns WooCommerce products.
    	 *
    	 * @param array<string,mixed> $arguments Query.
    	 *
    	 * @return array<int,array<string,mixed>>
    	 */
    	private function get_products(
    		array $arguments
    	): array {

    		if (
    			! function_exists(
    				'wc_get_products'
    			)
    		) {
    			return array();
    		}

    		$products =
    			wc_get_products(
    				$arguments
    			);

    		if ( empty( $products ) ) {
    			return array();
    		}

    		$currency =
    			get_woocommerce_currency();

    		$symbol =
    			html_entity_decode(
    				wp_strip_all_tags(
    					get_woocommerce_currency_symbol(
    						$currency
    					)
    				),
    				ENT_QUOTES,
    				'UTF-8'
    			);

    		$items = array();
    			foreach ( $products as $product ) {

        			if ( ! $product instanceof WC_Product ) {
        				continue;
        			}

        			$image =
        				$this->get_product_image_url(
        					$product
        				);

        			$price =
        				(string) $product->get_price();

        			if (
        				empty( $image ) ||
        				'' === $price
        			) {
        				continue;
        			}

        			$regular =
        				(string) $product->get_regular_price();

        			$items[] = array(

        				'id' => $product->get_id(),

        				'name' => wp_strip_all_tags(
        					$product->get_name()
        				),

        				'image_url' => esc_url_raw(
        					$image
        				),

        				'price' => $price,

        				'regular_price' =>
        					(
        						'' !== $regular &&
        						$regular !== $price
        					)
        						? $regular
        						: null,

        				'currency_code' => $currency,

        				'currency_symbol' => $symbol,

        				'in_stock' =>
        					$product->is_in_stock(),

        				'badge' =>
        					$product->is_on_sale()
        						? 'عرض'
        						: null,

        				'action' => array(

        					'type' => 'product',

        					'value' => (string)
        						$product->get_id(),

        				),

        			);

        		}

        		return $items;
        	}

        	/**
        	 * Returns category image.
        	 *
        	 * @param int $category_id Category.
        	 *
        	 * @return string|null
        	 */
        	private function get_category_image_url(
        		int $category_id
        	): ?string {

        		$image_id = absint(
        			get_term_meta(
        				$category_id,
        				'thumbnail_id',
        				true
        			)
        		);

        		if ( $image_id ) {

        			$url =
        				wp_get_attachment_image_url(
        					$image_id,
        					'woocommerce_thumbnail'
        				);

        			if ( $url ) {
        				return $url;
        			}

        		}

        		if (
        			function_exists(
        				'wc_placeholder_img_src'
        			)
        		) {
        			return wc_placeholder_img_src(
        				'woocommerce_thumbnail'
        			);
        		}

        		return null;
        	}
        		/**
            	 * Returns product image.
            	 *
            	 * @param WC_Product $product Product.
            	 *
            	 * @return string|null
            	 */
            	private function get_product_image_url(
            		WC_Product $product
            	): ?string {

            		$image_id = $product->get_image_id();

            		if ( $image_id ) {

            			$url = wp_get_attachment_image_url(
            				$image_id,
            				'woocommerce_thumbnail'
            			);

            			if ( $url ) {
            				return $url;
            			}
            		}

            		if (
            			function_exists(
            				'wc_placeholder_img_src'
            			)
            		) {

            			return wc_placeholder_img_src(
            				'woocommerce_thumbnail'
            			);

            		}

            		return null;
            	}
            }