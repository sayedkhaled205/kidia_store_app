=== MobiShop ===
Tags: mobile app, app builder, ecommerce, store app, woocommerce
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 8.0
Requires Plugins: woocommerce
Stable tag: 1.46.68
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Connect a WooCommerce store to the MobiShop app builder, manage the mobile storefront, and request Android and iOS builds.

== Description ==

MobiShop connects a WooCommerce store to the MobiShop service and provides the WordPress-side tools used by its mobile applications.

The plugin includes:

* A visual home, catalog, product, account, header, and footer builder.
* REST API endpoints for catalog, layouts, customer accounts, orders, checkout, and app configuration.
* Store analytics, abandoned-cart recovery, offer tools, push notification controls, and app promotion tools.
* License activation and secure, installation-bound communication with the MobiShop build service.
* Arabic and English storefront configuration, including right-to-left layouts.

An active MobiShop subscription is required to unlock the managed app-building and publishing features. WooCommerce must be installed and active.

= External service =

This plugin connects to the MobiShop service at `https://api.woomobile.app` when an administrator connects a website, activates or verifies a license, requests an app build, or configures managed push notifications.

For license activation, the plugin sends the license key, website URL, plugin version, a random installation identifier, and a one-time nonce. Hourly license verification sends the installation-bound activation token, plugin version, and a one-time nonce. App-build and managed-push requests send the settings selected by the administrator and the installation-bound authorization token. The plugin does not send customer passwords or raw payment-card data to MobiShop.

The service is provided by MobiShop and is required for subscription validation, managed builds, and managed push notifications:

* Service: https://woomobile.app/
* Terms: https://woomobile.app/terms/
* Privacy policy: https://woomobile.app/privacy/

== Installation ==

1. Install and activate WooCommerce.
2. Install and activate MobiShop.
3. Open **MobiShop** in WordPress administration.
4. Connect the website to your MobiShop account.
5. Activate the license assigned to this website.
6. Configure the application and request a build when ready.

== Frequently Asked Questions ==

= Does the plugin require WooCommerce? =

Yes. It exposes and manages mobile storefront functionality for a WooCommerce store.

= Is a MobiShop subscription required? =

The plugin can be installed and previewed without a subscription. An active subscription is required to save licensed configuration and use managed build and push services.

= Does the plugin store payment-card data? =

No. Store checkout is handled by the payment methods configured in WooCommerce, and the plugin does not store raw card details.

= Does the plugin support Arabic and RTL layouts? =

Yes. Application language, direction, typography, and other visual settings can be configured from the builder.

== Changelog ==

= 1.46.68 =
* Select platform-specific Firebase configuration and enable native iOS push registration after APNs becomes available.
* Identify WordPress plugin build requests separately from the central builder project.

= 1.46.67 =
* Restore compatibility with the deployed license and build API and its installation authentication headers.
* Open website connections on the account portal.
* Fix Flutter preview readiness, startup error, scroll and cache-version messages after the MobiShop rename.

= 1.46.66 =

* Fixed switch thumb placement in left-to-right and right-to-left builders.
* Fixed checkout status control and toolbar icon alignment, preserving keyboard focus and form values.

= 1.46.65 =

* Restored the styled sidebar on the main MobiShop administration page.
* Restored the green MobiShop styling for the website connection button.

= 1.46.64 =

* Completed the full MobiShop rebrand across public labels, service attribution, code identifiers, REST namespaces, option keys, hooks, classes, files, and package paths.
* Kept the existing service domains unchanged while presenting the service as MobiShop.

= 1.46.62 =

* Fixed the WordPress installation path by using `mobishop/mobishop.php` as the packaged plugin entry file.
* Added strict ZIP-layout checks and clean activation validation before publishing the package.

= 1.46.61 =

* Aligned the translation text domain with the assigned WordPress.org slug.
* Fixed the plugin and author URI validation for WordPress.org submission.

= 1.46.60 =

* Added global application settings and an expanded font collection.
* Updated the packaged plugin and embedded mobile preview.

== Upgrade Notice ==

= 1.46.65 =

Use this release to restore the main MobiShop administration layout.

= 1.46.64 =

Use this release for the complete MobiShop identity and updated internal namespaces.

= 1.46.62 =

Use this release to replace packages that installed under an incorrect nested plugin directory.
