(function () {
	"use strict";
	var root = document.querySelector(".mobishop-builder-wrap");
	var frame = document.getElementById("mobishop-flutter-preview");
	var form = document.getElementById("mobishop-home-builder-form");
	if (!root || !frame || !form) { return; }
	var config = window.mobishopHomeBuilder || {};
	var ready = false;
	var controller = null;
	var requestNumber = 0;
	var refreshTimer = 0;
	var sentInitialState = false;
	var pendingPayload = "";
	var deliveryTimer = 0;
	var deliveryAttempts = 0;
	var blocks = Array.isArray(window.mobishopHomePreviewBlocks) ? window.mobishopHomePreviewBlocks : [];
	var lastSignature = "";
	var fallback = frame.parentElement && frame.parentElement.querySelector(".mobishop-legacy-preview-fallback");
	var frameOrigin = window.location.origin;
	try { frameOrigin = new URL(frame.src, window.location.href).origin; } catch (_) {}
	function waitForFlutter() {
		// Keep the real Flutter surface visible while its own loading state is
		// shown. An HTML replica can drift from the mobile widgets.
		frame.hidden = false;
		frame.setAttribute("aria-busy", "true");
		if (fallback) { fallback.hidden = true; }
	}
	function showFlutter() {
		window.requestAnimationFrame(function () {
			window.requestAnimationFrame(function () {
				frame.hidden = false;
				frame.removeAttribute("aria-busy");
				if (fallback) { fallback.hidden = true; }
			});
		});
	}
	function setPath(target, name, value) {
		var keys = String(name).replace(/\]/g, "").split("[");
		var cursor = target;
		keys.forEach(function (key, index) {
			var last = index === keys.length - 1;
			var nextIsIndex = !last && /^\d+$/.test(keys[index + 1]);
			if (last) { cursor[key] = value; return; }
			if (!cursor[key] || typeof cursor[key] !== "object") { cursor[key] = nextIsIndex ? [] : {}; }
			cursor = cursor[key];
		});
	}
	function serializeLayout() {
		var result = {};
		Array.prototype.forEach.call(form.elements, function (field) {
			if (!field.name || field.disabled || field.name.indexOf("layout[") !== 0) { return; }
			if ((field.type === "checkbox" || field.type === "radio") && !field.checked) { return; }
			setPath(result, field.name, field.value);
		});
		return result.layout || {};
	}
	function postJson(url, body, signal) {
		return window.fetch(String(url), {
			method: "POST", credentials: "same-origin", cache: "no-store", signal: signal,
			headers: { "Content-Type": "application/json", "X-WP-Nonce": String(config.restNonce) },
			body: JSON.stringify(body)
		}).then(function (response) {
			if (!response.ok) { throw new Error("Preview request failed with HTTP " + response.status + "."); }
			return response.json();
		});
	}
	function deliverPayload() {
		window.clearTimeout(deliveryTimer);
		if (!pendingPayload || !frame.contentWindow) { return; }
		frame.contentWindow.postMessage(pendingPayload, frameOrigin);
		deliveryAttempts += 1;
		if (ready) {
			pendingPayload = "";
			deliveryAttempts = 0;
			showFlutter();
			return;
		}
		if (deliveryAttempts < 32) {
			deliveryTimer = window.setTimeout(deliverPayload, 250);
			return;
		}
		// Do not leave the phone on an infinite loader if the iframe ready
		// message was missed by the parent during a cached refresh.
		showFlutter();
		deliveryAttempts = 0;
		lastSignature = "";
	}
	function refresh(force) {
		var signature;
		var number;
		var signal;
		if (!config.layoutPreviewEndpoint || !config.livePreviewEndpoint || !config.restNonce || typeof window.fetch !== "function") { return; }
		signature = JSON.stringify({ layout: serializeLayout(), blocks: blocks });
		if (!force && signature === lastSignature) { return; }
		lastSignature = signature;
		if (controller) { controller.abort(); }
		controller = typeof window.AbortController === "function" ? new window.AbortController() : null;
		signal = controller ? controller.signal : undefined;
		number = ++requestNumber;
		Promise.all([
			postJson(config.layoutPreviewEndpoint, { layout: serializeLayout() }, signal),
			postJson(config.livePreviewEndpoint, { blocks: blocks }, signal)
		]).then(function (payloads) {
			if (number !== requestNumber || !frame.contentWindow) { return; }
			pendingPayload = JSON.stringify({ type: "mobishop-preview-layout", page: "home", layout: payloads[0], home: payloads[1] });
			deliveryAttempts = 0;
			deliverPayload();
		}).catch(function (error) {
			if (error && error.name === "AbortError") { return; }
			if (window.console && window.console.warn) { window.console.warn(error); }
		});
	}
	function queueRefresh(force) {
		window.clearTimeout(refreshTimer);
		if (force) {
			refresh(true);
			return;
		}
		// Typing and range controls can emit several events per frame. A short
		// debounce keeps the UI live without piling up expensive product queries.
		refreshTimer = window.setTimeout(function () {
			refresh(false);
		}, 140);
	}
	window.addEventListener("message", function (event) {
		if (event.source !== frame.contentWindow || event.origin !== frameOrigin) { return; }
		var message = event.data;
		if (typeof message === "string") { try { message = JSON.parse(message); } catch (_) { return; } }
		if (message && message.type === "mobishop-flutter-preview-ready") {
			ready = true;
			showFlutter();
			if (pendingPayload) {
				deliverPayload();
				sentInitialState = true;
				return;
			}
			if (!sentInitialState) {
				sentInitialState = true;
				queueRefresh(true);
			}
		}
	});
	frame.addEventListener("load", function () {
		ready = false;
		sentInitialState = false;
		lastSignature = "";
		pendingPayload = "";
		deliveryAttempts = 0;
		window.clearTimeout(deliveryTimer);
		waitForFlutter();
		queueRefresh(true);
	});
	form.addEventListener("input", function () { queueRefresh(false); });
	form.addEventListener("change", function () { queueRefresh(false); });
	document.addEventListener("mobishop:home-preview-state", function (event) {
		if (event.detail && Array.isArray(event.detail.blocks)) { blocks = event.detail.blocks; queueRefresh(false); }
	});
	document.addEventListener("mobishop:home-preview-focus", function (event) {
		var target = event.detail && String(event.detail.target || "");
		if (!target || !ready || !frame.contentWindow) { return; }
		frame.contentWindow.postMessage(JSON.stringify({
			type: "mobishop-preview-focus",
			page: "home",
			target: target
		}), frameOrigin);
	});
	function focusPreview() {
		// Give the embedded Flutter surface the wheel/trackpad events while the
		// pointer is over the phone, without requiring an initial click.
		try { frame.contentWindow.focus(); } catch (_) {}
	}
	frame.setAttribute("tabindex", "0");
	function relayPreviewWheel(event) {
		if (!event.deltaY || !frame.contentWindow) { return; }
		frame.contentWindow.postMessage(JSON.stringify({
			type: "mobishop-preview-scroll",
			page: "home",
			deltaY: Math.max(-180, Math.min(180, Number(event.deltaY)))
		}), frameOrigin);
		event.preventDefault();
		event.stopImmediatePropagation();
	}
	function bindPreviewWheel() {
		try {
			frame.contentWindow.removeEventListener("wheel", relayPreviewWheel, true);
			frame.contentWindow.addEventListener("wheel", relayPreviewWheel, { capture: true, passive: false });
			if (frame.contentDocument) {
				frame.contentDocument.removeEventListener("wheel", relayPreviewWheel, true);
				frame.contentDocument.addEventListener("wheel", relayPreviewWheel, { capture: true, passive: false });
			}
		} catch (_) {}
	}
	frame.addEventListener("mouseenter", focusPreview);
	frame.addEventListener("pointerenter", focusPreview);
	frame.addEventListener("click", focusPreview);
	frame.addEventListener("load", bindPreviewWheel);
	bindPreviewWheel();
	document.addEventListener("keydown", function (event) {
		if (event.altKey || event.ctrlKey || event.metaKey) { return; }
		var target = event.target;
		if (target && (target.matches("input, textarea, select, button, [contenteditable='true']") || target.closest(".media-modal, .mobishop-modal"))) { return; }
		var cards = document.querySelector("[data-mobishop-builder-cards-scroll]");
		var amount = 0;
		if (event.key === "ArrowDown") { amount = 72; }
		else if (event.key === "ArrowUp") { amount = -72; }
		else if (event.key === "PageDown") { amount = Math.max(180, Math.floor(window.innerHeight * 0.8)); }
		else if (event.key === "PageUp") { amount = -Math.max(180, Math.floor(window.innerHeight * 0.8)); }
		else if (event.key === "Home") { (cards || window).scrollTo({ top: 0, behavior: "smooth" }); event.preventDefault(); return; }
		else if (event.key === "End") { (cards || window).scrollTo({ top: cards ? cards.scrollHeight : document.documentElement.scrollHeight, behavior: "smooth" }); event.preventDefault(); return; }
		if (!amount) { return; }
		(cards || window).scrollBy({ top: amount, behavior: "smooth" });
		event.preventDefault();
	});
	// Do not rely on a load event that a cached iframe may already have fired.
	waitForFlutter();
	queueRefresh(true);
}());
