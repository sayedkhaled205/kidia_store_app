<?php
/**
 * Customer account endpoint contract test with WordPress/WooCommerce stubs.
 *
 * Run with: php mobishop/tests/customer-account-endpoint-contract-test.php
 */

declare( strict_types=1 );

define( 'ABSPATH', __DIR__ );

$GLOBALS['mobishop_account_routes']  = array();
$GLOBALS['mobishop_current_user_id'] = 7;
$GLOBALS['mobishop_user_meta']       = array(
	7 => array(
		'_mobishop_account_phone' => '01000000000',
		'billing_phone1'              => '01100000000',
	),
);
$GLOBALS['mobishop_customer']        = array(
	'id'           => 7,
	'email'        => 'customer@example.com',
	'first_name'   => 'MobiShop',
	'last_name'    => 'Customer',
	'display_name' => 'MobiShop Customer',
	'billing'      => array(
		'first_name' => 'MobiShop',
		'last_name'  => 'Customer',
		'address_1'  => '1 Test Street',
		'city'       => 'Cairo',
		'state'      => 'C',
		'country'    => 'EG',
		'phone'      => '01000000000',
	),
	'shipping'     => array(),
);
$GLOBALS['mobishop_skip_customer_save'] = false;

class WP_REST_Server {
	public const READABLE  = 'GET';
	public const CREATABLE = 'POST';
}

class WP_REST_Request {
	public function __construct(
		private array $params = array(),
		private array $json = array()
	) {}

	public function get_param( string $key ) {
		return $this->params[ $key ] ?? null;
	}

	public function get_json_params(): array {
		return $this->json;
	}
}

class WP_REST_Response {
	public $data;
	public int $status;
	public array $headers = array();

	public function __construct( $data, int $status = 200 ) {
		$this->data   = $data;
		$this->status = $status;
	}

	public function header( string $name, string $value ): void {
		$this->headers[ $name ] = $value;
	}
}

class WP_Error {
	public function __construct(
		private string $code,
		private string $message,
		private array $data = array()
	) {}

	public function get_error_code(): string {
		return $this->code;
	}

	public function get_error_data(): array {
		return $this->data;
	}
}

class WC_Customer {
	private array $data;

	public function __construct( private int $id ) {
		$this->data = $GLOBALS['mobishop_customer'];
	}

	public function get_id(): int {
		return $this->id;
	}

	public function get_email(): string {
		return (string) $this->data['email'];
	}

	public function get_first_name(): string {
		return (string) $this->data['first_name'];
	}

	public function get_last_name(): string {
		return (string) $this->data['last_name'];
	}

	public function get_display_name(): string {
		return (string) $this->data['display_name'];
	}

	public function __call( string $method, array $arguments ) {
		if ( preg_match( '/^get_(billing|shipping)_(.+)$/', $method, $matches ) ) {
			return $this->data[ $matches[1] ][ $matches[2] ] ?? '';
		}
		if ( preg_match( '/^set_(billing|shipping)_(.+)$/', $method, $matches ) ) {
			$this->data[ $matches[1] ][ $matches[2] ] = (string) ( $arguments[0] ?? '' );
			return null;
		}
		throw new BadMethodCallException( $method );
	}

	public function save(): void {
		if ( $GLOBALS['mobishop_skip_customer_save'] ) {
			return;
		}
		$GLOBALS['mobishop_customer'] = $this->data;
	}
}

function add_action( string $hook, $callback ): void {
	unset( $hook, $callback );
}

function register_rest_route( string $namespace, string $route, array $definition ): void {
	$GLOBALS['mobishop_account_routes'][ $namespace . $route ] = $definition;
}

function __( string $text, string $domain = '' ): string {
	unset( $domain );
	return $text;
}

function get_current_user_id(): int {
	return (int) $GLOBALS['mobishop_current_user_id'];
}

function is_wp_error( $value ): bool {
	return $value instanceof WP_Error;
}

function sanitize_text_field( $value ): string {
	return trim( strip_tags( (string) $value ) );
}

function sanitize_key( $value ): string {
	return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $value ) ) ?: '';
}

function sanitize_email( $value ): string {
	return filter_var( (string) $value, FILTER_SANITIZE_EMAIL ) ?: '';
}

function is_email( $value ): bool {
	return false !== filter_var( (string) $value, FILTER_VALIDATE_EMAIL );
}

function email_exists( string $email ) {
	return 'used@example.com' === $email ? 99 : false;
}

function wp_update_user( array $values ) {
	if ( isset( $values['first_name'] ) ) {
		$GLOBALS['mobishop_customer']['first_name'] = $values['first_name'];
	}
	if ( isset( $values['last_name'] ) ) {
		$GLOBALS['mobishop_customer']['last_name'] = $values['last_name'];
	}
	if ( isset( $values['display_name'] ) ) {
		$GLOBALS['mobishop_customer']['display_name'] = $values['display_name'];
	}
	if ( isset( $values['user_email'] ) ) {
		$GLOBALS['mobishop_customer']['email'] = $values['user_email'];
	}
	return (int) $values['ID'];
}

function get_user_meta( int $user_id, string $key, bool $single = false ) {
	unset( $single );
	return $GLOBALS['mobishop_user_meta'][ $user_id ][ $key ] ?? '';
}

function update_user_meta( int $user_id, string $key, $value ): void {
	$GLOBALS['mobishop_user_meta'][ $user_id ][ $key ] = (string) $value;
}

function clean_user_cache( int $user_id ): void {
	unset( $user_id );
}

function get_option( string $key, $default = '' ) {
	return match ( $key ) {
		'woocommerce_email_from_address' => 'support@example.com',
		'admin_email' => 'support@example.com',
		'woocommerce_store_phone' => '+201000000000',
		default => $default,
	};
}

function apply_filters( string $hook, $value ) {
	unset( $hook );
	return $value;
}

function home_url( string $path = '' ): string {
	return 'https://shop.example.com' . $path;
}

function esc_url_raw( $value ): string {
	return (string) $value;
}

function wc_sanitize_phone_number( string $value ): string {
	return preg_replace( '/[^0-9+]/', '', $value ) ?: '';
}

function mobishop_account_assert( bool $condition, string $message ): void {
	if ( ! $condition ) {
		throw new RuntimeException( $message );
	}
}

require dirname( __DIR__ ) . '/api/class-customer-account-endpoint.php';

$endpoint = new MobiShop_Customer_Account_Endpoint();
$endpoint->register_routes();
mobishop_account_assert( 3 === count( $GLOBALS['mobishop_account_routes'] ), 'All customer account routes must be registered.' );
mobishop_account_assert(
	WP_REST_Server::READABLE === $GLOBALS['mobishop_account_routes']['mobishop/v1/customer/account']['methods'],
	'Customer account reads must use GET.'
);

$GLOBALS['mobishop_current_user_id'] = 0;
$unauthorized = $endpoint->authenticate_customer( new WP_REST_Request() );
mobishop_account_assert( $unauthorized instanceof WP_Error, 'Signed-out account requests must be rejected.' );
mobishop_account_assert( 401 === $unauthorized->get_error_data()['status'], 'Missing sessions must return HTTP 401.' );

$GLOBALS['mobishop_current_user_id'] = 7;
$account = $endpoint->get_account();
mobishop_account_assert( $account instanceof WP_REST_Response, 'Signed-in customers must receive account data.' );
mobishop_account_assert( 'customer@example.com' === $account->data['profile']['email'], 'The WooCommerce profile must be returned.' );
mobishop_account_assert( '01000000000' === $account->data['profile']['phone'], 'The fixed sign-in phone must be returned with the profile.' );
mobishop_account_assert( '' === $account->data['profile']['alternate_phone'], 'Shipping contact numbers must not leak into account identity.' );
mobishop_account_assert( '01100000000' === $account->data['billing']['billing_phone1'], 'The alternate phone must be returned with the shipping address.' );
mobishop_account_assert( '1 Test Street' === $account->data['billing']['billing_address_1'], 'Saved billing values must be returned.' );
mobishop_account_assert( 'support@example.com' === $account->data['support']['email'], 'Store-controlled support details must be returned.' );
mobishop_account_assert( str_contains( $account->headers['Cache-Control'], 'no-store' ), 'Private account data must not be cached.' );

$profile = $endpoint->update_profile(
	new WP_REST_Request(
		array(),
		array(
			'first_name'   => 'Updated',
			'last_name'    => 'Customer',
			'display_name' => 'Updated Customer',
			'email'        => 'updated@example.com',
			'phone'        => '012-345-67890',
			'alternate_phone' => '015-555-55555',
		)
	)
);
mobishop_account_assert( 'Updated' === $profile->data['profile']['first_name'], 'Profile updates must be persisted through WordPress.' );
mobishop_account_assert( 'updated@example.com' === $profile->data['profile']['email'], 'Email updates must be persisted through WordPress.' );
mobishop_account_assert( '01000000000' === $profile->data['profile']['phone'], 'Profile edits must not replace the fixed sign-in phone.' );
mobishop_account_assert( '01100000000' === $GLOBALS['mobishop_user_meta'][7]['billing_phone1'], 'Profile edits must not replace shipping contact numbers.' );

$billing_address = $endpoint->update_address(
	new WP_REST_Request(
		array( 'type' => 'billing' ),
		array(
			'billing_phone'  => '012-345-67890',
			'billing_phone1' => '015-555-55555',
		)
	)
);
mobishop_account_assert( '01234567890' === $billing_address->data['address']['billing_phone'], 'The primary shipping phone must be saved with the address.' );
mobishop_account_assert( '01555555555' === $billing_address->data['address']['billing_phone1'], 'The alternate shipping phone must be saved with the address.' );
mobishop_account_assert( '01000000000' === $GLOBALS['mobishop_user_meta'][7]['_mobishop_account_phone'], 'Shipping edits must preserve account identity.' );

$address = $endpoint->update_address(
	new WP_REST_Request(
		array( 'type' => 'shipping' ),
		array(
			'shipping_first_name' => 'Updated',
			'shipping_address_1'  => '2 New Street',
			'shipping_city'       => 'Giza',
			'shipping_country'    => 'EG',
		)
	)
);
mobishop_account_assert( '2 New Street' === $address->data['address']['shipping_address_1'], 'Shipping addresses must be saved in WooCommerce.' );
mobishop_account_assert( 'Giza' === $address->data['address']['shipping_city'], 'Address fields must be returned after saving.' );

$GLOBALS['mobishop_skip_customer_save'] = true;
$not_persisted = $endpoint->update_address(
	new WP_REST_Request(
		array( 'type' => 'shipping' ),
		array( 'shipping_city' => 'Alexandria' )
	)
);
mobishop_account_assert( $not_persisted instanceof WP_Error, 'An unpersisted address update must fail.' );
mobishop_account_assert( 'mobishop_account_persistence_failed' === $not_persisted->get_error_code(), 'The endpoint must report a persistence failure.' );
$GLOBALS['mobishop_skip_customer_save'] = false;

fwrite( STDOUT, "Customer account endpoint contract test passed.\n" );
