<?php
/** Home Builder is the canonical source for complete element settings. */
declare( strict_types=1 );
define( 'ABSPATH', __DIR__ );
$GLOBALS['mobishop_test_options'] = array();
function __( string $text, string $domain = '' ): string { unset( $domain ); return $text; }
function sanitize_key( $value ): string { return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $value ) ) ?: ''; }
function sanitize_text_field( $value ): string { return trim( strip_tags( (string) $value ) ); }
function sanitize_textarea_field( $value ): string { return sanitize_text_field( $value ); }
function sanitize_hex_color( $value ) { return preg_match( '/^#[0-9a-f]{6}$/i', (string) $value ) ? (string) $value : null; }
function esc_url_raw( $value ): string { return filter_var( (string) $value, FILTER_VALIDATE_URL ) ? (string) $value : ''; }
function absint( $value ): int { return abs( (int) $value ); }
function wp_parse_args( $args, $defaults = array() ): array { return array_merge( (array) $defaults, (array) $args ); }
function get_option( string $name, $default = false ) { return array_key_exists( $name, $GLOBALS['mobishop_test_options'] ) ? $GLOBALS['mobishop_test_options'][ $name ] : $default; }
function update_option( string $name, $value, bool $autoload = false ): bool { unset( $autoload ); $GLOBALS['mobishop_test_options'][ $name ] = $value; return true; }
function current_time( string $type, bool $gmt = false ): string { unset( $type, $gmt ); return '2026-07-18 00:00:00'; }

final class MobiShop_Block_Registry {
	private const TYPES = array( 'app_header', 'hero_slider', 'image_banner', 'product_carousel', 'brand_carousel', 'category_grid', 'product_grid', 'section_header', 'promo_strip', 'coupon_banner', 'countdown', 'video_banner', 'text_block', 'divider', 'spacer', 'quick_links', 'banner_grid' );
	public static function exists( string $type ): bool { return in_array( $type, self::TYPES, true ); }
	public static function defaults( string $type ): array { unset( $type ); return array( 'title' => '', 'image_url' => '', 'items' => array(), 'limit' => 8 ); }
	public static function generate_id( string $type ): string { return $type . '_generated'; }
	public static function create( string $type, int $order ): array { return array( 'id' => $type . '_' . $order, 'type' => $type, 'enabled' => true, 'order' => $order, 'settings' => self::defaults( $type ) ); }
	public static function get( string $type ): array { return array( 'label' => $type ); }
}
function mobishop_assert( bool $condition, string $message ): void { if ( ! $condition ) throw new RuntimeException( $message ); }
require dirname( __DIR__ ) . '/includes/class-mobishop-layout-store.php';

// Legacy references migrate once, but unplaced Library records are never
// injected into the Home Page.
$GLOBALS['mobishop_test_options']['mobishop_hero_sliders'] = array(
	array( 'id' => 'placed', 'name' => 'Placed', 'enabled' => true, 'status' => 'published', 'settings' => array( 'title' => 'Legacy title' ) ),
	array( 'id' => 'unplaced', 'name' => 'Old page item', 'enabled' => true, 'status' => 'published', 'settings' => array( 'title' => 'Must stay hidden' ) ),
);
$GLOBALS['mobishop_test_options']['mobishop_home_layout_v4'] = array(
	array( 'id' => 'placed', 'library_id' => 'placed', 'type' => 'hero_slider', 'name' => 'Placed', 'enabled' => true, 'status' => 'published', 'order' => 1 ),
);
$store = new MobiShop_Layout_Store();
$migrated = $store->get_layout();
mobishop_assert( 1 === count( $migrated ), 'Legacy Library items not placed in Home Builder must stay hidden.' );
mobishop_assert( 'Legacy title' === $migrated[0]['settings']['title'], 'A referenced legacy element must migrate its settings.' );

$submitted = array();
$types = array( 'app_header', 'hero_slider', 'image_banner', 'product_carousel', 'brand_carousel', 'category_grid', 'product_grid', 'section_header', 'promo_strip', 'coupon_banner', 'countdown', 'video_banner', 'text_block', 'divider', 'spacer', 'quick_links', 'banner_grid' );
foreach ( $types as $index => $type ) {
	$submitted[] = array(
		'id' => $type . '_inline', 'library_id' => $type . '_inline', 'type' => $type,
		'name' => 'Inline ' . $type, 'enabled' => '1', 'status' => 'published', 'order' => $index + 1,
		'settings' => array( 'title' => 'Saved ' . $type, 'limit' => 12, 'items' => array( array( 'image_url' => 'https://example.com/' . $type . '.jpg' ) ) ),
	);
}
$decoded = MobiShop_Layout_Store::decode_submission( (string) json_encode( $submitted ) );
mobishop_assert( count( $types ) === count( $decoded ), 'JSON submission must contain every inline element.' );
$encoded = base64_encode( (string) json_encode( $submitted ) );
$decoded_base64 = MobiShop_Layout_Store::decode_submission( $encoded, 'base64' );
mobishop_assert( count( $types ) === count( $decoded_base64 ), 'Base64 submission must survive hosting security filters.' );
mobishop_assert( array() === MobiShop_Layout_Store::decode_submission( 'broken payload', 'base64' ), 'A damaged payload must be rejected instead of erasing the Home Layout.' );
$store->save_layout( $decoded );
$reloaded = $store->get_layout();
mobishop_assert( count( $types ) === count( $reloaded ), 'Every inline element must survive save/reload.' );
foreach ( $reloaded as $index => $block ) {
	mobishop_assert( 'published' === $block['status'], 'Inline visibility must survive.' );
	mobishop_assert( 'Saved ' . $types[ $index ] === $block['settings']['title'], 'Inline settings must be canonical after reload.' );
}
$runtime = $store->get_runtime_layout();
mobishop_assert( count( $types ) === count( $runtime ), 'The mobile runtime must read the same complete Home Builder layout.' );
mobishop_assert( isset( $GLOBALS['mobishop_test_options']['mobishop_home_layout_v5'][0]['settings'] ), 'The saved Home Layout must contain settings, not Library references only.' );
$preset = $store->get_mobishop_patpat_layout();
mobishop_assert( 'image_banner' === $preset[0]['type'], 'The PatPat content must begin with the main banner and omit the shortcut circles.' );
mobishop_assert( 1.0 === (float) $preset[0]['settings']['aspect_ratio'], 'The main MobiShop banner must use the tall PatPat proportion.' );
mobishop_assert( 'category_grid' === $preset[1]['type'] && 3 === $preset[1]['settings']['columns'], 'The circular MobiShop categories must follow the main banner in three columns.' );
mobishop_assert( 5 === $preset[1]['settings']['limit'] && 'grid' === $preset[1]['settings']['layout'], 'The category grid must show the store\'s five categories.' );
$saved_banner = array_values( array_filter( $reloaded, static fn ( array $block ): bool => 'image_banner' === $block['type'] ) )[0];
mobishop_assert( $saved_banner['id'] === $preset[0]['id'], 'The PatPat preset must reuse the store\'s real MobiShop banner instead of creating an empty one.' );
$default_layout = $store->get_default_layout();
mobishop_assert( array( 'image_banner', 'category_grid' ) === array_column( array_slice( $default_layout, 0, 2 ), 'type' ), 'Fresh Home Pages must open with the banner followed by categories.' );
fwrite( STDOUT, "Inline Home Builder canonical-layout test passed for all 17 elements.\n" );
